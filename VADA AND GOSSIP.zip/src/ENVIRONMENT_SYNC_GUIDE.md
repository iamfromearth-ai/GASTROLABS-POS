# 🔄 Environment Sync Guide

## 📱 Understanding Different Environments

Your POS app stores data in **browser localStorage**, which is **environment-specific**:

### **Separate Environments:**
- ✅ **Figma Preview** → Has its own localStorage
- ✅ **Chrome Browser** → Has its own localStorage  
- ✅ **Mobile Chrome** → Has its own localStorage
- ✅ **Incognito Mode** → Temporary localStorage (cleared on close)

**Each environment is COMPLETELY SEPARATE** - they don't share data!

---

## 🎨 Branding Consistency Fix

### **Before Fix:**
- Default: "VADA AND GOSSIP" | "Breakfast Chat Bun"
- Inconsistent capitalization and formatting

### **After Fix:**
- Default: **"Vada and Gossip"** | **"Breakfast, Chat & Bun"**
- ✅ Proper capitalization
- ✅ Professional formatting with comma
- ✅ Consistent across all environments

---

## 🔐 Password Protection Per Environment

### **Why Figma Preview Has No Password:**

**Figma Preview** and **Chrome Browser** have **separate localStorage**, so:

1. ✅ You set password in **Chrome laptop** → Saved in Chrome's localStorage
2. ❌ You open **Figma preview** → Fresh localStorage, NO password set
3. ✅ Password protection logic works correctly - just no password configured yet!

### **Solution:**

**Option 1: Set Password in Each Environment**
- Open Figma Preview → Settings → Password Protection → Set Password
- Open Mobile Chrome → Settings → Password Protection → Set Password
- Each environment needs its own password setup

**Option 2: Use Data Export/Import (Recommended)**
- Export settings from one environment
- Import into other environments
- Syncs all settings including password

---

## 💾 Syncing Settings Between Environments

### **Method 1: Data Export/Import**

#### **Export from Chrome (Laptop):**
1. Open Chrome browser with your configured POS
2. Click **Settings** (sidebar icon)
3. Click **Data Settings**
4. Click **Export Data**
5. Save the JSON file

#### **Import to Figma Preview:**
1. Open **Figma Preview**
2. Click **Settings** → **Data Settings**
3. Click **Import Data**
4. Select the exported JSON file
5. ✅ All settings synced! (branding, password, configs)

#### **Import to Mobile:**
1. Transfer JSON file to phone (email, cloud, airdrop)
2. Open POS app in **Mobile Chrome**
3. Settings → Data Settings → Import Data
4. Select file
5. ✅ Mobile now has same settings!

---

## 📋 What Gets Synced via Export/Import

✅ **Included:**
- Menu items & categories
- Order history
- App settings (currency, sound, etc)
- Receipt configuration
- Branding (business name, address, logo)
- Printer settings
- Email/Message templates

❌ **NOT Included (Security):**
- Admin password hash (**security feature** - must be set manually)

---

## 🎯 Recommended Workflow

### **For Trial/Production Use:**

#### **1. Configure Master Environment (Chrome Laptop)**
- Set up all branding (Settings → Branding Settings)
- Configure business identity (Settings → Receipt Settings → Business Identity)
- Set admin password (Settings → Password Protection)
- Configure printer, email, etc.

#### **2. Export Master Configuration**
- Settings → Data Settings → Export Data
- Save `teashop-data-YYYY-MM-DD.json`

#### **3. Deploy to Other Environments**
- **Figma Preview:** Import data file
- **Mobile Chrome:** Transfer file → Import
- **Team Member Devices:** Share file → Import

#### **4. Set Passwords (Each Environment)**
- After importing, go to Settings → Password Protection
- Set the same password for consistency
- OR use different passwords per device for better security

---

## 🔒 Security Note: Why Passwords Aren't Exported

**Passwords are NOT included in exports for security reasons:**

✅ **Prevents password leakage** if export file is shared
✅ **Allows different passwords** per environment/device
✅ **Forces deliberate password setup** instead of auto-import

**You MUST manually set the password in each environment after importing.**

---

## 🚀 Quick Setup for Your Shop Trial

### **Your Current State:**
- Chrome (Laptop): ✅ Configured with "VADA AND GOSSIP"
- Figma Preview: ❌ Default branding, no password
- Mobile: ❓ Unknown state

### **Action Plan:**

#### **Step 1: Update Chrome Configuration**
1. Open Chrome browser
2. Settings → Receipt Settings → Business Identity
3. Update to: **"Vada and Gossip"** | **"Breakfast, Chat & Bun"**
4. Upload your logo if needed
5. Save changes

#### **Step 2: Export Master Config**
1. Settings → Data Settings → Export Data
2. Save file: `vada-gossip-config.json`

#### **Step 3: Sync to Figma Preview**
1. Open Figma Preview
2. Settings → Data Settings → Import Data
3. Select `vada-gossip-config.json`
4. Settings → Password Protection → Set Password (same as Chrome)

#### **Step 4: Sync to Mobile**
1. Email yourself `vada-gossip-config.json`
2. Open email on phone
3. Download file
4. Open POS app in Mobile Chrome
5. Settings → Data Settings → Import Data
6. Settings → Password Protection → Set Password

---

## 📱 Mobile-Specific Tips

### **Password Protection on Mobile:**
- ✅ Now works correctly after our fix
- ✅ Sessions clear when browser closes (secure)
- ✅ Must authenticate each time you open app fresh

### **Testing on Mobile:**
1. Close Chrome completely (swipe away from recent apps)
2. Reopen Chrome
3. Navigate to POS app
4. Try to click **Settings** → Should ask for password ✅

---

## 🎨 Consistent Branding Checklist

✅ **Business Name:** "Vada and Gossip"  
✅ **Tagline/Address:** "Breakfast, Chat & Bun"  
✅ **Logo:** Upload via Settings → Receipt Settings → Logo Settings  
✅ **Colors:** Green theme (#EAEF9D to #336A29) - already built-in  
✅ **Typography:** Space Grotesk - already built-in  

---

## ✅ Verification Steps

### **After Syncing All Environments:**

1. **Open each environment:**
   - Figma Preview
   - Chrome Laptop
   - Mobile Chrome

2. **Check branding displays:**
   - Header should show: "Vada and Gossip"
   - Subtext should show: "Breakfast, Chat & Bun"

3. **Check password protection:**
   - Click Settings → Should ask for password
   - Click Inventory → Should ask for password
   - Click Statistics → Should ask for password
   - POS screen → Should be freely accessible (no password)

4. **Check receipts:**
   - Print a test receipt
   - Verify business name and address appear correctly
   - Verify logo displays if configured

---

## 🆘 Troubleshooting

### **"Figma Preview has different branding than Chrome!"**
→ Export from Chrome, Import to Figma Preview

### **"Password works on laptop but not on mobile!"**
→ Check the ENVIRONMENT_SYNC guide - mobile has separate localStorage  
→ Import config to mobile, then SET PASSWORD manually (passwords don't export)

### **"Tagline shows 'Breakfast Chat Bun' instead of 'Breakfast, Chat & Bun'"**
→ Old saved config - Go to Settings → Business Identity → Update address field

### **"Logo doesn't show on receipts"**
→ Settings → Receipt Settings → Logo Settings → Enable & Upload

---

## 💡 Pro Tips

### **Backup Strategy:**
- Export weekly to `vada-gossip-backup-YYYY-MM-DD.json`
- Keep backups in cloud storage
- Helps recover from data loss

### **Multi-Device Setup:**
- Main Terminal: Set password "terminal123"
- Manager Device: Set password "manager123"
- Each has different password for accountability

### **Testing New Features:**
- Use Figma Preview for testing
- Export/Import to production when ready
- Keeps live terminal stable

---

## 📞 Support

Need help syncing your environments?
1. Export your current config
2. Share the steps you've tried
3. Mention which environments are out of sync

**Remember:** Each browser environment is completely independent - they communicate only through Export/Import!
