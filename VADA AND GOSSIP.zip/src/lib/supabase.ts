import { createClient } from '@supabase/supabase-js';

// Safely get environment variables with fallbacks
const getEnvVar = (key: string): string => {
  try {
    // Try import.meta.env first (Vite)
    if (typeof import.meta !== 'undefined' && import.meta.env) {
      return import.meta.env[key] || '';
    }
    // Fallback to process.env (Node/other bundlers)
    if (typeof process !== 'undefined' && process.env) {
      return process.env[key] || '';
    }
  } catch (error) {
    console.warn(`Failed to get environment variable ${key}:`, error);
  }
  return '';
};

// Supabase client configuration
const supabaseUrl = getEnvVar('VITE_SUPABASE_URL');
const supabaseAnonKey = getEnvVar('VITE_SUPABASE_ANON_KEY');

// Only create client if credentials are available
export const supabase = supabaseUrl && supabaseAnonKey 
  ? createClient(supabaseUrl, supabaseAnonKey)
  : null;

// Helper to check if Supabase is configured
export const isSupabaseConfigured = () => {
  return supabase !== null;
};

// Database Types
export interface Database {
  public: {
    Tables: {
      tenants: {
        Row: {
          id: string;
          name: string;
          subdomain: string;
          custom_domain: string | null;
          logo_url: string | null;
          primary_color: string;
          subscription_tier: 'free' | 'pro' | 'enterprise';
          subscription_status: 'active' | 'trial' | 'cancelled' | 'expired';
          subscription_end_date: string | null;
          stripe_customer_id: string | null;
          stripe_subscription_id: string | null;
          monthly_order_limit: number;
          orders_this_month: number;
          created_at: string;
          updated_at: string;
        };
      };
      menu_items: {
        Row: {
          id: string;
          tenant_id: string;
          name: string;
          price: number;
          category: string;
          is_quick_add: boolean;
          sort_order: number;
          created_at: string;
          updated_at: string;
        };
      };
      orders: {
        Row: {
          id: string;
          tenant_id: string;
          order_number: string;
          items: any;
          subtotal: number;
          tax: number;
          discount: number;
          fees: number;
          total: number;
          status: 'active' | 'paid' | 'voided';
          payment_method: string | null;
          created_by: string;
          created_at: string;
          paid_at: string | null;
          voided_at: string | null;
          voided_reason: string | null;
          is_synced: boolean;
        };
      };
      audit_logs: {
        Row: {
          id: string;
          tenant_id: string;
          user_id: string;
          user_email: string;
          action: string;
          entity_type: string;
          entity_id: string;
          old_value: any | null;
          new_value: any | null;
          ip_address: string | null;
          user_agent: string | null;
          created_at: string;
        };
      };
      daily_settlements: {
        Row: {
          id: string;
          tenant_id: string;
          settlement_date: string;
          total_orders: number;
          total_revenue: number;
          total_cash: number;
          total_card: number;
          total_upi: number;
          created_at: string;
          emailed_at: string | null;
        };
      };
    };
  };
}

// Helper functions
export const getCurrentTenant = async () => {
  if (!supabase) return null;
  
  const { data: { user } } = await supabase.auth.getUser();
  
  if (!user) return null;

  const { data: tenant } = await supabase
    .from('tenants')
    .select('*')
    .eq('id', user.id)
    .single();

  return tenant;
};

export const checkOrderLimit = async (tenantId: string): Promise<{ canCreate: boolean; limit: number; current: number }> => {
  if (!supabase) {
    return { canCreate: true, limit: Infinity, current: 0 };
  }

  const { data: tenant } = await supabase
    .from('tenants')
    .select('subscription_tier, monthly_order_limit, orders_this_month')
    .eq('id', tenantId)
    .single();

  if (!tenant) {
    return { canCreate: true, limit: Infinity, current: 0 };
  }

  const canCreate = tenant.orders_this_month < tenant.monthly_order_limit;

  return {
    canCreate,
    limit: tenant.monthly_order_limit,
    current: tenant.orders_this_month
  };
};

export const incrementOrderCount = async (tenantId: string) => {
  if (!supabase) return;

  const { data: tenant } = await supabase
    .from('tenants')
    .select('orders_this_month')
    .eq('id', tenantId)
    .single();

  if (tenant) {
    await supabase
      .from('tenants')
      .update({ orders_this_month: tenant.orders_this_month + 1 })
      .eq('id', tenantId);
  }
};

// Check if subscription is active
export const isSubscriptionActive = async (tenantId: string): Promise<boolean> => {
  if (!supabase) return true; // Allow all features in demo mode

  const { data: tenant } = await supabase
    .from('tenants')
    .select('subscription_status, subscription_end_date')
    .eq('id', tenantId)
    .single();

  if (!tenant) return true; // Default to true in demo mode

  if (tenant.subscription_status === 'cancelled' || tenant.subscription_status === 'expired') {
    return false;
  }

  if (tenant.subscription_end_date) {
    const endDate = new Date(tenant.subscription_end_date);
    if (endDate < new Date()) {
      return false;
    }
  }

  return true;
};

// Get subscription features
export const getSubscriptionFeatures = (tier: 'free' | 'pro' | 'enterprise') => {
  const features = {
    free: {
      orderLimit: 100,
      multiDevice: false,
      removeWatermark: false,
      whiteLabel: false,
      multiLocation: false,
      prioritySupport: false,
      customDomain: false,
      auditLogs: false,
    },
    pro: {
      orderLimit: Infinity,
      multiDevice: true,
      removeWatermark: true,
      whiteLabel: false,
      multiLocation: false,
      prioritySupport: false,
      customDomain: false,
      auditLogs: true,
    },
    enterprise: {
      orderLimit: Infinity,
      multiDevice: true,
      removeWatermark: true,
      whiteLabel: true,
      multiLocation: true,
      prioritySupport: true,
      customDomain: true,
      auditLogs: true,
    }
  };

  return features[tier];
};