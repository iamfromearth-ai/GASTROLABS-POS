/**
 * Gastrolabs Bluetooth Printer - Type Definitions
 * Platform-agnostic types for Web, Android, iOS Bluetooth printing
 */

// ============================================================================
// DEVICE & DISCOVERY
// ============================================================================

export interface BluetoothDevice {
  id: string; // MAC address or UUID
  name: string;
  rssi?: number;
  paired?: boolean;
  protocol: 'SPP' | 'BLE' | 'UNKNOWN';
  vendorHint?: 'EPSON' | 'STAR' | 'GENERIC_POS' | 'UNKNOWN';
}

export interface ScanOptions {
  /** Duration in ms (default: 10000) */
  durationMs?: number;
  /** Filter by name patterns */
  nameFilters?: string[];
  /** Service UUIDs for BLE filtering */
  serviceUUIDs?: string[];
  /** Include already paired devices */
  includePaired?: boolean;
}

export interface PairResult {
  success: boolean;
  deviceId: string;
  alreadyPaired?: boolean;
  requiresPin?: boolean;
  error?: BluetoothError;
}

// ============================================================================
// CONNECTION & SESSION
// ============================================================================

export type ConnectionState = 
  | 'IDLE'
  | 'SCANNING'
  | 'PAIRED'
  | 'CONNECTING'
  | 'CONNECTED'
  | 'PRINTING'
  | 'DISCONNECTED'
  | 'RETRYING'
  | 'HARD_FAIL';

export interface ConnectionOptions {
  protocol: 'SPP' | 'BLE';
  charset?: 'UTF-8' | 'ISO-8859-1';
  /** Enable auto-reconnect on connection loss */
  autoReconnect?: boolean;
  /** Keep-alive interval in ms (default: 25000) */
  keepAliveMs?: number;
}

export interface Session {
  id: string;
  deviceId: string;
  protocol: 'SPP' | 'BLE';
  state: ConnectionState;
  connectedAt: string; // ISO date
  lastSeenAt: string; // ISO date
  charset: string;
  autoReconnect: boolean;
}

// ============================================================================
// PRINTER STATUS
// ============================================================================

export interface PrinterStatus {
  connected: boolean;
  rssi?: number;
  battery?: number;
  paperOut?: boolean;
  coverOpen?: boolean;
  tempHigh?: boolean;
  lastError?: string;
  lastSeenAt: string; // ISO date
  bufferBusy?: boolean;
}

// ============================================================================
// PRINT JOB
// ============================================================================

export type PaperWidth = '58mm' | '80mm';
export type CutType = 'partial' | 'full' | null;
export type TextAlign = 'left' | 'center' | 'right';

export interface QRCodeOptions {
  data: string;
  size?: number; // 1-16, default 6
  eccLevel?: 'L' | 'M' | 'Q' | 'H'; // default 'M'
}

export interface EscPosCommand {
  type: 'INIT' | 'TEXT' | 'BOLD' | 'ALIGN' | 'QR' | 'LINE' | 'CUT' | 'RAW';
  data?: string | Uint8Array;
  align?: TextAlign;
  bold?: boolean;
  qr?: QRCodeOptions;
  cutType?: CutType;
}

export interface PrintJob {
  /** Unique job ID */
  jobId?: string;
  /** Associated order ID for traceability */
  orderId?: string;
  /** Character encoding */
  encoding?: 'UTF-8' | 'ISO-8859-1';
  /** Paper width */
  width: PaperWidth;
  /** Pre-rendered ESC/POS bytes (preferred) or high-level commands */
  payload?: Uint8Array;
  commands?: EscPosCommand[];
  /** Timeout in ms (default: 5000) */
  timeoutMs?: number;
  /** Cut paper after print */
  cut?: CutType;
  /** QR code to print at end */
  qr?: QRCodeOptions;
  /** Checksum for integrity (optional) */
  checksum?: string;
}

export interface JobResult {
  jobId: string;
  success: boolean;
  bytesSent: number;
  durationMs: number;
  printerAck?: boolean;
  error?: BluetoothError;
  timestamp: string; // ISO date
}

export type JobState = 'QUEUED' | 'SENDING' | 'DONE' | 'FAILED' | 'FAILED_TRANSIENT';

export interface QueuedJob {
  job: PrintJob;
  state: JobState;
  enqueuedAt: string;
  attempts: number;
  result?: JobResult;
}

// ============================================================================
// ERROR HANDLING
// ============================================================================

export type BluetoothErrorCode =
  | 'BT_UNAVAILABLE'
  | 'FEATURE_UNAVAILABLE'
  | 'PERMISSION_DENIED'
  | 'SCAN_TIMEOUT'
  | 'PAIR_FAILED'
  | 'CONNECT_FAILED'
  | 'GATT_TIMEOUT'
  | 'RFCOMM_RESET'
  | 'LINK_LOSS'
  | 'BUFFER_BUSY'
  | 'WRITE_TIMEOUT'
  | 'MFI_REQUIRED'
  | 'UNSUPPORTED_PROTOCOL'
  | 'NO_SERVICE_CHAR'
  | 'NO_SPP_CHANNEL'
  | 'BUSY'
  | 'DEVICE_NOT_FOUND'
  | 'SESSION_NOT_FOUND'
  | 'INVALID_JOB';

export interface BluetoothError {
  code: BluetoothErrorCode;
  message: string;
  recoverable: boolean;
  hint: string;
  details?: any;
}

// ============================================================================
// DIAGNOSTICS
// ============================================================================

export type DiagnosticEventType =
  | 'SCAN_START'
  | 'SCAN_END'
  | 'DEVICE_FOUND'
  | 'PAIRED'
  | 'CONNECTED'
  | 'WRITE_CHUNK'
  | 'TIMEOUT'
  | 'RETRY'
  | 'DISCONNECTED'
  | 'ERROR';

export interface DiagnosticEvent {
  timestamp: string; // ISO date
  type: DiagnosticEventType;
  deviceId?: string;
  sessionId?: string;
  jobId?: string;
  message: string;
  data?: any;
}

export interface DiagnosticsSnapshot {
  platform: string;
  appVersion: string;
  events: DiagnosticEvent[];
  activeConnections: number;
  totalJobsProcessed: number;
  totalErrors: number;
  exportedAt: string; // ISO date
}

// ============================================================================
// PLATFORM DETECTION
// ============================================================================

export type Platform = 'web' | 'android' | 'ios' | 'unknown';

export interface PlatformCapabilities {
  platform: Platform;
  hasBluetooth: boolean;
  hasBluetoothLE: boolean;
  hasClassicBluetooth: boolean;
  hasWebBluetooth: boolean;
  requiresMFi: boolean;
  canBackgroundReconnect: boolean;
}

// ============================================================================
// SERVICE INTERFACE
// ============================================================================

export interface IBluetoothPrinterService {
  // Discovery & Pairing
  scan(options?: ScanOptions): Promise<BluetoothDevice[]>;
  pair(deviceId: string): Promise<PairResult>;
  
  // Connection Management
  connect(deviceId: string, options: ConnectionOptions): Promise<Session>;
  disconnect(sessionId: string): Promise<void>;
  getSession(sessionId: string): Session | null;
  
  // Printing
  print(sessionId: string, job: PrintJob): Promise<JobResult>;
  
  // Status & Monitoring
  getStatus(sessionId: string): Promise<PrinterStatus>;
  
  // Diagnostics
  getDiagnostics(): DiagnosticsSnapshot;
  exportDiagnostics(): string; // JSON string
  
  // Platform Info
  getPlatformCapabilities(): PlatformCapabilities;
}

// ============================================================================
// VENDOR-SPECIFIC CONSTANTS
// ============================================================================

export const VENDOR_FILTERS = {
  EPSON: ['TM-', 'ePOS', 'Epson'],
  STAR: ['Star', 'mC-Print', 'SM-', 'TSP'],
  GENERIC_POS: ['POS-', 'RP', 'Printer', 'BT-', 'Thermal'],
};

export const BLE_SERVICE_UUIDS = {
  // Generic GATT Printer Service
  GENERIC_PRINTER: '000018f0-0000-1000-8000-00805f9b34fb',
  // Epson ePOS
  EPSON_EPOS: '00001800-0000-1000-8000-00805f9b34fb',
  // Star PRNT
  STAR_PRNT: '00000001-1000-1000-8000-00805f9b0131',
};

export const SPP_UUID = '00001101-0000-1000-8000-00805f9b34fb'; // Serial Port Profile

// ============================================================================
// RETRY POLICY
// ============================================================================

export interface RetryPolicy {
  maxAttempts: number;
  backoffMs: number[]; // [1000, 2000, 4000, 8000, 16000]
  transientErrors: BluetoothErrorCode[];
}

export const DEFAULT_RETRY_POLICY: RetryPolicy = {
  maxAttempts: 5,
  backoffMs: [1000, 2000, 4000, 8000, 16000],
  transientErrors: [
    'GATT_TIMEOUT',
    'RFCOMM_RESET',
    'LINK_LOSS',
    'BUFFER_BUSY',
    'WRITE_TIMEOUT',
  ],
};
