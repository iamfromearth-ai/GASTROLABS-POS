import { supabase } from './supabase';
import { Order } from '../App';

interface PendingAction {
  id: string;
  type: 'create_order' | 'update_order' | 'create_item' | 'update_item' | 'delete_item';
  data: any;
  timestamp: Date;
  retryCount: number;
}

class OfflineSyncManager {
  private pendingActions: PendingAction[] = [];
  private isOnline: boolean = navigator.onLine;
  private syncInterval: number | null = null;

  constructor() {
    this.initializeListeners();
    this.loadPendingActions();
  }

  private initializeListeners() {
    window.addEventListener('online', () => {
      this.isOnline = true;
      console.log('🌐 Back online - syncing pending actions...');
      this.syncAll();
    });

    window.addEventListener('offline', () => {
      this.isOnline = false;
      console.log('📴 Offline mode activated');
    });

    // Auto-sync every 30 seconds when online
    this.syncInterval = window.setInterval(() => {
      if (this.isOnline && this.pendingActions.length > 0) {
        this.syncAll();
      }
    }, 30000);
  }

  private loadPendingActions() {
    try {
      const stored = localStorage.getItem('gastrolabs_pending_sync');
      if (stored) {
        this.pendingActions = JSON.parse(stored).map((action: any) => ({
          ...action,
          timestamp: new Date(action.timestamp)
        }));
      }
    } catch (error) {
      console.error('Failed to load pending actions:', error);
      this.pendingActions = [];
    }
  }

  private savePendingActions() {
    try {
      localStorage.setItem('gastrolabs_pending_sync', JSON.stringify(this.pendingActions));
    } catch (error) {
      console.error('Failed to save pending actions:', error);
    }
  }

  addPendingAction(action: Omit<PendingAction, 'id' | 'timestamp' | 'retryCount'>) {
    const pendingAction: PendingAction = {
      ...action,
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      timestamp: new Date(),
      retryCount: 0
    };

    this.pendingActions.push(pendingAction);
    this.savePendingActions();

    console.log(`📝 Queued action: ${action.type}`, pendingAction);

    // Try to sync immediately if online
    if (this.isOnline) {
      this.syncAll();
    }
  }

  async syncAll() {
    if (this.pendingActions.length === 0) return;

    console.log(`🔄 Syncing ${this.pendingActions.length} pending actions...`);

    const actionsToSync = [...this.pendingActions];
    const successfulIds: string[] = [];

    for (const action of actionsToSync) {
      try {
        await this.syncAction(action);
        successfulIds.push(action.id);
        console.log(`✅ Synced: ${action.type}`);
      } catch (error) {
        console.error(`❌ Sync failed for ${action.type}:`, error);
        
        // Increment retry count
        const actionIndex = this.pendingActions.findIndex(a => a.id === action.id);
        if (actionIndex !== -1) {
          this.pendingActions[actionIndex].retryCount++;
          
          // Remove action if retry count exceeds limit
          if (this.pendingActions[actionIndex].retryCount > 5) {
            console.error(`🗑️ Removing action after 5 failed attempts: ${action.type}`);
            this.pendingActions.splice(actionIndex, 1);
          }
        }
      }
    }

    // Remove successful actions
    this.pendingActions = this.pendingActions.filter(
      action => !successfulIds.includes(action.id)
    );

    this.savePendingActions();

    if (this.pendingActions.length === 0) {
      console.log('✨ All actions synced successfully');
    } else {
      console.log(`⏳ ${this.pendingActions.length} actions still pending`);
    }
  }

  private async syncAction(action: PendingAction) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('No authenticated user');

    const tenantId = user.id;

    switch (action.type) {
      case 'create_order':
        const orderData = {
          ...action.data,
          tenant_id: tenantId,
          is_synced: true
        };
        
        const { error: orderError } = await supabase
          .from('orders')
          .insert(orderData);

        if (orderError) throw orderError;
        break;

      case 'update_order':
        const { error: updateError } = await supabase
          .from('orders')
          .update({
            ...action.data,
            is_synced: true
          })
          .eq('id', action.data.id)
          .eq('tenant_id', tenantId);

        if (updateError) throw updateError;
        break;

      case 'create_item':
        const { error: itemError } = await supabase
          .from('menu_items')
          .insert({
            ...action.data,
            tenant_id: tenantId
          });

        if (itemError) throw itemError;
        break;

      case 'update_item':
        const { error: itemUpdateError } = await supabase
          .from('menu_items')
          .update(action.data)
          .eq('id', action.data.id)
          .eq('tenant_id', tenantId);

        if (itemUpdateError) throw itemUpdateError;
        break;

      case 'delete_item':
        const { error: deleteError } = await supabase
          .from('menu_items')
          .delete()
          .eq('id', action.data.id)
          .eq('tenant_id', tenantId);

        if (deleteError) throw deleteError;
        break;

      default:
        throw new Error(`Unknown action type: ${action.type}`);
    }
  }

  getPendingCount() {
    return this.pendingActions.length;
  }

  isOfflineMode() {
    return !this.isOnline;
  }

  clearPendingActions() {
    this.pendingActions = [];
    this.savePendingActions();
  }

  destroy() {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
    }
  }
}

// Singleton instance
export const offlineSyncManager = new OfflineSyncManager();

// Hook for components
export const useOfflineSync = () => {
  return {
    isOffline: offlineSyncManager.isOfflineMode(),
    pendingCount: offlineSyncManager.getPendingCount(),
    addPendingAction: (action: Omit<PendingAction, 'id' | 'timestamp' | 'retryCount'>) => 
      offlineSyncManager.addPendingAction(action),
    syncAll: () => offlineSyncManager.syncAll()
  };
};
