/**
 * Gastrolabs Bluetooth Printer - Integration Examples
 * 
 * This file contains code examples for integrating the Bluetooth printer
 * module into the Gastrolabs POS application.
 * 
 * DO NOT import this file directly - these are reference examples only.
 */

import { bluetoothPrinter, BluetoothDevice, Session, PrintJob } from './bluetooth-printer';
import { ReceiptBuilder } from './escpos-renderer';
import { toast } from 'sonner@2.0.3';

// ============================================================================
// EXAMPLE 1: Basic Print Flow
// ============================================================================

/**
 * Complete flow: Scan → Connect → Print → Disconnect
 */
export async function exampleBasicPrintFlow() {
  try {
    // 1. Check platform capabilities
    const caps = bluetoothPrinter.getPlatformCapabilities();
    if (!caps.hasBluetooth) {
      toast.error('Bluetooth not available on this device');
      return;
    }

    // 2. Scan for devices
    toast.info('Scanning for printers...');
    const devices = await bluetoothPrinter.scan({
      durationMs: 10000,
      nameFilters: ['POS', 'Printer', 'TM-', 'Star'],
    });

    if (devices.length === 0) {
      toast.error('No printers found. Make sure your printer is on and in pairing mode.');
      return;
    }

    // 3. Let user select device (or auto-select first)
    const selectedDevice = devices[0];
    toast.success(`Found: ${selectedDevice.name}`);

    // 4. Pair if needed
    const pairResult = await bluetoothPrinter.pair(selectedDevice.id);
    if (!pairResult.success) {
      toast.error('Failed to pair with printer');
      return;
    }

    // 5. Connect
    toast.info('Connecting...');
    const session = await bluetoothPrinter.connect(selectedDevice.id, {
      protocol: 'BLE',
      autoReconnect: true,
      keepAliveMs: 25000,
    });

    toast.success('Connected!');

    // 6. Print receipt
    const printJob: PrintJob = {
      jobId: `job-${Date.now()}`,
      orderId: 'ORDER-12345',
      width: '58mm',
      encoding: 'UTF-8',
      commands: [
        { type: 'TEXT', data: 'GASTROLABS POS', align: 'center' },
        { type: 'LINE' },
        { type: 'TEXT', data: 'Tea                $10.00', align: 'left' },
        { type: 'TEXT', data: 'Samosa             $15.00', align: 'left' },
        { type: 'LINE' },
        { type: 'TEXT', data: 'TOTAL:            $25.00', align: 'right' },
        { type: 'QR', qr: { data: 'ORDER-12345', size: 6 } },
        { type: 'CUT', cutType: 'full' },
      ],
      timeoutMs: 5000,
    };

    toast.info('Printing...');
    const result = await bluetoothPrinter.print(session.id, printJob);

    if (result.success) {
      toast.success(`Printed ${result.bytesSent} bytes in ${result.durationMs}ms`);
    } else {
      toast.error('Print failed');
    }

    // 7. Disconnect
    await bluetoothPrinter.disconnect(session.id);
  } catch (error: any) {
    console.error('Print error:', error);
    toast.error(error.hint || error.message);
  }
}

// ============================================================================
// EXAMPLE 2: Integration with Existing App.tsx handleCheckout
// ============================================================================

/**
 * Replace existing handleCheckout with Bluetooth printer support
 */
export async function exampleIntegrateWithCheckout(
  billItems: any[],
  calculateTotal: () => number,
  receiptConfig: any,
  clearBill: () => void
) {
  try {
    // Check if Bluetooth printer is connected
    const savedSessionId = localStorage.getItem('bluetoothPrinterSessionId');
    let session: Session | null = null;

    if (savedSessionId) {
      session = bluetoothPrinter.getSession(savedSessionId);
    }

    // If no active session, prompt user to connect
    if (!session) {
      toast.error('No printer connected. Please connect a printer in Settings → Printer Settings');
      return;
    }

    // Generate order ID
    const orderId = Date.now().toString();

    // Build receipt using ReceiptBuilder
    const receipt = new ReceiptBuilder('58mm', 'UTF-8')
      .init()
      .centerBold(receiptConfig.business?.businessName || 'GASTROLABS POS')
      .center(receiptConfig.business?.address || '')
      .line()
      .left(`Date: ${new Date().toLocaleDateString()}`)
      .left(`Time: ${new Date().toLocaleTimeString()}`)
      .line();

    // Add items
    billItems.forEach((item) => {
      const line = `${item.name}`.padEnd(20) + `$${(item.price * item.quantity).toFixed(2)}`.padStart(10);
      receipt.left(line);
    });

    receipt
      .line()
      .rightBold(`TOTAL: $${calculateTotal().toFixed(2)}`)
      .spacing(2)
      .center('Thank you for your visit!')
      .spacing(1)
      .qr(orderId, 6)
      .spacing(2)
      .cut('full');

    const { bytes, checksum } = receipt.buildWithChecksum();

    // Print
    const printJob: PrintJob = {
      jobId: `job-${orderId}`,
      orderId: orderId,
      width: '58mm',
      payload: bytes,
      checksum: checksum,
      timeoutMs: 5000,
    };

    toast.info('Printing receipt...');
    const result = await bluetoothPrinter.print(session.id, printJob);

    if (result.success) {
      toast.success('Receipt printed successfully!');
      
      // Clear bill after successful print
      setTimeout(() => {
        clearBill();
      }, 500);
    } else {
      toast.error('Print failed. Please try again.');
    }
  } catch (error: any) {
    console.error('Checkout print error:', error);
    
    if (error.recoverable) {
      toast.error('Print failed. Retrying...', { duration: 2000 });
      // Could implement retry logic here
    } else {
      toast.error(error.hint || 'Failed to print receipt');
    }
  }
}

// ============================================================================
// EXAMPLE 3: Persistent Connection in Settings
// ============================================================================

/**
 * Save connected session for reuse throughout app
 */
export async function exampleConnectAndSave(deviceId: string) {
  try {
    // Connect with auto-reconnect
    const session = await bluetoothPrinter.connect(deviceId, {
      protocol: 'BLE',
      autoReconnect: true,
      keepAliveMs: 25000,
    });

    // Save session ID for later use
    localStorage.setItem('bluetoothPrinterSessionId', session.id);
    localStorage.setItem('bluetoothPrinterDeviceId', deviceId);

    toast.success('Printer connected and saved!');

    return session;
  } catch (error: any) {
    console.error('Connection error:', error);
    toast.error(error.hint || 'Failed to connect to printer');
    throw error;
  }
}

/**
 * Get or restore saved session
 */
export function exampleGetSavedSession(): Session | null {
  const sessionId = localStorage.getItem('bluetoothPrinterSessionId');
  if (!sessionId) return null;

  return bluetoothPrinter.getSession(sessionId);
}

/**
 * Test print to verify connection
 */
export async function exampleTestPrint() {
  const session = exampleGetSavedSession();
  if (!session) {
    toast.error('No printer connected');
    return;
  }

  try {
    const testReceipt = new ReceiptBuilder('58mm', 'UTF-8')
      .init()
      .centerBold('TEST PRINT')
      .spacing(1)
      .center('Gastrolabs POS')
      .center('Bluetooth Printer Test')
      .spacing(1)
      .left(`Date: ${new Date().toLocaleDateString()}`)
      .left(`Time: ${new Date().toLocaleTimeString()}`)
      .spacing(1)
      .line()
      .spacing(1)
      .center('✓ Connection successful!')
      .spacing(2)
      .cut('full');

    const bytes = testReceipt.build();

    const result = await bluetoothPrinter.print(session.id, {
      jobId: `test-${Date.now()}`,
      width: '58mm',
      payload: bytes,
    });

    if (result.success) {
      toast.success('Test print successful!');
    }
  } catch (error: any) {
    toast.error('Test print failed: ' + (error.hint || error.message));
  }
}

// ============================================================================
// EXAMPLE 4: Monitoring Printer Status
// ============================================================================

/**
 * Periodic status check with alerts
 */
export function exampleStartStatusMonitoring(sessionId: string) {
  const checkStatus = async () => {
    try {
      const status = await bluetoothPrinter.getStatus(sessionId);

      if (!status.connected) {
        toast.warning('Printer disconnected. Attempting to reconnect...');
      }

      if (status.paperOut) {
        toast.error('⚠️ Paper out! Please refill paper.');
      }

      if (status.coverOpen) {
        toast.warning('⚠️ Printer cover is open');
      }

      if (status.bufferBusy) {
        console.log('Printer is busy...');
      }
    } catch (error) {
      console.error('Status check failed:', error);
    }
  };

  // Check every 30 seconds
  const intervalId = setInterval(checkStatus, 30000);

  // Return cleanup function
  return () => clearInterval(intervalId);
}

// ============================================================================
// EXAMPLE 5: React Hook for Bluetooth Printer
// ============================================================================

/**
 * Custom React hook for managing Bluetooth printer state
 * 
 * Usage:
 * ```tsx
 * const { session, isConnected, connect, disconnect, print } = useBluetoothPrinter();
 * ```
 */
/*
import { useState, useEffect } from 'react';

export function useBluetoothPrinter() {
  const [session, setSession] = useState<Session | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [isScanning, setIsScanning] = useState(false);

  // Restore saved session on mount
  useEffect(() => {
    const savedSessionId = localStorage.getItem('bluetoothPrinterSessionId');
    if (savedSessionId) {
      const existingSession = bluetoothPrinter.getSession(savedSessionId);
      if (existingSession) {
        setSession(existingSession);
        setIsConnected(existingSession.state === 'CONNECTED');
      }
    }
  }, []);

  // Monitor session status
  useEffect(() => {
    if (!session) return;

    const checkStatus = async () => {
      try {
        const status = await bluetoothPrinter.getStatus(session.id);
        setIsConnected(status.connected);
      } catch (error) {
        setIsConnected(false);
      }
    };

    const intervalId = setInterval(checkStatus, 5000);
    return () => clearInterval(intervalId);
  }, [session]);

  const scan = async (): Promise<BluetoothDevice[]> => {
    setIsScanning(true);
    try {
      const devices = await bluetoothPrinter.scan({ durationMs: 10000 });
      return devices;
    } finally {
      setIsScanning(false);
    }
  };

  const connect = async (deviceId: string) => {
    const newSession = await bluetoothPrinter.connect(deviceId, {
      protocol: 'BLE',
      autoReconnect: true,
      keepAliveMs: 25000,
    });

    setSession(newSession);
    setIsConnected(true);
    localStorage.setItem('bluetoothPrinterSessionId', newSession.id);

    return newSession;
  };

  const disconnect = async () => {
    if (!session) return;

    await bluetoothPrinter.disconnect(session.id);
    setSession(null);
    setIsConnected(false);
    localStorage.removeItem('bluetoothPrinterSessionId');
  };

  const print = async (job: PrintJob) => {
    if (!session) {
      throw new Error('No printer connected');
    }

    return await bluetoothPrinter.print(session.id, job);
  };

  const testPrint = async () => {
    if (!session) {
      throw new Error('No printer connected');
    }

    const receipt = new ReceiptBuilder('58mm', 'UTF-8')
      .init()
      .centerBold('TEST PRINT')
      .center('Connection successful!')
      .spacing(2)
      .cut('full');

    const bytes = receipt.build();

    return await print({
      jobId: `test-${Date.now()}`,
      width: '58mm',
      payload: bytes,
    });
  };

  return {
    session,
    isConnected,
    isScanning,
    scan,
    connect,
    disconnect,
    print,
    testPrint,
  };
}
*/

// ============================================================================
// EXAMPLE 6: Batch Printing Multiple Orders
// ============================================================================

/**
 * Print multiple receipts in sequence
 */
export async function exampleBatchPrint(orders: any[], sessionId: string) {
  const results = [];

  for (const order of orders) {
    try {
      const receipt = new ReceiptBuilder('58mm', 'UTF-8')
        .init()
        .centerBold('GASTROLABS POS')
        .center(`Order #${order.id}`)
        .line();

      order.items.forEach((item: any) => {
        receipt.left(`${item.name}`.padEnd(20) + `$${item.price}`.padStart(10));
      });

      receipt
        .line()
        .rightBold(`TOTAL: $${order.total}`)
        .spacing(2)
        .qr(order.id, 6)
        .cut('full');

      const bytes = receipt.build();

      const result = await bluetoothPrinter.print(sessionId, {
        jobId: `order-${order.id}`,
        orderId: order.id,
        width: '58mm',
        payload: bytes,
      });

      results.push({ orderId: order.id, success: result.success });
      
      if (result.success) {
        toast.success(`Printed order #${order.id}`);
      }

      // Small delay between prints
      await new Promise(resolve => setTimeout(resolve, 500));
    } catch (error) {
      console.error(`Failed to print order ${order.id}:`, error);
      results.push({ orderId: order.id, success: false });
    }
  }

  const successCount = results.filter(r => r.success).length;
  toast.info(`Batch print complete: ${successCount}/${orders.length} successful`);

  return results;
}

// ============================================================================
// EXAMPLE 7: Export Diagnostics for Support
// ============================================================================

/**
 * Download diagnostics file for troubleshooting
 */
export function exampleExportDiagnostics() {
  const diagnosticsJson = bluetoothPrinter.exportDiagnostics();
  
  // Create download
  const blob = new Blob([diagnosticsJson], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `printer-diagnostics-${Date.now()}.json`;
  a.click();
  URL.revokeObjectURL(url);

  toast.success('Diagnostics exported!');
}

// ============================================================================
// NOTES FOR INTEGRATION
// ============================================================================

/**
 * TO INTEGRATE INTO GASTROLABS POS:
 * 
 * 1. In PrinterSettings.tsx:
 *    - Replace existing Bluetooth scanning with bluetoothPrinter.scan()
 *    - Add "Connect" button that calls bluetoothPrinter.connect()
 *    - Add "Test Print" button that calls exampleTestPrint()
 *    - Save session ID to localStorage on successful connection
 * 
 * 2. In App.tsx handleCheckout:
 *    - Check for saved session using exampleGetSavedSession()
 *    - Use bluetoothPrinter.print() instead of window.print()
 *    - Build receipt using ReceiptBuilder
 *    - Handle errors gracefully with toast notifications
 * 
 * 3. Add status monitoring:
 *    - Use useEffect to start status monitoring when connected
 *    - Show alerts for paper out, cover open, etc.
 * 
 * 4. Add diagnostic export:
 *    - Add button in Settings to export diagnostics
 *    - Useful for troubleshooting customer issues
 * 
 * 5. Platform detection:
 *    - Use getPlatformCapabilities() to show/hide features
 *    - Display appropriate messages for unsupported features
 * 
 * IMPORTANT: No UI changes required - only backend integration!
 */
