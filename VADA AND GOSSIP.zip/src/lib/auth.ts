/**
 * Authentication Utilities for Gastrolabs POS
 * 
 * Provides secure password hashing and session management
 * Works consistently across desktop and mobile browsers
 */

// Hash password using SHA-256
export async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex;
}

// Verify password against stored hash
export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  const passwordHash = await hashPassword(password);
  return passwordHash === hash;
}

// Session management - keeps auth state in memory AND storage
class AuthSession {
  private authenticated: boolean = false;
  private sessionKey: string = 'gastrolabs_auth_session';
  private sessionExpiry: number = 15 * 60 * 1000; // 15 minutes of inactivity
  private lastActivityKey: string = 'gastrolabs_last_activity';

  constructor() {
    // Initialize from sessionStorage (survives page refresh but not tab close)
    // Clear any old localStorage sessions for security
    try {
      localStorage.removeItem(this.sessionKey);
    } catch (error) {
      console.error('Failed to clear old localStorage session:', error);
    }
    
    this.loadSession();
  }

  private loadSession() {
    try {
      // Only check sessionStorage (more secure - clears when tab closes)
      const sessionData = sessionStorage.getItem(this.sessionKey);
      
      if (sessionData) {
        const { authenticated, timestamp } = JSON.parse(sessionData);
        const now = Date.now();
        const timeSinceLastActivity = now - timestamp;
        
        // Check if session is still valid (within 15 minutes of last activity)
        if (authenticated && timeSinceLastActivity < this.sessionExpiry) {
          this.authenticated = true;
          const minutesRemaining = Math.floor((this.sessionExpiry - timeSinceLastActivity) / 60000);
          console.log(`✅ Auth session restored (expires in ${minutesRemaining} min)`);
        } else {
          console.log(`⏰ Auth session expired (inactive for ${Math.floor(timeSinceLastActivity / 60000)} min)`);
          this.clearSession();
        }
      } else {
        console.log('🔐 No active session found - authentication required');
      }
    } catch (error) {
      console.error('Failed to load auth session:', error);
      this.clearSession();
    }
  }

  private saveSession() {
    try {
      const sessionData = {
        authenticated: this.authenticated,
        timestamp: Date.now(),
      };
      
      // Only save to sessionStorage (clears when tab closes)
      // This is more secure and prevents bypassing password on mobile
      sessionStorage.setItem(this.sessionKey, JSON.stringify(sessionData));
      
      console.log('💾 Auth session saved to sessionStorage');
    } catch (error) {
      console.error('Failed to save auth session:', error);
    }
  }

  public authenticate() {
    this.authenticated = true;
    this.saveSession();
    console.log('✅ User authenticated - session saved');
  }

  public logout() {
    this.clearSession();
    console.log('🚪 User logged out');
  }

  private clearSession() {
    this.authenticated = false;
    try {
      sessionStorage.removeItem(this.sessionKey);
      localStorage.removeItem(this.sessionKey);
    } catch (error) {
      console.error('Failed to clear session:', error);
    }
  }

  public isAuthenticated(): boolean {
    // Always check storage in case of page refresh
    if (!this.authenticated) {
      this.loadSession();
    }
    return this.authenticated;
  }

  public extendSession() {
    if (this.authenticated) {
      this.saveSession();
    }
  }
}

// Singleton instance
export const authSession = new AuthSession();

// Get stored password hash
export function getPasswordHash(): string | null {
  try {
    // Try multiple storage locations (mobile browsers are unpredictable)
    const hash = localStorage.getItem('adminPasswordHash') || 
                 sessionStorage.getItem('adminPasswordHash') ||
                 localStorage.getItem('adminPassword'); // Legacy plain-text fallback
    return hash;
  } catch (error) {
    console.error('Failed to get password hash:', error);
    return null;
  }
}

// Set password hash
export async function setPasswordHash(password: string): Promise<void> {
  try {
    const hash = await hashPassword(password);
    
    // Store in multiple locations for reliability
    localStorage.setItem('adminPasswordHash', hash);
    sessionStorage.setItem('adminPasswordHash', hash);
    
    // Remove legacy plain-text password if it exists
    localStorage.removeItem('adminPassword');
    
    console.log('✅ Password hash saved securely');
  } catch (error) {
    console.error('Failed to set password hash:', error);
    throw new Error('Failed to save password');
  }
}

// Check if password is set
export function isPasswordSet(): boolean {
  const hash = getPasswordHash();
  return !!hash;
}

// Migrate legacy plain-text password to hash
export async function migrateLegacyPassword(): Promise<boolean> {
  try {
    const plainPassword = localStorage.getItem('adminPassword');
    if (plainPassword && !localStorage.getItem('adminPasswordHash')) {
      console.log('🔄 Migrating legacy plain-text password to hash...');
      await setPasswordHash(plainPassword);
      localStorage.removeItem('adminPassword');
      console.log('✅ Migration complete');
      return true;
    }
    return false;
  } catch (error) {
    console.error('Failed to migrate legacy password:', error);
    return false;
  }
}