/**
 * Gastrolabs Bluetooth Printer Service
 * Platform-aware Bluetooth connectivity for Web, Android, iOS
 * 
 * Usage Example:
 * ```ts
 * import { bluetoothPrinter } from './lib/bluetooth-printer';
 * 
 * // 1. Check capabilities
 * const caps = bluetoothPrinter.getPlatformCapabilities();
 * if (!caps.hasBluetooth) {
 *   alert('Bluetooth not available');
 *   return;
 * }
 * 
 * // 2. Scan for devices
 * const devices = await bluetoothPrinter.scan({ durationMs: 10000 });
 * console.log('Found devices:', devices);
 * 
 * // 3. Pair (if needed)
 * const pairResult = await bluetoothPrinter.pair(devices[0].id);
 * 
 * // 4. Connect
 * const session = await bluetoothPrinter.connect(devices[0].id, {
 *   protocol: 'BLE',
 *   autoReconnect: true,
 * });
 * 
 * // 5. Print
 * const job: PrintJob = {
 *   width: '58mm',
 *   commands: [
 *     { type: 'TEXT', data: 'Hello World', align: 'center' },
 *     { type: 'QR', qr: { data: 'ORDER-12345' } },
 *     { type: 'CUT', cutType: 'full' },
 *   ],
 * };
 * 
 * const result = await bluetoothPrinter.print(session.id, job);
 * console.log('Print result:', result);
 * 
 * // 6. Get status
 * const status = await bluetoothPrinter.getStatus(session.id);
 * console.log('Printer status:', status);
 * ```
 */

import {
  IBluetoothPrinterService,
  BluetoothDevice,
  ScanOptions,
  PairResult,
  ConnectionOptions,
  Session,
  PrintJob,
  JobResult,
  PrinterStatus,
  DiagnosticsSnapshot,
  PlatformCapabilities,
  Platform,
  ConnectionState,
  QueuedJob,
  JobState,
  BluetoothError,
  BluetoothErrorCode,
  DEFAULT_RETRY_POLICY,
  BLE_SERVICE_UUIDS,
  SPP_UUID,
  VENDOR_FILTERS,
} from './bluetooth-printer-types';
import { renderCommands, EscPosRenderer } from './escpos-renderer';
import { diagnostics } from './bluetooth-printer-diagnostics';

// ============================================================================
// ERROR FACTORY
// ============================================================================

function createError(
  code: BluetoothErrorCode,
  message: string,
  recoverable: boolean,
  hint: string,
  details?: any
): BluetoothError {
  return { code, message, recoverable, hint, details };
}

const ERRORS = {
  BT_UNAVAILABLE: () =>
    createError(
      'BT_UNAVAILABLE',
      'Bluetooth is not available on this device',
      false,
      'This device does not support Bluetooth. Please use a device with Bluetooth capabilities.'
    ),
  FEATURE_UNAVAILABLE: () =>
    createError(
      'FEATURE_UNAVAILABLE',
      'Web Bluetooth is not available in this browser',
      false,
      'Please use Chrome, Edge, or another browser that supports Web Bluetooth API.'
    ),
  PERMISSION_DENIED: () =>
    createError(
      'PERMISSION_DENIED',
      'Bluetooth permission denied',
      false,
      'Please grant Bluetooth permissions in your device settings.'
    ),
  SCAN_TIMEOUT: () =>
    createError(
      'SCAN_TIMEOUT',
      'Device scan timed out',
      true,
      'No devices found. Make sure your printer is powered on and in pairing mode.'
    ),
  CONNECT_FAILED: (details?: any) =>
    createError(
      'CONNECT_FAILED',
      'Failed to connect to device',
      true,
      'Connection failed. Make sure the printer is powered on and in range.',
      details
    ),
  GATT_TIMEOUT: () =>
    createError(
      'GATT_TIMEOUT',
      'GATT operation timed out',
      true,
      'Connection timeout. Please try again.'
    ),
  MFI_REQUIRED: () =>
    createError(
      'MFI_REQUIRED',
      'This printer requires MFi (Made for iPhone) certification',
      false,
      'This printer is not compatible with iOS BLE. Please use an MFi-certified printer or Android device.'
    ),
  SESSION_NOT_FOUND: (sessionId: string) =>
    createError(
      'SESSION_NOT_FOUND',
      `Session ${sessionId} not found`,
      false,
      'The printer session has been closed or does not exist.'
    ),
  BUSY: () =>
    createError(
      'BUSY',
      'Printer is busy processing another job',
      true,
      'Please wait for the current print job to complete.'
    ),
  WRITE_TIMEOUT: () =>
    createError(
      'WRITE_TIMEOUT',
      'Write operation timed out',
      true,
      'Printer did not respond in time. Check printer connection.'
    ),
};

// ============================================================================
// PLATFORM DETECTION
// ============================================================================

function detectPlatform(): Platform {
  if (typeof navigator === 'undefined') return 'unknown';

  const ua = navigator.userAgent.toLowerCase();

  // Check for React Native bridges
  if (typeof (window as any).ReactNativeWebView !== 'undefined') {
    if (ua.includes('android')) return 'android';
    if (ua.includes('iphone') || ua.includes('ipad')) return 'ios';
  }

  // Web environment
  return 'web';
}

// ============================================================================
// WEB BLUETOOTH IMPLEMENTATION (BLE only)
// ============================================================================

class WebBluetoothImpl implements IBluetoothPrinterService {
  private sessions = new Map<string, WebBluetoothSession>();
  private platform: Platform = 'web';

  async scan(options?: ScanOptions): Promise<BluetoothDevice[]> {
    diagnostics.log('SCAN_START', 'Starting Web Bluetooth scan', { data: options });

    if (!navigator.bluetooth) {
      throw ERRORS.FEATURE_UNAVAILABLE();
    }

    try {
      // Check if we're in an iframe (Bluetooth not allowed in iframes)
      if (window !== window.top) {
        throw createError(
          'FEATURE_UNAVAILABLE',
          'Web Bluetooth is not available in embedded contexts (iframes)',
          false,
          'Please open this app in a new browser tab/window to use Bluetooth printing, or use WiFi connection instead.'
        );
      }

      // Check permissions policy before attempting
      try {
        // Test if Bluetooth is allowed by permissions policy
        const testAllowed = await navigator.permissions.query({ 
          name: 'bluetooth' as PermissionName 
        }).catch(() => null);
        
        // If permissions API doesn't support bluetooth, continue anyway
        if (testAllowed && testAllowed.state === 'denied') {
          throw createError(
            'PERMISSION_DENIED',
            'Bluetooth access is denied by browser permissions',
            false,
            'Please enable Bluetooth permissions in your browser settings, or use WiFi connection instead.'
          );
        }
      } catch (permError: any) {
        // Permissions API might not support bluetooth query - that's okay
        console.log('Permissions API check skipped:', permError);
      }

      // Web Bluetooth requires user gesture and only returns one device
      const device = await navigator.bluetooth.requestDevice({
        filters: [
          { services: [BLE_SERVICE_UUIDS.GENERIC_PRINTER] },
          { namePrefix: 'POS' },
          { namePrefix: 'Printer' },
          { namePrefix: 'TM' },
          { namePrefix: 'Star' },
        ],
        optionalServices: Object.values(BLE_SERVICE_UUIDS),
      });

      const btDevice: BluetoothDevice = {
        id: device.id,
        name: device.name || 'Unknown Printer',
        protocol: 'BLE',
        vendorHint: this.detectVendor(device.name || ''),
      };

      diagnostics.log('DEVICE_FOUND', `Found device: ${btDevice.name}`, {
        deviceId: btDevice.id,
      });

      return [btDevice];
    } catch (error: any) {
      diagnostics.log('ERROR', 'Scan failed', { data: error });
      
      // Handle specific SecurityError for permissions policy
      if (error.name === 'SecurityError') {
        if (error.message?.includes('permissions policy') || 
            error.message?.includes('disallowed') ||
            error.message?.includes('iframe')) {
          throw createError(
            'FEATURE_UNAVAILABLE',
            'Bluetooth is blocked by browser security policy',
            false,
            '🔒 SOLUTION: Open this app in a new browser tab (not embedded). Or use WiFi connection instead - it works everywhere!'
          );
        }
        throw createError(
          'PERMISSION_DENIED',
          'Bluetooth access is blocked',
          false,
          '🔒 Please enable Bluetooth permissions in browser settings, or use WiFi connection.'
        );
      }
      
      if (error.name === 'NotFoundError') {
        throw ERRORS.SCAN_TIMEOUT();
      }
      
      if (error.name === 'NotSupportedError') {
        throw createError(
          'FEATURE_UNAVAILABLE',
          'Web Bluetooth is not supported in this browser',
          false,
          '💡 SOLUTION: Use Chrome, Edge, or Opera browser. Or switch to WiFi connection.'
        );
      }
      
      throw ERRORS.CONNECT_FAILED(error);
    }
  }

  async pair(deviceId: string): Promise<PairResult> {
    // Web Bluetooth handles pairing automatically
    diagnostics.log('PAIRED', `Device ${deviceId} paired (automatic)`, { deviceId });
    return { success: true, deviceId, alreadyPaired: true };
  }

  async connect(deviceId: string, options: ConnectionOptions): Promise<Session> {
    diagnostics.log('CONNECTED', `Connecting to ${deviceId}`, {
      deviceId,
      data: options,
    });

    if (options.protocol !== 'BLE') {
      throw createError(
        'UNSUPPORTED_PROTOCOL',
        'Web Bluetooth only supports BLE protocol',
        false,
        'Use BLE protocol for web browsers.'
      );
    }

    const session = new WebBluetoothSession(deviceId, options);
    await session.connect();

    this.sessions.set(session.id, session);
    diagnostics.incrementConnections();

    return session.getSessionInfo();
  }

  async disconnect(sessionId: string): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (!session) {
      throw ERRORS.SESSION_NOT_FOUND(sessionId);
    }

    await session.disconnect();
    this.sessions.delete(sessionId);
    diagnostics.decrementConnections();
  }

  getSession(sessionId: string): Session | null {
    const session = this.sessions.get(sessionId);
    return session ? session.getSessionInfo() : null;
  }

  async print(sessionId: string, job: PrintJob): Promise<JobResult> {
    const session = this.sessions.get(sessionId);
    if (!session) {
      throw ERRORS.SESSION_NOT_FOUND(sessionId);
    }

    return await session.print(job);
  }

  async getStatus(sessionId: string): Promise<PrinterStatus> {
    const session = this.sessions.get(sessionId);
    if (!session) {
      throw ERRORS.SESSION_NOT_FOUND(sessionId);
    }

    return await session.getStatus();
  }

  getDiagnostics(): DiagnosticsSnapshot {
    return diagnostics.getSnapshot();
  }

  exportDiagnostics(): string {
    return diagnostics.exportDiagnostics();
  }

  getPlatformCapabilities(): PlatformCapabilities {
    const hasBT = !!navigator.bluetooth;
    return {
      platform: this.platform,
      hasBluetooth: hasBT,
      hasBluetoothLE: hasBT,
      hasClassicBluetooth: false,
      hasWebBluetooth: hasBT,
      requiresMFi: false,
      canBackgroundReconnect: false,
    };
  }

  private detectVendor(name: string): BluetoothDevice['vendorHint'] {
    const upper = name.toUpperCase();
    for (const [vendor, patterns] of Object.entries(VENDOR_FILTERS)) {
      if (patterns.some((p) => upper.includes(p.toUpperCase()))) {
        return vendor as BluetoothDevice['vendorHint'];
      }
    }
    return 'UNKNOWN';
  }
}

// ============================================================================
// WEB BLUETOOTH SESSION
// ============================================================================

class WebBluetoothSession {
  id: string;
  deviceId: string;
  state: ConnectionState = 'IDLE';
  private device: BluetoothDevice | null = null;
  private server: BluetoothRemoteGATTServer | null = null;
  private characteristic: BluetoothRemoteGATTCharacteristic | null = null;
  private options: ConnectionOptions;
  private connectedAt: Date = new Date();
  private lastSeenAt: Date = new Date();
  private jobQueue: QueuedJob[] = [];
  private activeJobLock = false;
  private reconnectAttempts = 0;

  constructor(deviceId: string, options: ConnectionOptions) {
    this.id = `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    this.deviceId = deviceId;
    this.options = options;
  }

  async connect(): Promise<void> {
    this.state = 'CONNECTING';

    try {
      // Get device (already selected via requestDevice)
      const devices = await navigator.bluetooth.getDevices();
      this.device = devices.find((d) => d.id === this.deviceId) as any;

      if (!this.device) {
        throw ERRORS.CONNECT_FAILED('Device not found');
      }

      // Connect GATT server
      this.server = await (this.device as any).gatt!.connect();

      // Find write characteristic
      const services = await this.server.getPrimaryServices();
      
      for (const service of services) {
        const characteristics = await service.getCharacteristics();
        for (const char of characteristics) {
          if (char.properties.writeWithoutResponse || char.properties.write) {
            this.characteristic = char;
            break;
          }
        }
        if (this.characteristic) break;
      }

      if (!this.characteristic) {
        throw createError(
          'NO_SERVICE_CHAR',
          'No writable characteristic found',
          false,
          'This printer may not be compatible. Try a different printer.'
        );
      }

      this.state = 'CONNECTED';
      this.connectedAt = new Date();
      this.lastSeenAt = new Date();

      diagnostics.log('CONNECTED', `Session ${this.id} connected`, {
        sessionId: this.id,
        deviceId: this.deviceId,
      });

      // Set up disconnect handler
      (this.device as any).gatt!.addEventListener('gattserverdisconnected', () =>
        this.handleDisconnect()
      );

      // Start keep-alive if enabled
      if (this.options.keepAliveMs) {
        this.startKeepAlive();
      }
    } catch (error: any) {
      this.state = 'DISCONNECTED';
      diagnostics.log('ERROR', 'Connection failed', {
        sessionId: this.id,
        data: error,
      });
      throw ERRORS.CONNECT_FAILED(error);
    }
  }

  async disconnect(): Promise<void> {
    if (this.server) {
      this.server.disconnect();
    }
    this.state = 'DISCONNECTED';
    diagnostics.log('DISCONNECTED', `Session ${this.id} disconnected`, {
      sessionId: this.id,
    });
  }

  async print(job: PrintJob): Promise<JobResult> {
    if (this.state !== 'CONNECTED') {
      throw ERRORS.CONNECT_FAILED('Not connected');
    }

    if (this.activeJobLock) {
      throw ERRORS.BUSY();
    }

    this.activeJobLock = true;
    this.state = 'PRINTING';

    const jobId = job.jobId || `job-${Date.now()}`;
    const startTime = Date.now();

    try {
      // Generate bytes
      let bytes: Uint8Array;
      if (job.payload) {
        bytes = job.payload;
      } else if (job.commands) {
        bytes = renderCommands(job.commands, job.width, job.encoding);
      } else {
        throw createError(
          'INVALID_JOB',
          'Job must have either payload or commands',
          false,
          'Provide print data in the job.'
        );
      }

      // Add QR code if specified
      if (job.qr && !job.payload) {
        const qrRenderer = new EscPosRenderer(job.width, job.encoding);
        qrRenderer.setAlign('center');
        qrRenderer.qrCode(job.qr.data, job.qr);
        const qrBytes = qrRenderer.getBytes();
        const combined = new Uint8Array(bytes.length + qrBytes.length);
        combined.set(bytes);
        combined.set(qrBytes, bytes.length);
        bytes = combined;
      }

      // Add cut command if specified
      if (job.cut && !job.payload) {
        const cutRenderer = new EscPosRenderer(job.width, job.encoding);
        cutRenderer.cut(job.cut);
        const cutBytes = cutRenderer.getBytes();
        const combined = new Uint8Array(bytes.length + cutBytes.length);
        combined.set(bytes);
        combined.set(cutBytes, bytes.length);
        bytes = combined;
      }

      // Send in chunks
      await this.writeChunked(bytes, job.timeoutMs || 5000);

      const durationMs = Date.now() - startTime;

      diagnostics.log('WRITE_CHUNK', `Job ${jobId} completed`, {
        jobId,
        sessionId: this.id,
        data: { bytes: bytes.length, durationMs },
      });

      diagnostics.incrementJobsProcessed();

      const result: JobResult = {
        jobId,
        success: true,
        bytesSent: bytes.length,
        durationMs,
        timestamp: new Date().toISOString(),
      };

      this.state = 'CONNECTED';
      this.activeJobLock = false;

      return result;
    } catch (error: any) {
      this.state = 'CONNECTED';
      this.activeJobLock = false;

      diagnostics.log('ERROR', `Job ${jobId} failed`, {
        jobId,
        sessionId: this.id,
        data: error,
      });

      throw ERRORS.WRITE_TIMEOUT();
    }
  }

  async getStatus(): Promise<PrinterStatus> {
    return {
      connected: this.state === 'CONNECTED' || this.state === 'PRINTING',
      lastSeenAt: this.lastSeenAt.toISOString(),
      bufferBusy: this.activeJobLock,
    };
  }

  getSessionInfo(): Session {
    return {
      id: this.id,
      deviceId: this.deviceId,
      protocol: 'BLE',
      state: this.state,
      connectedAt: this.connectedAt.toISOString(),
      lastSeenAt: this.lastSeenAt.toISOString(),
      charset: this.options.charset || 'UTF-8',
      autoReconnect: this.options.autoReconnect || false,
    };
  }

  private async writeChunked(bytes: Uint8Array, timeoutMs: number): Promise<void> {
    const chunkSize = 512; // BLE MTU limit
    const totalChunks = Math.ceil(bytes.length / chunkSize);

    for (let i = 0; i < totalChunks; i++) {
      const start = i * chunkSize;
      const end = Math.min(start + chunkSize, bytes.length);
      const chunk = bytes.slice(start, end);

      if (!this.characteristic) {
        throw ERRORS.CONNECT_FAILED('Characteristic not available');
      }

      await this.characteristic.writeValue(chunk);

      // Flow control: small delay between chunks
      await this.sleep(20);

      diagnostics.log('WRITE_CHUNK', `Chunk ${i + 1}/${totalChunks} sent`, {
        sessionId: this.id,
        data: { size: chunk.length },
      });
    }
  }

  private async handleDisconnect(): Promise<void> {
    this.state = 'DISCONNECTED';
    diagnostics.log('DISCONNECTED', 'Device disconnected', {
      sessionId: this.id,
    });

    if (this.options.autoReconnect && this.reconnectAttempts < DEFAULT_RETRY_POLICY.maxAttempts) {
      await this.attemptReconnect();
    }
  }

  private async attemptReconnect(): Promise<void> {
    this.state = 'RETRYING';
    const backoff = DEFAULT_RETRY_POLICY.backoffMs[this.reconnectAttempts] || 16000;

    diagnostics.log('RETRY', `Reconnecting in ${backoff}ms (attempt ${this.reconnectAttempts + 1})`, {
      sessionId: this.id,
    });

    await this.sleep(backoff);

    try {
      await this.connect();
      this.reconnectAttempts = 0;
    } catch (error) {
      this.reconnectAttempts++;
      if (this.reconnectAttempts >= DEFAULT_RETRY_POLICY.maxAttempts) {
        this.state = 'HARD_FAIL';
        diagnostics.log('ERROR', 'Max reconnection attempts reached', {
          sessionId: this.id,
        });
      } else {
        await this.attemptReconnect();
      }
    }
  }

  private startKeepAlive(): void {
    // Simple keep-alive using harmless status query
    setInterval(async () => {
      if (this.state === 'CONNECTED' && !this.activeJobLock) {
        this.lastSeenAt = new Date();
      }
    }, this.options.keepAliveMs || 25000);
  }

  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}

// ============================================================================
// NATIVE BRIDGE STUBS (Android/iOS)
// ============================================================================

/**
 * Native implementation placeholders
 * These would interface with React Native modules:
 * - react-native-bluetooth-classic (Android SPP)
 * - react-native-ble-plx (Android/iOS BLE)
 */

class NativeBluetoothImpl implements IBluetoothPrinterService {
  private platform: Platform;

  constructor(platform: Platform) {
    this.platform = platform;
  }

  async scan(options?: ScanOptions): Promise<BluetoothDevice[]> {
    // TODO: Implement native bridge call
    throw createError(
      'FEATURE_UNAVAILABLE',
      'Native Bluetooth not implemented yet',
      false,
      'Native implementation requires React Native bridge setup.'
    );
  }

  async pair(deviceId: string): Promise<PairResult> {
    throw createError('FEATURE_UNAVAILABLE', 'Not implemented', false, '');
  }

  async connect(deviceId: string, options: ConnectionOptions): Promise<Session> {
    throw createError('FEATURE_UNAVAILABLE', 'Not implemented', false, '');
  }

  async disconnect(sessionId: string): Promise<void> {}

  getSession(sessionId: string): Session | null {
    return null;
  }

  async print(sessionId: string, job: PrintJob): Promise<JobResult> {
    throw createError('FEATURE_UNAVAILABLE', 'Not implemented', false, '');
  }

  async getStatus(sessionId: string): Promise<PrinterStatus> {
    throw createError('FEATURE_UNAVAILABLE', 'Not implemented', false, '');
  }

  getDiagnostics(): DiagnosticsSnapshot {
    return diagnostics.getSnapshot();
  }

  exportDiagnostics(): string {
    return diagnostics.exportDiagnostics();
  }

  getPlatformCapabilities(): PlatformCapabilities {
    return {
      platform: this.platform,
      hasBluetooth: false,
      hasBluetoothLE: false,
      hasClassicBluetooth: false,
      hasWebBluetooth: false,
      requiresMFi: this.platform === 'ios',
      canBackgroundReconnect: false,
    };
  }
}

// ============================================================================
// FACTORY & SINGLETON
// ============================================================================

function createBluetoothPrinterService(): IBluetoothPrinterService {
  const platform = detectPlatform();

  switch (platform) {
    case 'web':
      return new WebBluetoothImpl();
    case 'android':
    case 'ios':
      return new NativeBluetoothImpl(platform);
    default:
      return new NativeBluetoothImpl('unknown');
  }
}

// ============================================================================
// EXPORTS
// ============================================================================

export const bluetoothPrinter = createBluetoothPrinterService();
export { diagnostics as bluetoothDiagnostics };
export * from './bluetooth-printer-types';
export * from './escpos-renderer';