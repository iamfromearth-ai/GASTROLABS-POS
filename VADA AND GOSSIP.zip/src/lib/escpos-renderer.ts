/**
 * Gastrolabs ESC/POS Command Renderer
 * Deterministic ESC/POS byte sequence generator for 58mm/80mm thermal printers
 */

import { EscPosCommand, PaperWidth, TextAlign, QRCodeOptions, CutType } from './bluetooth-printer-types';

// ============================================================================
// ESC/POS CONSTANTS
// ============================================================================

const ESC = 0x1b;
const GS = 0x1d;
const LF = 0x0a;
const CR = 0x0d;

// ============================================================================
// ESCPOS RENDERER CLASS
// ============================================================================

export class EscPosRenderer {
  private buffer: number[] = [];
  private encoding: 'UTF-8' | 'ISO-8859-1';
  private width: PaperWidth;
  private columns: number;

  constructor(width: PaperWidth = '58mm', encoding: 'UTF-8' | 'ISO-8859-1' = 'UTF-8') {
    this.width = width;
    this.encoding = encoding;
    // 58mm ≈ 32 chars, 80mm ≈ 48 chars (with standard font)
    this.columns = width === '58mm' ? 32 : 48;
  }

  /**
   * Initialize printer: ESC @ (reset)
   */
  init(): this {
    this.buffer.push(ESC, 0x40); // ESC @ - Initialize printer
    return this;
  }

  /**
   * Set character code table
   */
  setCharset(charset: number = 0): this {
    // ESC t n - Select character code table
    // 0 = PC437 (USA, Standard Europe)
    // 16 = WPC1252 (Latin 1)
    this.buffer.push(ESC, 0x74, charset);
    return this;
  }

  /**
   * Set code page
   */
  setCodePage(codePage: number = 0): this {
    // ESC R n - Select international character set
    this.buffer.push(ESC, 0x52, codePage);
    return this;
  }

  /**
   * Add text with optional alignment
   */
  text(text: string, align: TextAlign = 'left'): this {
    // Set alignment
    this.setAlign(align);
    
    // Convert text to bytes
    const bytes = this.encodeText(text);
    this.buffer.push(...bytes);
    
    return this;
  }

  /**
   * Add text line with newline
   */
  line(text: string = '', align: TextAlign = 'left'): this {
    this.text(text, align);
    this.buffer.push(LF);
    return this;
  }

  /**
   * Set text alignment
   */
  setAlign(align: TextAlign): this {
    // ESC a n - Select justification
    // 0 = left, 1 = center, 2 = right
    const alignCode = align === 'left' ? 0 : align === 'center' ? 1 : 2;
    this.buffer.push(ESC, 0x61, alignCode);
    return this;
  }

  /**
   * Enable/disable bold
   */
  bold(enabled: boolean = true): this {
    // ESC E n - Turn emphasized mode on/off
    this.buffer.push(ESC, 0x45, enabled ? 1 : 0);
    return this;
  }

  /**
   * Set font size
   */
  setSize(width: number = 1, height: number = 1): this {
    // GS ! n - Select character size
    // width: 1-8, height: 1-8
    const w = Math.max(1, Math.min(8, width)) - 1;
    const h = Math.max(1, Math.min(8, height)) - 1;
    const size = (w << 4) | h;
    this.buffer.push(GS, 0x21, size);
    return this;
  }

  /**
   * Add horizontal line (dashed)
   */
  dashedLine(): this {
    const line = '-'.repeat(this.columns);
    this.line(line);
    return this;
  }

  /**
   * Add solid horizontal line
   */
  solidLine(): this {
    const line = '='.repeat(this.columns);
    this.line(line);
    return this;
  }

  /**
   * Add spacing (blank lines)
   */
  spacing(lines: number = 1): this {
    for (let i = 0; i < lines; i++) {
      this.buffer.push(LF);
    }
    return this;
  }

  /**
   * Print QR code
   */
  qrCode(data: string, options?: QRCodeOptions): this {
    const size = options?.size || 6; // Module size (1-16)
    const eccLevel = options?.eccLevel || 'M'; // Error correction level
    
    // Model: GS ( k pL pH cn fn n (model)
    this.buffer.push(GS, 0x28, 0x6b, 0x04, 0x00, 0x31, 0x41, 0x32, 0x00); // Model 2
    
    // Size: GS ( k pL pH cn fn n (size)
    this.buffer.push(GS, 0x28, 0x6b, 0x03, 0x00, 0x31, 0x43, Math.max(1, Math.min(16, size)));
    
    // Error correction: GS ( k pL pH cn fn n (ecc)
    const eccCode = eccLevel === 'L' ? 0x30 : eccLevel === 'M' ? 0x31 : eccLevel === 'Q' ? 0x32 : 0x33;
    this.buffer.push(GS, 0x28, 0x6b, 0x03, 0x00, 0x31, 0x45, eccCode);
    
    // Store data: GS ( k pL pH cn fn m d1...dk
    const dataBytes = this.encodeText(data);
    const dataLen = dataBytes.length + 3;
    const pL = dataLen & 0xff;
    const pH = (dataLen >> 8) & 0xff;
    this.buffer.push(GS, 0x28, 0x6b, pL, pH, 0x31, 0x50, 0x30);
    this.buffer.push(...dataBytes);
    
    // Print: GS ( k pL pH cn fn m
    this.buffer.push(GS, 0x28, 0x6b, 0x03, 0x00, 0x31, 0x51, 0x30);
    
    return this;
  }

  /**
   * Cut paper
   */
  cut(type: CutType = 'full'): this {
    if (!type) return this;
    
    // Feed paper before cut
    this.buffer.push(LF, LF, LF);
    
    // GS V m - Cut paper
    // m = 0: full cut, m = 1: partial cut
    this.buffer.push(GS, 0x56, type === 'full' ? 0x00 : 0x01);
    
    return this;
  }

  /**
   * Add raw bytes
   */
  raw(bytes: Uint8Array | number[]): this {
    this.buffer.push(...Array.from(bytes));
    return this;
  }

  /**
   * Get rendered bytes
   */
  getBytes(): Uint8Array {
    return new Uint8Array(this.buffer);
  }

  /**
   * Clear buffer
   */
  clear(): this {
    this.buffer = [];
    return this;
  }

  /**
   * Encode text to bytes using configured encoding
   */
  private encodeText(text: string): number[] {
    if (this.encoding === 'UTF-8') {
      const encoder = new TextEncoder();
      return Array.from(encoder.encode(text));
    } else {
      // ISO-8859-1 / Latin-1 encoding
      const bytes: number[] = [];
      for (let i = 0; i < text.length; i++) {
        const code = text.charCodeAt(i);
        // ISO-8859-1 is single byte, so just use the lower byte
        bytes.push(code > 255 ? 0x3f : code); // Replace unsupported chars with '?'
      }
      return bytes;
    }
  }

  /**
   * Compute simple checksum for integrity
   */
  static computeChecksum(bytes: Uint8Array): string {
    let sum = 0;
    for (let i = 0; i < bytes.length; i++) {
      sum = (sum + bytes[i]) & 0xffffffff;
    }
    return sum.toString(16).padStart(8, '0');
  }
}

// ============================================================================
// HIGH-LEVEL COMMAND RENDERER
// ============================================================================

/**
 * Render high-level commands to ESC/POS bytes
 */
export function renderCommands(
  commands: EscPosCommand[],
  width: PaperWidth = '58mm',
  encoding: 'UTF-8' | 'ISO-8859-1' = 'UTF-8'
): Uint8Array {
  const renderer = new EscPosRenderer(width, encoding);
  
  renderer.init();
  renderer.setCharset(0);
  renderer.setCodePage(0);
  
  for (const cmd of commands) {
    switch (cmd.type) {
      case 'INIT':
        renderer.init();
        break;
      
      case 'TEXT':
        if (cmd.data && typeof cmd.data === 'string') {
          if (cmd.align) {
            renderer.text(cmd.data, cmd.align);
          } else {
            renderer.text(cmd.data);
          }
        }
        break;
      
      case 'BOLD':
        renderer.bold(cmd.bold !== false);
        break;
      
      case 'ALIGN':
        if (cmd.align) {
          renderer.setAlign(cmd.align);
        }
        break;
      
      case 'QR':
        if (cmd.qr) {
          renderer.qrCode(cmd.qr.data, cmd.qr);
        }
        break;
      
      case 'LINE':
        renderer.dashedLine();
        break;
      
      case 'CUT':
        renderer.cut(cmd.cutType || 'full');
        break;
      
      case 'RAW':
        if (cmd.data instanceof Uint8Array) {
          renderer.raw(cmd.data);
        }
        break;
    }
  }
  
  return renderer.getBytes();
}

// ============================================================================
// RECEIPT BUILDER HELPER
// ============================================================================

/**
 * Helper class for building receipts
 * 
 * Example usage:
 * ```ts
 * const receipt = new ReceiptBuilder('58mm')
 *   .init()
 *   .centerBold('MY SHOP')
 *   .center('123 Main St')
 *   .line()
 *   .left('Item 1          $10.00')
 *   .left('Item 2          $15.00')
 *   .line()
 *   .rightBold('TOTAL: $25.00')
 *   .spacing(2)
 *   .qr('ORDER-12345')
 *   .cut();
 * 
 * const bytes = receipt.build();
 * ```
 */
export class ReceiptBuilder {
  private renderer: EscPosRenderer;

  constructor(width: PaperWidth = '58mm', encoding: 'UTF-8' | 'ISO-8859-1' = 'UTF-8') {
    this.renderer = new EscPosRenderer(width, encoding);
  }

  init(): this {
    this.renderer.init();
    return this;
  }

  left(text: string): this {
    this.renderer.line(text, 'left');
    return this;
  }

  center(text: string): this {
    this.renderer.line(text, 'center');
    return this;
  }

  right(text: string): this {
    this.renderer.line(text, 'right');
    return this;
  }

  leftBold(text: string): this {
    this.renderer.bold(true).line(text, 'left').bold(false);
    return this;
  }

  centerBold(text: string): this {
    this.renderer.bold(true).line(text, 'center').bold(false);
    return this;
  }

  rightBold(text: string): this {
    this.renderer.bold(true).line(text, 'right').bold(false);
    return this;
  }

  line(): this {
    this.renderer.dashedLine();
    return this;
  }

  solidLine(): this {
    this.renderer.solidLine();
    return this;
  }

  spacing(lines: number = 1): this {
    this.renderer.spacing(lines);
    return this;
  }

  qr(data: string, size?: number): this {
    this.renderer.setAlign('center');
    this.renderer.qrCode(data, { data, size });
    return this;
  }

  cut(type: CutType = 'full'): this {
    this.renderer.cut(type);
    return this;
  }

  raw(bytes: Uint8Array): this {
    this.renderer.raw(bytes);
    return this;
  }

  build(): Uint8Array {
    return this.renderer.getBytes();
  }

  buildWithChecksum(): { bytes: Uint8Array; checksum: string } {
    const bytes = this.renderer.getBytes();
    const checksum = EscPosRenderer.computeChecksum(bytes);
    return { bytes, checksum };
  }
}
