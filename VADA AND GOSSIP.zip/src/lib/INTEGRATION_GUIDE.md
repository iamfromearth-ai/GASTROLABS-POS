# Bluetooth Printer Integration Guide

**How to integrate the new Bluetooth printer module into Gastrolabs POS**

## 🎯 Integration Overview

This guide shows how to connect the new `bluetooth-printer` module to your existing POS application **without changing any UI**.

## 📋 Quick Integration Checklist

- [ ] Update `App.tsx` - Replace `handleCheckout` print logic
- [ ] Update `PrinterSettings.tsx` - Add Bluetooth connection management
- [ ] Add session persistence in localStorage
- [ ] Add status monitoring (optional but recommended)
- [ ] Add diagnostic export button in settings (optional)

---

## 1️⃣ Update App.tsx - Replace Print Logic

### Current Code (Window Print):

```typescript
const handleCheckout = () => {
  if (billItems.length > 0) {
    const orderId = Date.now().toString();
    setCurrentOrderId(orderId);
    setPrintPreviewOpen(true);
  }
};

const handleConfirmPrint = async () => {
  // Save order
  const newOrder: Order = {
    id: currentOrderId,
    items: [...billItems],
    total: calculateTotal(),
    timestamp: new Date(),
    status: 'active',
  };
  setOrders((prev) => [newOrder, ...prev]);
  
  // Print with browser
  await handleThermalPrint(currentOrderId);
  
  setTimeout(() => {
    clearBill();
  }, 500);
};
```

### New Code (Bluetooth Printer):

**Step 1:** Add imports at top of `App.tsx`:

```typescript
import { bluetoothPrinter } from './lib/bluetooth-printer';
import { ReceiptBuilder } from './lib/escpos-renderer';
```

**Step 2:** Add state for printer session:

```typescript
// Add near other state declarations
const [printerSession, setPrinterSession] = useState<Session | null>(null);

// Load saved session on mount
useEffect(() => {
  const savedSessionId = localStorage.getItem('gastrolabs_printer_session_id');
  if (savedSessionId) {
    const session = bluetoothPrinter.getSession(savedSessionId);
    if (session && session.state === 'CONNECTED') {
      setPrinterSession(session);
      console.log('✅ Restored printer session:', session.id);
    }
  }
}, []);
```

**Step 3:** Replace `handleConfirmPrint` with Bluetooth printing:

```typescript
const handleConfirmPrint = async () => {
  // Save order first (fraud-proof billing)
  const newOrder: Order = {
    id: currentOrderId,
    items: [...billItems],
    total: calculateTotal(),
    timestamp: new Date(),
    status: 'active',
  };
  setOrders((prev) => [newOrder, ...prev]);
  
  // Check if Bluetooth printer is connected
  const sessionId = localStorage.getItem('gastrolabs_printer_session_id');
  const session = sessionId ? bluetoothPrinter.getSession(sessionId) : null;
  
  if (!session || session.state !== 'CONNECTED') {
    // Fallback to browser print if no Bluetooth printer
    console.log('⚠️ No Bluetooth printer, using browser print');
    await handleThermalPrint(currentOrderId);
    setTimeout(() => clearBill(), 500);
    return;
  }

  // Build receipt using ReceiptBuilder
  try {
    toast.info('📄 Preparing receipt...');
    
    const receipt = new ReceiptBuilder('58mm', 'UTF-8')
      .init()
      .centerBold(receiptConfig.business?.businessName || 'GASTROLABS POS')
      .center(receiptConfig.business?.address || '')
      .spacing(1)
      .left(`Date: ${new Date().toLocaleDateString('en-GB')}`)
      .left(`Time: ${new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}`)
      .line();

    // Add items
    billItems.forEach((item) => {
      const itemLine = `${item.name}`.padEnd(20).substring(0, 20);
      const qtyPrice = `${item.quantity}x${item.price}`.padStart(10);
      receipt.left(itemLine + qtyPrice);
    });

    receipt
      .line()
      .spacing(1)
      .rightBold(`TOTAL: Rs ${calculateTotal()}`)
      .spacing(2)
      .center('═══ PAY USING UPI ═══')
      .spacing(1);

    // Add UPI QR if configured
    if (receiptConfig.paymentQR?.imageUrl || receiptConfig.qrCode?.upiId) {
      const upiId = receiptConfig.qrCode?.upiId || 'your-upi@bank';
      const upiString = `upi://pay?pa=${upiId}&am=${calculateTotal()}&cu=INR`;
      receipt.qr(upiString, 6);
    }

    receipt
      .spacing(2)
      .center('THANK YOU AND COME AGAIN!')
      .spacing(1)
      .left(`Order ID: #${currentOrderId.slice(-6)}`)
      .spacing(2)
      .cut('full');

    const { bytes, checksum } = receipt.buildWithChecksum();

    // Print via Bluetooth
    toast.info('🖨️ Printing receipt...');
    
    const result = await bluetoothPrinter.print(session.id, {
      jobId: `job-${currentOrderId}`,
      orderId: currentOrderId,
      width: '58mm',
      payload: bytes,
      checksum: checksum,
      timeoutMs: 5000,
    });

    if (result.success) {
      toast.success(`✅ Receipt printed! (${result.bytesSent} bytes in ${result.durationMs}ms)`);
      setTimeout(() => clearBill(), 500);
    } else {
      toast.error('❌ Print failed. Please try again.');
    }
  } catch (error: any) {
    console.error('Print error:', error);
    
    if (error.recoverable) {
      toast.warning('⚠️ Print failed. Retrying...', { duration: 2000 });
      // Could retry here
    } else {
      toast.error(error.hint || '❌ Failed to print. Please check printer connection.');
    }
    
    // Fallback to browser print
    toast.info('📄 Opening browser print as fallback...');
    await handleThermalPrint(currentOrderId);
    setTimeout(() => clearBill(), 500);
  }
};
```

---

## 2️⃣ Update PrinterSettings.tsx - Add Connection Management

**Step 1:** Add imports at top:

```typescript
import { bluetoothPrinter, BluetoothDevice, Session } from '../lib/bluetooth-printer';
```

**Step 2:** Add state for Bluetooth session:

```typescript
const [bluetoothSession, setBluetoothSession] = useState<Session | null>(null);
const [bluetoothDevices, setBluetoothDevices] = useState<BluetoothDevice[]>([]);

// Check for existing session on mount
useEffect(() => {
  const sessionId = localStorage.getItem('gastrolabs_printer_session_id');
  if (sessionId) {
    const session = bluetoothPrinter.getSession(sessionId);
    if (session) {
      setBluetoothSession(session);
    }
  }
}, []);
```

**Step 3:** Replace Bluetooth scanning function:

```typescript
const scanForDevices = async () => {
  setIsScanning(true);
  setDiscoveredDevices([]);
  setBluetoothDevices([]);
  setShowManualEntry(false);
  setPrintStatus({ type: null, message: '' });

  try {
    if (config.connectionType === 'bluetooth') {
      // Check platform capabilities
      const caps = bluetoothPrinter.getPlatformCapabilities();
      
      if (!caps.hasBluetooth) {
        setPrintStatus({
          type: 'error',
          message: '📱 Bluetooth not available on this device.\n\n💡 TIP: Use WiFi connection instead!'
        });
        setIsScanning(false);
        setShowManualEntry(true);
        return;
      }

      // Scan for printers
      toast.info('🔍 Scanning for printers...');
      
      const devices = await bluetoothPrinter.scan({
        durationMs: 10000,
        nameFilters: ['POS', 'Printer', 'TM-', 'Star', 'Epson'],
      });

      setBluetoothDevices(devices);

      if (devices.length === 0) {
        setPrintStatus({
          type: 'success',
          message: '🔍 No printers found.\n\nMake sure your printer is:\n• Powered on\n• In pairing mode\n• Within 10 meters'
        });
        setShowManualEntry(true);
      } else {
        setPrintStatus({
          type: 'success',
          message: `✅ Found ${devices.length} printer(s)!`
        });
        
        // Convert to DiscoveredDevice format for UI
        const discovered: DiscoveredDevice[] = devices.map(d => ({
          id: d.id,
          name: d.name,
          address: d.id,
          type: 'bluetooth',
          status: 'available',
        }));
        
        setDiscoveredDevices(discovered);
      }
    }
    // ... keep existing WiFi/USB logic
  } catch (error: any) {
    console.error('Scan error:', error);
    
    setPrintStatus({
      type: 'error',
      message: error.hint || '❌ Failed to scan for devices'
    });
    setShowManualEntry(true);
  } finally {
    setIsScanning(false);
  }
};
```

**Step 4:** Add connect function:

```typescript
const connectToPrinter = async (deviceId: string) => {
  try {
    toast.info('🔗 Connecting to printer...');

    // Pair first
    const pairResult = await bluetoothPrinter.pair(deviceId);
    if (!pairResult.success) {
      toast.error('❌ Failed to pair with printer');
      return;
    }

    // Connect
    const session = await bluetoothPrinter.connect(deviceId, {
      protocol: 'BLE',
      charset: config.encoding === 'UTF-8' ? 'UTF-8' : 'ISO-8859-1',
      autoReconnect: true,
      keepAliveMs: 25000,
    });

    // Save session
    setBluetoothSession(session);
    localStorage.setItem('gastrolabs_printer_session_id', session.id);
    localStorage.setItem('gastrolabs_printer_device_id', deviceId);

    toast.success('✅ Printer connected!');
    
    setPrintStatus({
      type: 'success',
      message: '✅ Printer connected successfully!\n\nYou can now print receipts from the POS screen.'
    });
  } catch (error: any) {
    console.error('Connection error:', error);
    toast.error(error.hint || '❌ Failed to connect to printer');
    
    setPrintStatus({
      type: 'error',
      message: error.hint || '❌ Connection failed'
    });
  }
};

const disconnectPrinter = async () => {
  if (!bluetoothSession) return;

  try {
    await bluetoothPrinter.disconnect(bluetoothSession.id);
    setBluetoothSession(null);
    localStorage.removeItem('gastrolabs_printer_session_id');
    toast.success('✅ Printer disconnected');
  } catch (error) {
    console.error('Disconnect error:', error);
    toast.error('❌ Failed to disconnect');
  }
};
```

**Step 5:** Add test print function:

```typescript
const testPrint = async () => {
  if (!bluetoothSession) {
    toast.error('❌ No printer connected');
    return;
  }

  try {
    toast.info('🖨️ Sending test print...');

    const testReceipt = new ReceiptBuilder('58mm', 'UTF-8')
      .init()
      .centerBold('TEST PRINT')
      .spacing(1)
      .center('Gastrolabs POS')
      .center('Bluetooth Printer Test')
      .spacing(1)
      .line()
      .left(`Date: ${new Date().toLocaleDateString()}`)
      .left(`Time: ${new Date().toLocaleTimeString()}`)
      .line()
      .spacing(1)
      .centerBold('✓ CONNECTION SUCCESSFUL!')
      .spacing(2)
      .center('Your printer is ready to use.')
      .spacing(2)
      .cut('full');

    const bytes = testReceipt.build();

    const result = await bluetoothPrinter.print(bluetoothSession.id, {
      jobId: `test-${Date.now()}`,
      width: '58mm',
      payload: bytes,
    });

    if (result.success) {
      toast.success('✅ Test print successful!');
      setPrintStatus({
        type: 'success',
        message: '✅ Test print completed successfully!\n\nYour printer is working correctly.'
      });
    }
  } catch (error: any) {
    console.error('Test print error:', error);
    toast.error(error.hint || '❌ Test print failed');
    setPrintStatus({
      type: 'error',
      message: error.hint || '❌ Test print failed'
    });
  }
};
```

**Step 6:** Update the UI to show connection status and buttons:

```typescript
// Add this in the JSX, after the existing scan button:

{config.connectionType === 'bluetooth' && bluetoothDevices.length > 0 && (
  <div className="space-y-2">
    <Label>Discovered Printers</Label>
    {bluetoothDevices.map((device) => (
      <div key={device.id} className="flex items-center justify-between p-3 bg-neutral-50 rounded-lg">
        <div>
          <div className="font-medium">{device.name}</div>
          <div className="text-sm text-neutral-500">{device.vendorHint}</div>
        </div>
        <Button
          onClick={() => connectToPrinter(device.id)}
          size="sm"
          className="bg-[#49842B] hover:bg-[#336A29]"
        >
          Connect
        </Button>
      </div>
    ))}
  </div>
)}

{bluetoothSession && bluetoothSession.state === 'CONNECTED' && (
  <div className="bg-green-50 border border-green-200 p-4 rounded-lg space-y-3">
    <div className="flex items-center gap-2">
      <CheckCircle className="h-5 w-5 text-green-600" />
      <span className="font-medium text-green-900">Printer Connected</span>
    </div>
    
    <div className="flex gap-2">
      <Button
        onClick={testPrint}
        variant="outline"
        size="sm"
        className="flex-1"
      >
        <Printer className="h-4 w-4 mr-2" />
        Test Print
      </Button>
      
      <Button
        onClick={disconnectPrinter}
        variant="outline"
        size="sm"
        className="flex-1"
      >
        Disconnect
      </Button>
    </div>
  </div>
)}
```

---

## 3️⃣ Add Status Monitoring (Recommended)

Add this in `App.tsx` to monitor printer status:

```typescript
// Add state
const [printerStatus, setPrinterStatus] = useState<PrinterStatus | null>(null);

// Add useEffect for status monitoring
useEffect(() => {
  const sessionId = localStorage.getItem('gastrolabs_printer_session_id');
  if (!sessionId) return;

  const checkStatus = async () => {
    try {
      const status = await bluetoothPrinter.getStatus(sessionId);
      setPrinterStatus(status);

      // Alert on issues
      if (status.paperOut) {
        toast.warning('⚠️ Printer paper is out! Please refill.');
      }
      if (status.coverOpen) {
        toast.warning('⚠️ Printer cover is open!');
      }
      if (!status.connected) {
        toast.error('❌ Printer disconnected. Attempting to reconnect...');
      }
    } catch (error) {
      console.error('Status check failed:', error);
    }
  };

  // Check every 30 seconds
  const intervalId = setInterval(checkStatus, 30000);
  
  // Check immediately
  checkStatus();

  return () => clearInterval(intervalId);
}, []);

// Show status indicator in header (optional)
{printerStatus && (
  <div className="flex items-center gap-2">
    {printerStatus.connected ? (
      <CheckCircle className="h-4 w-4 text-green-500" />
    ) : (
      <AlertCircle className="h-4 w-4 text-red-500" />
    )}
    <span className="text-xs">Printer</span>
  </div>
)}
```

---

## 4️⃣ Add Diagnostic Export (Optional)

Add a button in Settings to export diagnostics:

```typescript
// In Settings.tsx or PrinterSettings.tsx

const exportDiagnostics = () => {
  const diagnosticsJson = bluetoothPrinter.exportDiagnostics();
  
  const blob = new Blob([diagnosticsJson], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `printer-diagnostics-${Date.now()}.json`;
  a.click();
  URL.revokeObjectURL(url);

  toast.success('📊 Diagnostics exported!');
};

// Add button in JSX
<Button onClick={exportDiagnostics} variant="outline">
  <Download className="h-4 w-4 mr-2" />
  Export Printer Diagnostics
</Button>
```

---

## 5️⃣ Testing Checklist

### Before Testing:
- [ ] Bluetooth printer is powered on
- [ ] Printer is in pairing mode
- [ ] Printer has paper loaded
- [ ] Using Chrome or Edge browser
- [ ] App is running on HTTPS (or localhost)

### Test Steps:
1. [ ] Go to Settings → Printer Settings
2. [ ] Select "Bluetooth" connection type
3. [ ] Click "Scan for Printers"
4. [ ] Select your printer from the list
5. [ ] Click "Connect"
6. [ ] Click "Test Print" - verify receipt prints
7. [ ] Return to POS screen
8. [ ] Add items to cart
9. [ ] Click checkout (printer icon)
10. [ ] Verify receipt prints via Bluetooth
11. [ ] Test auto-reconnect by turning printer off/on

---

## 🔧 Troubleshooting

### Printer not found during scan
- Ensure printer is powered on
- Put printer in pairing/discoverable mode
- Check printer is within 10 meters
- Try increasing scan duration in code

### Connection fails
- Check browser supports Web Bluetooth (Chrome/Edge)
- Ensure app is on HTTPS (or localhost)
- Try unpairing and re-pairing the device
- Check browser console for error details

### Print doesn't work
- Verify session is connected: `bluetoothPrinter.getSession(sessionId)`
- Check printer status: `await bluetoothPrinter.getStatus(sessionId)`
- Try test print from settings
- Check paper and printer state
- Export diagnostics for detailed logs

### Browser shows "Bluetooth not available"
- Web Bluetooth only works on Chrome, Edge, Opera
- Firefox and Safari don't support Web Bluetooth
- Use WiFi connection as alternative

---

## 📊 Platform Support Matrix

| Platform | BLE | Classic BT | Status |
|----------|-----|------------|--------|
| Web (Chrome/Edge) | ✅ | ❌ | Production Ready |
| Web (Firefox/Safari) | ❌ | ❌ | Use WiFi |
| Android App | ⚠️ | ⚠️ | Needs Native Bridge |
| iOS App | ⚠️ | ❌ | Needs Native Bridge |

---

## 🎯 Summary

**What Changed:**
- ✅ Added Bluetooth printer module (`/lib/bluetooth-printer.ts`)
- ✅ Added ESC/POS renderer (`/lib/escpos-renderer.ts`)
- ✅ Updated `App.tsx` to use Bluetooth printing
- ✅ Updated `PrinterSettings.tsx` to manage connections
- ✅ Added session persistence in localStorage
- ✅ Added status monitoring
- ✅ Added diagnostic export

**What Stayed the Same:**
- ✅ No UI design changes
- ✅ Existing WiFi/USB options still work
- ✅ Browser print fallback still available
- ✅ All existing features preserved

**Benefits:**
- ✅ Reliable Bluetooth connectivity
- ✅ Auto-reconnect on connection loss
- ✅ Professional thermal printer support
- ✅ Detailed error messages with recovery hints
- ✅ Diagnostic logs for troubleshooting
- ✅ ESC/POS rendering for perfect receipts

---

**Need Help?** Check `/lib/BLUETOOTH_PRINTER_README.md` for complete API documentation.

**Questions?** Review `/lib/bluetooth-printer-integration-example.ts` for more examples.
