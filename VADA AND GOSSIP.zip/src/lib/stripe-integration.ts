import { loadStripe, Stripe } from '@stripe/stripe-js';

// Safely get environment variables with fallbacks
const getEnvVar = (key: string): string => {
  try {
    // Try import.meta.env first (Vite)
    if (typeof import.meta !== 'undefined' && import.meta.env) {
      return import.meta.env[key] || '';
    }
    // Fallback to process.env (Node/other bundlers)
    if (typeof process !== 'undefined' && process.env) {
      return process.env[key] || '';
    }
  } catch (error) {
    console.warn(`Failed to get environment variable ${key}:`, error);
  }
  return '';
};

const stripePublishableKey = getEnvVar('VITE_STRIPE_PUBLISHABLE_KEY');

let stripePromise: Promise<Stripe | null>;

export const getStripe = () => {
  if (!stripePromise) {
    stripePromise = loadStripe(stripePublishableKey);
  }
  return stripePromise;
};

export interface SubscriptionPlan {
  id: string;
  name: string;
  tier: 'free' | 'pro' | 'enterprise';
  price: number;
  currency: string;
  interval: 'month' | 'year';
  stripePriceId: string;
  features: string[];
  orderLimit: number;
}

export const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: 'free',
    name: 'Free Plan',
    tier: 'free',
    price: 0,
    currency: 'USD',
    interval: 'month',
    stripePriceId: '',
    features: [
      '100 orders per month',
      'Basic POS features',
      'Single device',
      'Gastrolabs watermark',
      'Email support'
    ],
    orderLimit: 100
  },
  {
    id: 'pro_monthly',
    name: 'Pro Plan (Monthly)',
    tier: 'pro',
    price: 29,
    currency: 'USD',
    interval: 'month',
    stripePriceId: getEnvVar('VITE_STRIPE_PRO_MONTHLY_PRICE_ID'),
    features: [
      'Unlimited orders',
      'Remove watermark',
      'Multi-device sync',
      'Advanced reports',
      'Audit logs',
      'Priority email support'
    ],
    orderLimit: Infinity
  },
  {
    id: 'pro_yearly',
    name: 'Pro Plan (Yearly)',
    tier: 'pro',
    price: 290,
    currency: 'USD',
    interval: 'year',
    stripePriceId: getEnvVar('VITE_STRIPE_PRO_YEARLY_PRICE_ID'),
    features: [
      'Unlimited orders',
      'Remove watermark',
      'Multi-device sync',
      'Advanced reports',
      'Audit logs',
      'Priority email support',
      '2 months free'
    ],
    orderLimit: Infinity
  },
  {
    id: 'enterprise_monthly',
    name: 'Enterprise Plan (Monthly)',
    tier: 'enterprise',
    price: 99,
    currency: 'USD',
    interval: 'month',
    stripePriceId: getEnvVar('VITE_STRIPE_ENTERPRISE_MONTHLY_PRICE_ID'),
    features: [
      'Everything in Pro',
      'Full white-label',
      'Custom domain',
      'Multi-location support',
      'Export branded app',
      'API access',
      'Dedicated support',
      'Custom integrations'
    ],
    orderLimit: Infinity
  },
  {
    id: 'enterprise_yearly',
    name: 'Enterprise Plan (Yearly)',
    tier: 'enterprise',
    price: 990,
    currency: 'USD',
    interval: 'year',
    stripePriceId: getEnvVar('VITE_STRIPE_ENTERPRISE_YEARLY_PRICE_ID'),
    features: [
      'Everything in Pro',
      'Full white-label',
      'Custom domain',
      'Multi-location support',
      'Export branded app',
      'API access',
      'Dedicated support',
      'Custom integrations',
      '2 months free'
    ],
    orderLimit: Infinity
  }
];

export const createCheckoutSession = async (
  priceId: string,
  tenantId: string,
  successUrl: string,
  cancelUrl: string
) => {
  try {
    const response = await fetch('/api/create-checkout-session', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        priceId,
        tenantId,
        successUrl,
        cancelUrl
      })
    });

    const { sessionId } = await response.json();

    const stripe = await getStripe();
    if (!stripe) throw new Error('Stripe failed to load');

    const { error } = await stripe.redirectToCheckout({ sessionId });

    if (error) {
      throw error;
    }
  } catch (error) {
    console.error('Checkout error:', error);
    throw error;
  }
};

export const createPortalSession = async (tenantId: string, returnUrl: string) => {
  try {
    const response = await fetch('/api/create-portal-session', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        tenantId,
        returnUrl
      })
    });

    const { url } = await response.json();

    window.location.href = url;
  } catch (error) {
    console.error('Portal session error:', error);
    throw error;
  }
};

export const getPlanByTier = (tier: 'free' | 'pro' | 'enterprise') => {
  return subscriptionPlans.find(plan => plan.tier === tier && plan.interval === 'month');
};

export const formatPrice = (price: number, currency: string = 'USD') => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency
  }).format(price);
};