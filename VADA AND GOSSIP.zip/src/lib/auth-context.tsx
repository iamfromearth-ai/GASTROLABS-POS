/**
 * Authentication Context for Gastrolabs POS
 * 
 * Provides centralized auth state management that works reliably
 * across desktop and mobile browsers
 */

import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { 
  authSession, 
  isPasswordSet, 
  verifyPassword, 
  getPasswordHash,
  migrateLegacyPassword 
} from './auth';

interface AuthContextType {
  isAuthenticated: boolean;
  isPasswordConfigured: boolean;
  authenticate: (password: string) => Promise<boolean>;
  logout: () => void;
  checkAuth: () => boolean;
  authSession: typeof authSession; // Export authSession
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isPasswordConfigured, setIsPasswordConfigured] = useState(false);

  // Initialize auth state on mount
  useEffect(() => {
    const initAuth = async () => {
      console.log('🔐 Initializing auth context...');
      
      // Migrate legacy plain-text passwords to hashed
      await migrateLegacyPassword();
      
      // Check if password is configured
      const passwordSet = isPasswordSet();
      setIsPasswordConfigured(passwordSet);
      console.log('📋 Password configured:', passwordSet);
      
      // Check existing session (works on both desktop and mobile)
      const sessionAuth = authSession.isAuthenticated();
      setIsAuthenticated(sessionAuth);
      
      console.log('🔐 Auth initialized:', { passwordSet, authenticated: sessionAuth });
    };
    
    initAuth();
    
    // Extend session on user activity (mobile-friendly)
    const activityEvents = ['click', 'touchstart', 'keydown', 'scroll'];
    const handleActivity = () => {
      if (isAuthenticated) {
        authSession.extendSession();
      }
    };
    
    activityEvents.forEach(event => {
      window.addEventListener(event, handleActivity, { passive: true });
    });
    
    return () => {
      activityEvents.forEach(event => {
        window.removeEventListener(event, handleActivity);
      });
    };
  }, [isAuthenticated]);

  const authenticate = async (password: string): Promise<boolean> => {
    try {
      const hash = getPasswordHash();
      
      if (!hash) {
        console.error('❌ No password hash found');
        return false;
      }
      
      const isValid = await verifyPassword(password, hash);
      
      if (isValid) {
        authSession.authenticate();
        setIsAuthenticated(true);
        console.log('✅ Authentication successful');
        return true;
      } else {
        console.log('❌ Invalid password');
        return false;
      }
    } catch (error) {
      console.error('Authentication error:', error);
      return false;
    }
  };

  const logout = () => {
    authSession.logout();
    setIsAuthenticated(false);
    console.log('🚪 Logged out');
  };

  const checkAuth = (): boolean => {
    const authenticated = authSession.isAuthenticated();
    setIsAuthenticated(authenticated);
    return authenticated;
  };

  const value: AuthContextType = {
    isAuthenticated,
    isPasswordConfigured,
    authenticate,
    logout,
    checkAuth,
    authSession, // Include authSession in the context
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

/**
 * Higher-Order Component to protect routes/components
 * Usage: const ProtectedComponent = withAuth(YourComponent);
 */
export function withAuth<P extends object>(
  Component: React.ComponentType<P>,
  options?: {
    onUnauthorized?: () => void;
  }
) {
  return function ProtectedComponent(props: P) {
    const { isAuthenticated, isPasswordConfigured } = useAuth();
    
    // If no password is set, allow access (backward compatibility)
    if (!isPasswordConfigured) {
      return <Component {...props} />;
    }
    
    // If password is set but user is not authenticated, block access
    if (!isAuthenticated) {
      if (options?.onUnauthorized) {
        options.onUnauthorized();
      }
      return null; // Don't render the component
    }
    
    // User is authenticated, render component
    return <Component {...props} />;
  };
}