import { supabase } from './supabase';

export type AuditAction = 
  | 'order.created'
  | 'order.paid'
  | 'order.voided'
  | 'order.printed'
  | 'item.created'
  | 'item.updated'
  | 'item.deleted'
  | 'category.created'
  | 'category.deleted'
  | 'settings.updated'
  | 'data.exported'
  | 'data.imported'
  | 'data.cleared';

export interface AuditLogEntry {
  action: AuditAction;
  entityType: string;
  entityId: string;
  oldValue?: any;
  newValue?: any;
}

class AuditLogger {
  private tenantId: string | null = null;
  private userId: string | null = null;
  private userEmail: string | null = null;

  async initialize() {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (user) {
      this.userId = user.id;
      this.userEmail = user.email || 'unknown';
      this.tenantId = user.id; // In this setup, user ID = tenant ID
    }
  }

  async log(entry: AuditLogEntry) {
    if (!this.tenantId || !this.userId) {
      await this.initialize();
    }

    if (!this.tenantId || !this.userId) {
      console.error('Audit log failed: No authenticated user');
      return;
    }

    const { error } = await supabase
      .from('audit_logs')
      .insert({
        tenant_id: this.tenantId,
        user_id: this.userId,
        user_email: this.userEmail || 'unknown',
        action: entry.action,
        entity_type: entry.entityType,
        entity_id: entry.entityId,
        old_value: entry.oldValue || null,
        new_value: entry.newValue || null,
        ip_address: await this.getIpAddress(),
        user_agent: navigator.userAgent,
      });

    if (error) {
      console.error('Audit log error:', error);
    }
  }

  async getIpAddress(): Promise<string | null> {
    try {
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      return data.ip;
    } catch (error) {
      return null;
    }
  }

  // Bulk log for batch operations
  async logBatch(entries: AuditLogEntry[]) {
    for (const entry of entries) {
      await this.log(entry);
    }
  }

  // Query audit logs
  async getRecentLogs(limit: number = 50) {
    if (!this.tenantId) {
      await this.initialize();
    }

    const { data, error } = await supabase
      .from('audit_logs')
      .select('*')
      .eq('tenant_id', this.tenantId)
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) {
      console.error('Failed to fetch audit logs:', error);
      return [];
    }

    return data || [];
  }

  // Get logs for specific entity
  async getEntityLogs(entityType: string, entityId: string) {
    if (!this.tenantId) {
      await this.initialize();
    }

    const { data, error } = await supabase
      .from('audit_logs')
      .select('*')
      .eq('tenant_id', this.tenantId)
      .eq('entity_type', entityType)
      .eq('entity_id', entityId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Failed to fetch entity logs:', error);
      return [];
    }

    return data || [];
  }

  // Get daily activity summary
  async getDailyActivity(date: string) {
    if (!this.tenantId) {
      await this.initialize();
    }

    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);

    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    const { data, error } = await supabase
      .from('audit_logs')
      .select('action')
      .eq('tenant_id', this.tenantId)
      .gte('created_at', startOfDay.toISOString())
      .lte('created_at', endOfDay.toISOString());

    if (error) {
      console.error('Failed to fetch daily activity:', error);
      return {};
    }

    // Count actions
    const summary: Record<string, number> = {};
    data?.forEach((log) => {
      summary[log.action] = (summary[log.action] || 0) + 1;
    });

    return summary;
  }
}

// Singleton instance
export const auditLogger = new AuditLogger();

// Fraud detection utilities
export const detectSuspiciousActivity = async (tenantId: string) => {
  // Get logs from last 24 hours
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);

  const { data, error } = await supabase
    .from('audit_logs')
    .select('*')
    .eq('tenant_id', tenantId)
    .gte('created_at', yesterday.toISOString());

  if (error || !data) return { suspicious: false, alerts: [] };

  const alerts: string[] = [];

  // Check for excessive deletions
  const deletions = data.filter(log => log.action.includes('deleted'));
  if (deletions.length > 20) {
    alerts.push(`⚠️ High deletion activity: ${deletions.length} items deleted in 24h`);
  }

  // Check for rapid order voids
  const voids = data.filter(log => log.action === 'order.voided');
  if (voids.length > 10) {
    alerts.push(`⚠️ Multiple order voids: ${voids.length} orders voided in 24h`);
  }

  // Check for data exports (potential data theft)
  const exports = data.filter(log => log.action === 'data.exported');
  if (exports.length > 5) {
    alerts.push(`⚠️ Multiple data exports: ${exports.length} exports in 24h`);
  }

  return {
    suspicious: alerts.length > 0,
    alerts
  };
};
