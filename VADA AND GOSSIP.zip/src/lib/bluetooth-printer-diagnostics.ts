/**
 * Gastrolabs Bluetooth Printer - Diagnostics & Logging
 * Ring-buffer event logging for debugging and support
 */

import { DiagnosticEvent, DiagnosticEventType, DiagnosticsSnapshot } from './bluetooth-printer-types';

// ============================================================================
// DIAGNOSTICS LOGGER
// ============================================================================

export class BluetoothPrinterDiagnostics {
  private static instance: BluetoothPrinterDiagnostics;
  private events: DiagnosticEvent[] = [];
  private maxEvents: number = 200; // Ring buffer size
  private totalJobsProcessed: number = 0;
  private totalErrors: number = 0;
  private activeConnections: number = 0;

  private constructor() {}

  static getInstance(): BluetoothPrinterDiagnostics {
    if (!BluetoothPrinterDiagnostics.instance) {
      BluetoothPrinterDiagnostics.instance = new BluetoothPrinterDiagnostics();
    }
    return BluetoothPrinterDiagnostics.instance;
  }

  /**
   * Log a diagnostic event
   */
  log(
    type: DiagnosticEventType,
    message: string,
    meta?: {
      deviceId?: string;
      sessionId?: string;
      jobId?: string;
      data?: any;
    }
  ): void {
    const event: DiagnosticEvent = {
      timestamp: new Date().toISOString(),
      type,
      message,
      ...meta,
    };

    // Ring buffer: remove oldest if at capacity
    if (this.events.length >= this.maxEvents) {
      this.events.shift();
    }

    this.events.push(event);

    // Console logging for development
    const emoji = this.getEventEmoji(type);
    console.log(`${emoji} [BT Printer] ${type}: ${message}`, meta?.data || '');

    // Track stats
    if (type === 'ERROR') {
      this.totalErrors++;
    }
  }

  /**
   * Increment active connection count
   */
  incrementConnections(): void {
    this.activeConnections++;
    this.log('CONNECTED', `Active connections: ${this.activeConnections}`);
  }

  /**
   * Decrement active connection count
   */
  decrementConnections(): void {
    this.activeConnections = Math.max(0, this.activeConnections - 1);
    this.log('DISCONNECTED', `Active connections: ${this.activeConnections}`);
  }

  /**
   * Increment total jobs processed
   */
  incrementJobsProcessed(): void {
    this.totalJobsProcessed++;
  }

  /**
   * Get current statistics
   */
  getStats(): { totalJobs: number; totalErrors: number; activeConnections: number } {
    return {
      totalJobs: this.totalJobsProcessed,
      totalErrors: this.totalErrors,
      activeConnections: this.activeConnections,
    };
  }

  /**
   * Get diagnostics snapshot
   */
  getSnapshot(): DiagnosticsSnapshot {
    return {
      platform: this.detectPlatform(),
      appVersion: this.getAppVersion(),
      events: [...this.events],
      activeConnections: this.activeConnections,
      totalJobsProcessed: this.totalJobsProcessed,
      totalErrors: this.totalErrors,
      exportedAt: new Date().toISOString(),
    };
  }

  /**
   * Export diagnostics as JSON string
   */
  exportDiagnostics(): string {
    const snapshot = this.getSnapshot();
    // Anonymize sensitive data
    const anonymized = {
      ...snapshot,
      events: snapshot.events.map((event) => ({
        ...event,
        deviceId: event.deviceId ? this.anonymizeId(event.deviceId) : undefined,
        sessionId: event.sessionId ? this.anonymizeId(event.sessionId) : undefined,
      })),
    };
    return JSON.stringify(anonymized, null, 2);
  }

  /**
   * Clear all events
   */
  clear(): void {
    this.events = [];
    this.log('SCAN_START', 'Diagnostics cleared');
  }

  /**
   * Get recent errors
   */
  getRecentErrors(count: number = 10): DiagnosticEvent[] {
    return this.events.filter((e) => e.type === 'ERROR').slice(-count);
  }

  /**
   * Detect platform
   */
  private detectPlatform(): string {
    if (typeof navigator === 'undefined') return 'unknown';

    const ua = navigator.userAgent.toLowerCase();
    
    // Check for React Native
    if (typeof (window as any).ReactNativeWebView !== 'undefined') {
      if (ua.includes('android')) return 'android';
      if (ua.includes('iphone') || ua.includes('ipad')) return 'ios';
      return 'react-native';
    }

    // Check for mobile browsers
    if (ua.includes('android')) return 'web-android';
    if (ua.includes('iphone') || ua.includes('ipad')) return 'web-ios';

    return 'web-desktop';
  }

  /**
   * Get app version
   */
  private getAppVersion(): string {
    // Try to get from package.json or environment
    return (window as any).__APP_VERSION__ || '1.0.0';
  }

  /**
   * Anonymize device/session IDs for privacy
   */
  private anonymizeId(id: string): string {
    // Keep first 4 and last 4 characters, mask middle
    if (id.length <= 8) return '****';
    return `${id.substring(0, 4)}****${id.substring(id.length - 4)}`;
  }

  /**
   * Get emoji for event type
   */
  private getEventEmoji(type: DiagnosticEventType): string {
    const emojiMap: Record<DiagnosticEventType, string> = {
      SCAN_START: '🔍',
      SCAN_END: '✅',
      DEVICE_FOUND: '📱',
      PAIRED: '🤝',
      CONNECTED: '🔗',
      WRITE_CHUNK: '📤',
      TIMEOUT: '⏱️',
      RETRY: '🔄',
      DISCONNECTED: '🔌',
      ERROR: '❌',
    };
    return emojiMap[type] || '📋';
  }
}

// ============================================================================
// SINGLETON EXPORT
// ============================================================================

export const diagnostics = BluetoothPrinterDiagnostics.getInstance();
