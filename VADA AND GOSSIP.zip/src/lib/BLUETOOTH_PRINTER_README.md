# Gastrolabs Bluetooth Printer Module

**Bulletproof Bluetooth printer connectivity for Web, Android, and iOS**

Platform-aware module for high-volume fast food workflows with automatic recovery, connection management, and ESC/POS rendering.

## 🚀 Quick Start

```typescript
import { bluetoothPrinter } from './lib/bluetooth-printer';

// 1. Check platform capabilities
const caps = bluetoothPrinter.getPlatformCapabilities();
console.log('Platform:', caps.platform);
console.log('Has Bluetooth:', caps.hasBluetooth);

// 2. Scan for devices
const devices = await bluetoothPrinter.scan({ durationMs: 10000 });
console.log('Found devices:', devices);

// 3. Connect to printer
const session = await bluetoothPrinter.connect(devices[0].id, {
  protocol: 'BLE',
  autoReconnect: true,
  keepAliveMs: 25000,
});

// 4. Print receipt
const result = await bluetoothPrinter.print(session.id, {
  width: '58mm',
  commands: [
    { type: 'TEXT', data: 'GASTROLABS POS', align: 'center' },
    { type: 'LINE' },
    { type: 'TEXT', data: 'Item 1          $10.00', align: 'left' },
    { type: 'TEXT', data: 'Item 2          $15.00', align: 'left' },
    { type: 'LINE' },
    { type: 'TEXT', data: 'TOTAL: $25.00', align: 'right' },
    { type: 'QR', qr: { data: 'ORDER-12345', size: 6 } },
    { type: 'CUT', cutType: 'full' },
  ],
  orderId: 'ORDER-12345',
  timeoutMs: 5000,
});

console.log('Print result:', result);
```

## 📋 Core API

### `scan(options?: ScanOptions): Promise<BluetoothDevice[]>`

Scan for nearby Bluetooth printers.

**Options:**
- `durationMs` - Scan duration in milliseconds (default: 10000)
- `nameFilters` - Array of name patterns to filter (e.g., `['POS', 'Printer']`)
- `serviceUUIDs` - BLE service UUIDs to filter
- `includePaired` - Include already paired devices (default: false)

**Returns:** Array of discovered devices

```typescript
const devices = await bluetoothPrinter.scan({
  durationMs: 15000,
  nameFilters: ['POS', 'TM-'],
});
```

---

### `pair(deviceId: string): Promise<PairResult>`

Pair with a device (handles OS-native pairing UI).

**Returns:** Pairing result with success status

```typescript
const pairResult = await bluetoothPrinter.pair(deviceId);
if (pairResult.success) {
  console.log('Paired successfully');
}
```

---

### `connect(deviceId: string, options: ConnectionOptions): Promise<Session>`

Connect to a paired device and create a session.

**Options:**
- `protocol` - `'SPP'` (Android Classic) or `'BLE'` (all platforms)
- `charset` - `'UTF-8'` or `'ISO-8859-1'` (default: 'UTF-8')
- `autoReconnect` - Enable automatic reconnection (default: false)
- `keepAliveMs` - Keep-alive interval in ms (default: 25000)

**Returns:** Active session object

```typescript
const session = await bluetoothPrinter.connect(deviceId, {
  protocol: 'BLE',
  charset: 'UTF-8',
  autoReconnect: true,
  keepAliveMs: 30000,
});
```

---

### `print(sessionId: string, job: PrintJob): Promise<JobResult>`

Send a print job to the connected printer.

**PrintJob:**
- `jobId` - Optional unique job ID
- `orderId` - Order ID for traceability (recommended)
- `width` - Paper width: `'58mm'` or `'80mm'`
- `encoding` - Character encoding
- `payload` - Pre-rendered ESC/POS bytes (Uint8Array)
- `commands` - High-level commands (alternative to payload)
- `timeoutMs` - Job timeout (default: 5000)
- `cut` - Cut paper: `'full'`, `'partial'`, or `null`
- `qr` - QR code options

**Returns:** Job result with byte count and duration

```typescript
const result = await bluetoothPrinter.print(session.id, {
  jobId: 'job-001',
  orderId: 'ORDER-12345',
  width: '58mm',
  encoding: 'UTF-8',
  commands: [
    { type: 'INIT' },
    { type: 'TEXT', data: 'Receipt', align: 'center' },
    { type: 'CUT', cutType: 'full' },
  ],
  timeoutMs: 5000,
});
```

---

### `getStatus(sessionId: string): Promise<PrinterStatus>`

Get current printer status.

**Returns:** Status object with connection state and diagnostics

```typescript
const status = await bluetoothPrinter.getStatus(session.id);
console.log('Connected:', status.connected);
console.log('Paper out:', status.paperOut);
console.log('Cover open:', status.coverOpen);
```

---

### `disconnect(sessionId: string): Promise<void>`

Disconnect from printer and close session.

```typescript
await bluetoothPrinter.disconnect(session.id);
```

---

### `getPlatformCapabilities(): PlatformCapabilities`

Get current platform capabilities.

```typescript
const caps = bluetoothPrinter.getPlatformCapabilities();
console.log('Platform:', caps.platform); // 'web', 'android', 'ios'
console.log('Has BLE:', caps.hasBluetoothLE);
console.log('Has Classic BT:', caps.hasClassicBluetooth);
console.log('Requires MFi:', caps.requiresMFi);
```

---

### `getDiagnostics(): DiagnosticsSnapshot`

Get diagnostics snapshot for debugging.

```typescript
const diag = bluetoothPrinter.getDiagnostics();
console.log('Total jobs:', diag.totalJobsProcessed);
console.log('Total errors:', diag.totalErrors);
console.log('Recent events:', diag.events.slice(-10));
```

---

### `exportDiagnostics(): string`

Export anonymized diagnostics as JSON string for support.

```typescript
const diagJson = bluetoothPrinter.exportDiagnostics();
// Send to support or download for debugging
```

## 🎨 ESC/POS Renderer

### Using High-Level Commands

```typescript
const job: PrintJob = {
  width: '58mm',
  commands: [
    { type: 'INIT' },
    { type: 'TEXT', data: 'MY STORE', align: 'center' },
    { type: 'BOLD', bold: true },
    { type: 'TEXT', data: 'Receipt #123', align: 'center' },
    { type: 'BOLD', bold: false },
    { type: 'LINE' },
    { type: 'TEXT', data: 'Item 1        $10', align: 'left' },
    { type: 'TEXT', data: 'Item 2        $20', align: 'left' },
    { type: 'LINE' },
    { type: 'TEXT', data: 'TOTAL: $30', align: 'right' },
    { type: 'QR', qr: { data: 'ORDER-123', size: 6 } },
    { type: 'CUT', cutType: 'full' },
  ],
};
```

### Using ReceiptBuilder Helper

```typescript
import { ReceiptBuilder } from './lib/escpos-renderer';

const receipt = new ReceiptBuilder('58mm', 'UTF-8')
  .init()
  .centerBold('GASTROLABS')
  .center('123 Main Street')
  .center('Tel: (555) 123-4567')
  .line()
  .left('Coffee             $3.50')
  .left('Sandwich           $8.00')
  .left('Water              $1.50')
  .line()
  .rightBold('TOTAL:        $13.00')
  .spacing(2)
  .center('Thank you!')
  .spacing(1)
  .qr('ORDER-12345', 6)
  .spacing(2)
  .cut('full');

const bytes = receipt.build();

// Print directly with raw bytes
await bluetoothPrinter.print(session.id, {
  width: '58mm',
  payload: bytes,
});
```

### Manual ESC/POS Rendering

```typescript
import { EscPosRenderer } from './lib/escpos-renderer';

const renderer = new EscPosRenderer('58mm', 'UTF-8');

renderer
  .init()
  .setCharset(0)
  .bold(true)
  .setAlign('center')
  .text('RECEIPT')
  .bold(false)
  .dashedLine()
  .setAlign('left')
  .text('Item 1: $10.00')
  .text('Item 2: $15.00')
  .solidLine()
  .setAlign('right')
  .bold(true)
  .text('TOTAL: $25.00')
  .bold(false)
  .spacing(2)
  .qrCode('ORDER-12345', { size: 6 })
  .cut('full');

const bytes = renderer.getBytes();
const checksum = EscPosRenderer.computeChecksum(bytes);

console.log('Rendered bytes:', bytes.length);
console.log('Checksum:', checksum);
```

## 🔧 Advanced Features

### Auto-Reconnect with Backoff

Automatic reconnection on connection loss:

```typescript
const session = await bluetoothPrinter.connect(deviceId, {
  protocol: 'BLE',
  autoReconnect: true, // Enable auto-reconnect
});

// Connection will automatically retry with backoff:
// 1s → 2s → 4s → 8s → 16s (max 5 attempts)
```

### Keep-Alive / Heartbeat

Prevent connection timeout:

```typescript
const session = await bluetoothPrinter.connect(deviceId, {
  protocol: 'BLE',
  keepAliveMs: 25000, // Heartbeat every 25 seconds
});
```

### Job Queueing

Jobs are automatically queued per session:

```typescript
// Jobs will be queued if printer is busy
const result1 = bluetoothPrinter.print(session.id, job1); // Processing
const result2 = bluetoothPrinter.print(session.id, job2); // Queued

await Promise.all([result1, result2]);
```

### Error Handling

All errors include recovery hints:

```typescript
try {
  await bluetoothPrinter.connect(deviceId, { protocol: 'BLE' });
} catch (error: BluetoothError) {
  console.error('Code:', error.code);
  console.error('Message:', error.message);
  console.error('Recoverable:', error.recoverable);
  console.error('Hint:', error.hint);
  
  if (error.recoverable) {
    // Retry logic
  } else {
    // Show user-friendly error
    alert(error.hint);
  }
}
```

### Error Codes

**Transient (Recoverable):**
- `GATT_TIMEOUT` - BLE GATT operation timeout
- `RFCOMM_RESET` - Classic Bluetooth connection reset
- `LINK_LOSS` - Connection lost
- `BUFFER_BUSY` - Printer buffer full
- `WRITE_TIMEOUT` - Write operation timeout
- `SCAN_TIMEOUT` - No devices found in scan

**Terminal (Not Recoverable):**
- `BT_UNAVAILABLE` - Bluetooth not available
- `FEATURE_UNAVAILABLE` - Platform feature not supported
- `PERMISSION_DENIED` - Bluetooth permission denied
- `MFI_REQUIRED` - iOS MFi certification required
- `UNSUPPORTED_PROTOCOL` - Protocol not supported
- `NO_SERVICE_CHAR` - No writable GATT characteristic
- `NO_SPP_CHANNEL` - No SPP RFCOMM channel

## 🌐 Platform Differences

### Web (Chrome/Edge)

**Features:**
- ✅ BLE (GATT) only
- ❌ Classic Bluetooth SPP not supported
- ✅ Web Bluetooth API
- ❌ Background reconnection

**Permissions:**
- User gesture required for device selection
- Automatic permission prompt

**Limitations:**
- Only one device can be selected at a time
- No background operation

### Android

**Features:**
- ✅ BLE (GATT)
- ✅ Classic Bluetooth SPP
- ✅ Background reconnection (with foreground service)
- ✅ Multiple concurrent connections

**Permissions Required:**
```xml
<!-- AndroidManifest.xml -->
<uses-permission android:name="android.permission.BLUETOOTH" />
<uses-permission android:name="android.permission.BLUETOOTH_ADMIN" />
<uses-permission android:name="android.permission.BLUETOOTH_SCAN" />
<uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
```

**Note:** Android 12+ requires runtime permission for `BLUETOOTH_SCAN` and `BLUETOOTH_CONNECT`.

### iOS

**Features:**
- ✅ BLE (GATT) only
- ❌ Classic Bluetooth requires MFi
- ❌ Background printing not supported
- ✅ Single connection

**Info.plist Required:**
```xml
<key>NSBluetoothAlwaysUsageDescription</key>
<string>This app requires Bluetooth to print receipts</string>
```

**MFi Printers:**
- If printer requires MFi, error `MFI_REQUIRED` will be thrown
- Use MFi-certified printers or switch to Android

## 🧪 Testing

### Test Scenarios

1. **Printer Off:**
   - Scan should timeout with `SCAN_TIMEOUT`
   - Connection should fail with `CONNECT_FAILED`

2. **Paper Out:**
   - Status should report `paperOut: true`
   - Print should complete but warn user

3. **Low Battery:**
   - Status should report battery level
   - Print may be slower

4. **Signal Loss:**
   - Auto-reconnect should trigger
   - Jobs should queue and resume

5. **Buffer Overflow:**
   - Write operations should use flow control
   - Chunking prevents overflow

### Example Test Code

```typescript
// Test connection recovery
const session = await bluetoothPrinter.connect(deviceId, {
  protocol: 'BLE',
  autoReconnect: true,
});

// Simulate disconnect
await bluetoothPrinter.disconnect(session.id);

// Wait for reconnection
await new Promise(resolve => setTimeout(resolve, 3000));

// Should be reconnected
const status = await bluetoothPrinter.getStatus(session.id);
console.log('Reconnected:', status.connected);
```

## 📊 Diagnostics

### Enable Logging

Diagnostics are automatically logged to console:

```
🔍 [BT Printer] SCAN_START: Starting Web Bluetooth scan
📱 [BT Printer] DEVICE_FOUND: Found device: POS-8001
🔗 [BT Printer] CONNECTED: Session session-123 connected
📤 [BT Printer] WRITE_CHUNK: Chunk 1/5 sent
✅ [BT Printer] WRITE_CHUNK: Job job-001 completed
```

### Export Diagnostics

```typescript
// Export for support ticket
const diagJson = bluetoothPrinter.exportDiagnostics();

// Download diagnostics
const blob = new Blob([diagJson], { type: 'application/json' });
const url = URL.createObjectURL(blob);
const a = document.createElement('a');
a.href = url;
a.download = `printer-diagnostics-${Date.now()}.json`;
a.click();
```

### Diagnostic Events

- `SCAN_START` - Scan initiated
- `SCAN_END` - Scan completed
- `DEVICE_FOUND` - Device discovered
- `PAIRED` - Device paired
- `CONNECTED` - Session connected
- `WRITE_CHUNK` - Data chunk written
- `TIMEOUT` - Operation timeout
- `RETRY` - Reconnection attempt
- `DISCONNECTED` - Session disconnected
- `ERROR` - Error occurred

## 🔒 Security & Integrity

### Order Persistence

Always persist orders before printing:

```typescript
// 1. Save order to database
const order = await saveOrderToDatabase({
  items: billItems,
  total: calculateTotal(),
  timestamp: new Date(),
});

// 2. Print with order ID for traceability
const result = await bluetoothPrinter.print(session.id, {
  orderId: order.id,
  width: '58mm',
  commands: [
    { type: 'TEXT', data: `Order #${order.id}` },
    // ... receipt content
  ],
});

// 3. Update order with print status
await updateOrderPrintStatus(order.id, result.success);
```

### Checksum Verification

Compute checksums for integrity:

```typescript
import { ReceiptBuilder, EscPosRenderer } from './lib/escpos-renderer';

const receipt = new ReceiptBuilder('58mm');
// ... build receipt

const { bytes, checksum } = receipt.buildWithChecksum();

console.log('Checksum:', checksum);

// Store checksum with order
await saveOrderChecksum(orderId, checksum);
```

## 🎯 Best Practices

1. **Always check capabilities first:**
   ```typescript
   const caps = bluetoothPrinter.getPlatformCapabilities();
   if (!caps.hasBluetooth) {
     alert('Bluetooth not available');
     return;
   }
   ```

2. **Enable auto-reconnect for critical workflows:**
   ```typescript
   await bluetoothPrinter.connect(deviceId, {
     protocol: 'BLE',
     autoReconnect: true,
     keepAliveMs: 25000,
   });
   ```

3. **Use high-level commands for flexibility:**
   ```typescript
   // Easy to modify and maintain
   const job = {
     width: '58mm',
     commands: [
       { type: 'TEXT', data: 'Header', align: 'center' },
       // ... more commands
     ],
   };
   ```

4. **Handle errors gracefully:**
   ```typescript
   try {
     await bluetoothPrinter.print(session.id, job);
   } catch (error) {
     if (error.recoverable) {
       // Retry
       await retryWithBackoff(() => bluetoothPrinter.print(session.id, job));
     } else {
       // Show user-friendly error
       showError(error.hint);
     }
   }
   ```

5. **Monitor printer status:**
   ```typescript
   setInterval(async () => {
     const status = await bluetoothPrinter.getStatus(session.id);
     if (status.paperOut) {
       alert('Please refill paper');
     }
   }, 30000);
   ```

## 🔮 Future Enhancements

- [ ] React Native bridge for Android Classic SPP
- [ ] React Native bridge for iOS/Android BLE
- [ ] Vendor-specific optimizations (Epson, Star)
- [ ] Advanced status queries (DLE EOT)
- [ ] Image/logo printing support
- [ ] Multi-device connection pool
- [ ] Print job templates
- [ ] Cloud print queue sync

## 📚 TypeScript Types

All types are fully typed and exported:

```typescript
import type {
  BluetoothDevice,
  Session,
  PrintJob,
  JobResult,
  PrinterStatus,
  BluetoothError,
  PlatformCapabilities,
} from './lib/bluetooth-printer-types';
```

## 🐛 Troubleshooting

### Web Bluetooth not working
- Use Chrome, Edge, or Opera (Firefox doesn't support Web Bluetooth)
- Ensure HTTPS (required for Web Bluetooth API)
- Check browser flags: `chrome://flags/#enable-web-bluetooth`

### Permission denied
- Check system Bluetooth permissions
- On Android 12+, grant location permission (required by OS)
- Provide permission rationale to users

### Printer not found
- Ensure printer is powered on
- Put printer in pairing/discoverable mode
- Check printer is in range (<10m for BLE)
- Try increasing scan duration

### Print quality issues
- Adjust paper width setting to match printer
- Use correct encoding (UTF-8 for most printers)
- Check character set compatibility

### Connection drops
- Enable auto-reconnect
- Reduce keep-alive interval
- Check for interference from other Bluetooth devices
- Ensure printer has sufficient battery

## 📄 License

Part of Gastrolabs POS - Proprietary

---

**Built with ❤️ by Gastrolabs**
