import { supabase } from './supabase';
import { Order } from '../App';

// Fraud prevention utilities

export const validateOrderBeforePrint = async (order: Order, tenantId: string): Promise<{ valid: boolean; error?: string }> => {
  // Rule 1: Order must be saved to database first
  const { data: existingOrder } = await supabase
    .from('orders')
    .select('id')
    .eq('id', order.id)
    .eq('tenant_id', tenantId)
    .single();

  if (!existingOrder) {
    return {
      valid: false,
      error: '⚠️ FRAUD PREVENTION: Order must be saved to database before printing!'
    };
  }

  // Rule 2: Order must not be voided
  const { data: orderDetails } = await supabase
    .from('orders')
    .select('status, voided_at')
    .eq('id', order.id)
    .single();

  if (orderDetails?.status === 'voided') {
    return {
      valid: false,
      error: '❌ Cannot print voided order!'
    };
  }

  // Rule 3: Check for duplicate print attempts (potential fraud)
  const recentPrints = await getRecentPrintAttempts(order.id, tenantId);
  if (recentPrints > 5) {
    return {
      valid: false,
      error: '⚠️ Excessive print attempts detected. Please contact support.'
    };
  }

  return { valid: true };
};

export const canDeleteOrder = async (order: Order, tenantId: string): Promise<{ canDelete: boolean; reason?: string }> => {
  // Rule: Paid orders CANNOT be deleted
  if (order.status === 'paid') {
    return {
      canDelete: false,
      reason: '🔒 FRAUD PREVENTION: Paid orders cannot be deleted! Use void instead.'
    };
  }

  // Rule: Orders can only be voided, not deleted
  // This maintains audit trail
  return {
    canDelete: false,
    reason: '🔒 Orders cannot be deleted. Use "Void Order" to cancel instead.'
  };
};

export const voidOrder = async (orderId: string, tenantId: string, reason: string): Promise<{ success: boolean; error?: string }> => {
  // Get order details
  const { data: order, error: fetchError } = await supabase
    .from('orders')
    .select('*')
    .eq('id', orderId)
    .eq('tenant_id', tenantId)
    .single();

  if (fetchError || !order) {
    return { success: false, error: 'Order not found' };
  }

  // Cannot void paid orders without special permission
  if (order.status === 'paid') {
    return {
      success: false,
      error: '⚠️ Cannot void paid order. Please contact manager for refund authorization.'
    };
  }

  // Void the order
  const { error: voidError } = await supabase
    .from('orders')
    .update({
      status: 'voided',
      voided_at: new Date().toISOString(),
      voided_reason: reason
    })
    .eq('id', orderId)
    .eq('tenant_id', tenantId);

  if (voidError) {
    return { success: false, error: 'Failed to void order' };
  }

  return { success: true };
};

export const getRecentPrintAttempts = async (orderId: string, tenantId: string): Promise<number> => {
  const oneHourAgo = new Date();
  oneHourAgo.setHours(oneHourAgo.getHours() - 1);

  const { data, error } = await supabase
    .from('audit_logs')
    .select('id')
    .eq('tenant_id', tenantId)
    .eq('entity_id', orderId)
    .eq('action', 'order.printed')
    .gte('created_at', oneHourAgo.toISOString());

  if (error) return 0;

  return data?.length || 0;
};

export const detectUnpaidOrderAttempt = (order: Order): { isPaid: boolean; warning?: string } => {
  if (order.status === 'active') {
    return {
      isPaid: false,
      warning: '⚠️ WARNING: This order is UNPAID! Ensure payment is received before completing.'
    };
  }

  return { isPaid: true };
};

export const generateDailySettlement = async (tenantId: string, date: Date) => {
  const startOfDay = new Date(date);
  startOfDay.setHours(0, 0, 0, 0);

  const endOfDay = new Date(date);
  endOfDay.setHours(23, 59, 59, 999);

  // Get all orders for the day
  const { data: orders, error } = await supabase
    .from('orders')
    .select('*')
    .eq('tenant_id', tenantId)
    .gte('created_at', startOfDay.toISOString())
    .lte('created_at', endOfDay.toISOString());

  if (error || !orders) {
    console.error('Failed to generate settlement:', error);
    return null;
  }

  // Calculate totals
  const totalOrders = orders.length;
  const paidOrders = orders.filter(o => o.status === 'paid');
  const totalRevenue = paidOrders.reduce((sum, o) => sum + o.total, 0);

  // Break down by payment method
  const cashOrders = paidOrders.filter(o => o.payment_method === 'cash');
  const cardOrders = paidOrders.filter(o => o.payment_method === 'card');
  const upiOrders = paidOrders.filter(o => o.payment_method === 'upi');

  const totalCash = cashOrders.reduce((sum, o) => sum + o.total, 0);
  const totalCard = cardOrders.reduce((sum, o) => sum + o.total, 0);
  const totalUpi = upiOrders.reduce((sum, o) => sum + o.total, 0);

  // Save settlement
  const { data: settlement, error: settlementError } = await supabase
    .from('daily_settlements')
    .insert({
      tenant_id: tenantId,
      settlement_date: date.toISOString().split('T')[0],
      total_orders: totalOrders,
      total_revenue: totalRevenue,
      total_cash: totalCash,
      total_card: totalCard,
      total_upi: totalUpi
    })
    .select()
    .single();

  if (settlementError) {
    console.error('Failed to save settlement:', settlementError);
    return null;
  }

  return {
    date: date.toISOString().split('T')[0],
    totalOrders,
    paidOrders: paidOrders.length,
    unpaidOrders: totalOrders - paidOrders.length,
    totalRevenue,
    breakdown: {
      cash: { orders: cashOrders.length, total: totalCash },
      card: { orders: cardOrders.length, total: totalCard },
      upi: { orders: upiOrders.length, total: totalUpi }
    }
  };
};

export const emailDailySettlement = async (tenantId: string, settlementData: any) => {
  // Get tenant email
  const { data: tenant } = await supabase
    .from('tenants')
    .select('name, email')
    .eq('id', tenantId)
    .single();

  if (!tenant) return;

  // Call email API endpoint
  try {
    await fetch('/api/send-settlement-email', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        to: tenant.email,
        businessName: tenant.name,
        settlement: settlementData
      })
    });

    // Mark as emailed
    await supabase
      .from('daily_settlements')
      .update({ emailed_at: new Date().toISOString() })
      .eq('settlement_date', settlementData.date)
      .eq('tenant_id', tenantId);
  } catch (error) {
    console.error('Failed to send settlement email:', error);
  }
};

// Auto-generate settlement at end of day (call this from a cron job or scheduled function)
export const scheduleEndOfDaySettlement = () => {
  const now = new Date();
  const midnight = new Date();
  midnight.setHours(24, 0, 0, 0);

  const msUntilMidnight = midnight.getTime() - now.getTime();

  setTimeout(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);

      const settlement = await generateDailySettlement(user.id, yesterday);
      if (settlement) {
        await emailDailySettlement(user.id, settlement);
      }
    }

    // Schedule next day
    scheduleEndOfDaySettlement();
  }, msUntilMidnight);
};
