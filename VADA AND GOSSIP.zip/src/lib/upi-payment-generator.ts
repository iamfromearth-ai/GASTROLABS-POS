/**
 * UPI Payment QR Code Generator
 * Generates dynamic UPI payment URLs and QR codes with order-specific amounts
 */

export interface UPIPaymentParams {
  upiId: string;
  name: string;
  amount: number;
  orderId: string;
  note?: string;
}

/**
 * Generates a UPI payment URL that can be encoded in QR codes
 * Format: upi://pay?pa=UPI_ID&pn=NAME&am=AMOUNT&cu=INR&tn=NOTE
 */
export function generateUPIPaymentURL(params: UPIPaymentParams): string {
  const { upiId, name, amount, orderId, note } = params;
  
  // Encode parameters for URL
  const encodedName = encodeURIComponent(name);
  const encodedNote = encodeURIComponent(note || `Payment for Order #${orderId}`);
  
  // Build UPI URL following standard format
  const upiUrl = `upi://pay?pa=${upiId}&pn=${encodedName}&am=${amount.toFixed(2)}&cu=INR&tn=${encodedNote}`;
  
  return upiUrl;
}

/**
 * Generates a combined data string for QR code that includes:
 * - UPI payment link (for payment apps)
 * - Order ID (for tracking)
 * - Amount (for verification)
 */
export function generatePaymentQRData(params: UPIPaymentParams): string {
  const upiUrl = generateUPIPaymentURL(params);
  
  // Create a JSON payload that apps can parse
  const qrData = {
    type: 'PAYMENT',
    upi: upiUrl,
    orderId: params.orderId,
    amount: params.amount,
    timestamp: new Date().toISOString(),
  };
  
  // For UPI apps to work, we need to return the raw UPI URL
  // Apps will automatically detect upi:// protocol
  return upiUrl;
}

/**
 * Parses scanned QR data to extract payment information
 */
export function parsePaymentQRData(qrData: string): {
  type: 'PAYMENT' | 'ORDER_ID' | 'UPI' | 'UNKNOWN';
  orderId?: string;
  amount?: number;
  upiUrl?: string;
} {
  // Check if it's a UPI URL
  if (qrData.startsWith('upi://pay')) {
    const urlParams = new URLSearchParams(qrData.split('?')[1]);
    const note = urlParams.get('tn') || '';
    const amount = parseFloat(urlParams.get('am') || '0');
    
    // Extract order ID from note (format: "Payment for Order #ORDER_ID")
    const orderIdMatch = note.match(/Order #(\w+)/);
    const orderId = orderIdMatch ? orderIdMatch[1] : undefined;
    
    return {
      type: 'UPI',
      orderId,
      amount,
      upiUrl: qrData,
    };
  }
  
  // Check if it's a plain order ID
  if (qrData.match(/^[A-Z0-9]{8,}$/)) {
    return {
      type: 'ORDER_ID',
      orderId: qrData,
    };
  }
  
  // Try to parse as JSON
  try {
    const parsed = JSON.parse(qrData);
    if (parsed.type === 'PAYMENT') {
      return {
        type: 'PAYMENT',
        orderId: parsed.orderId,
        amount: parsed.amount,
        upiUrl: parsed.upi,
      };
    }
  } catch (e) {
    // Not JSON
  }
  
  return { type: 'UNKNOWN' };
}

/**
 * Validates UPI ID format
 */
export function isValidUPIId(upiId: string): boolean {
  // UPI ID format: username@bankname
  // Username can contain: letters, numbers, dots, hyphens, underscores
  // Bank name can contain: letters, numbers, dots (e.g., @federal, @paytm, @okaxis)
  const upiRegex = /^[\w\.\-]+@[\w\.]+$/;
  return upiRegex.test(upiId);
}