/**
 * Root component that wraps the App with AuthProvider
 * This ensures password protection works reliably across all devices
 */

import App from './App';
import { AuthProvider } from './lib/auth-context';

export default function Root() {
  return (
    <AuthProvider>
      <App />
    </AuthProvider>
  );
}
