# GASTROLABS POS - COMPREHENSIVE TECHNICAL DOCUMENTATION

**Version:** 1.0.0  
**Platform:** Web (React + TypeScript), iOS & Android Ready  
**Company:** Gastrolabs - Food Service Software Solutions  
**Product Type:** White-Label SaaS POS Platform  

---

## 📋 TABLE OF CONTENTS

1. [System Architecture Overview](#1-system-architecture-overview)
2. [Core Data Models](#2-core-data-models)
3. [State Management Architecture](#3-state-management-architecture)
4. [Component Architecture](#4-component-architecture)
5. [Feature Modules Deep Dive](#5-feature-modules-deep-dive)
6. [White-Label System](#6-white-label-system)
7. [Business Logic & Workflows](#7-business-logic--workflows)
8. [Security Implementation](#8-security-implementation)
9. [Print & Receipt System](#9-print--receipt-system)
10. [Data Persistence & Export](#10-data-persistence--export)
11. [Payment & QR Code Integration](#11-payment--qr-code-integration)
12. [Future Development Roadmap](#12-future-development-roadmap)

---

## 1. SYSTEM ARCHITECTURE OVERVIEW

### 1.1 Technology Stack

```typescript
Framework: React 18.x (TypeScript)
UI Library: Tailwind CSS v4.0
Component Library: shadcn/ui (Radix UI primitives)
Icons: Lucide React
State Management: React useState (Local State)
Routing: View-based conditional rendering (No React Router)
QR Code: qrcode library
Notifications: Sonner (Toast notifications)
Forms: React Hook Form (v7.55.0)
Build Tool: Vite/Create React App
```

### 1.2 Application Architecture Pattern

**Pattern:** Monolithic Single-Page Application (SPA)
- **No Backend (Currently):** Pure frontend application
- **Data Storage:** Browser localStorage (JSON serialization)
- **Future Backend:** Supabase integration planned for multi-device sync

### 1.3 View Navigation System

The app uses a **state-based view routing system** instead of traditional URL routing:

```typescript
type ViewType = 
  | 'pos'                    // Main POS screen
  | 'items'                  // Item management
  | 'categories'             // Category management
  | 'history'                // Order history
  | 'settings'               // Main settings
  | 'receipt-settings'       // Receipt customization
  | 'printer-settings'       // Thermal printer config
  | 'statistics'             // Analytics dashboard
  | 'data-settings'          // Backup/restore
  | 'language-settings'      // Multi-language
  | 'currency-settings'      // Currency symbols
  | 'email-settings'         // Email integration
  | 'message-settings'       // SMS/iMessage integration
  | 'logo-settings'          // Receipt logo
  | 'footer-settings'        // Receipt footer
  | 'time-format-settings'   // Date/time formatting
  | 'business-identity'      // Business info for receipts
  | 'sequence-settings'      // Invoice numbering
  | 'tax-settings'           // Tax configuration
  | 'discount-settings'      // Discount rules
  | 'fees-settings'          // Additional fees (service charge, etc.)
  | 'qrcode-settings'        // Payment QR codes
  | 'password-settings'      // Security settings
  | 'branding-settings'      // WHITE-LABEL: Business branding
  | 'about-gastrolabs';      // Company information

const [currentView, setCurrentView] = useState<ViewType>('pos');
```

**Navigation Flow:**
```
POS Screen (pos)
  ├─> Sidebar Icons trigger view changes
  ├─> setCurrentView('items') → Item Management
  ├─> setCurrentView('settings') → Settings Hub
  │     └─> Settings Hub has sub-navigation
  │           ├─> Receipt Settings → More sub-pages
  │           ├─> Printer Settings
  │           ├─> Data Settings
  │           ├─> Branding Settings ✨ WHITE-LABEL
  │           └─> About Gastrolabs
  └─> onBack() functions navigate backwards
```

---

## 2. CORE DATA MODELS

### 2.1 MenuItem Interface

```typescript
export interface MenuItem {
  id: string;              // Unique identifier (timestamp-based)
  name: string;            // Item name (e.g., "Ginger Tea")
  price: number;           // Price in base currency units
  category: string;        // Category reference (e.g., "Tea", "Snacks")
}

// Example:
{
  id: "1704123456789",
  name: "Special Tea",
  price: 15,
  category: "Tea"
}
```

**Storage:** `menuItems` state in App.tsx
**Persistence:** localStorage (future: Supabase table)

### 2.2 BillItem Interface (extends MenuItem)

```typescript
export interface BillItem extends MenuItem {
  quantity: number;        // Number of items ordered
}

// Example current bill:
[
  { id: "1", name: "Regular Tea", price: 10, category: "Tea", quantity: 2 },
  { id: "5", name: "Samosa", price: 20, category: "Snacks", quantity: 3 }
]
// Total: (10 × 2) + (20 × 3) = ₹80
```

**Storage:** `billItems` state in App.tsx
**Lifecycle:** 
- Created when item added to bill
- Cleared after checkout confirmation
- Never persisted (temporary cart state)

### 2.3 Order Interface

```typescript
export interface Order {
  id: string;              // Unique order ID (timestamp)
  items: BillItem[];       // Snapshot of bill items at checkout
  total: number;           // Calculated total amount
  timestamp: Date;         // Order creation time
  status: 'active' | 'paid'; // Payment status
}

// Example:
{
  id: "1704123456789",
  items: [
    { id: "1", name: "Regular Tea", price: 10, category: "Tea", quantity: 2 }
  ],
  total: 20,
  timestamp: new Date("2025-01-24T14:30:00"),
  status: "active"  // Created as UNPAID initially
}
```

**Storage:** `orders` state array in App.tsx
**Status Workflow:**
1. **Order Created:** `status: 'active'` (UNPAID bill)
2. **Payment Received:** User marks as paid → `status: 'paid'`
3. **QR Code Integration:** QR contains order ID for payment tracking

### 2.4 AppSettings Interface

```typescript
export interface AppSettings {
  sound: boolean;              // Play sound on item add
  vibration: boolean;          // Haptic feedback (mobile)
  currency: string;            // Currency symbol (e.g., "Rs", "$", "€")
  sortManually: boolean;       // Manual item sorting (future feature)
  mergeSimilarItems: boolean;  // Combine same items in bill
}
```

### 2.5 ReceiptConfig Interface (Complex Configuration Object)

```typescript
export interface ReceiptConfig {
  // Basic Receipt Header
  header: string;                    // Business name on receipt
  
  // Display Toggles
  showCustomer: boolean;             // Show customer name field
  showTotalQty: boolean;             // Show total quantity
  showSubtotal: boolean;             // Show subtotal before taxes
  showPaymentMethods: boolean;       // Show payment method field
  showCash: boolean;                 // Show cash received
  showChange: boolean;               // Show change given
  showGrandTotal: boolean;           // Show final total
  showPaidTime: boolean;             // Show payment timestamp
  showWatermark: boolean;            // Show watermark
  
  // Format Settings
  timeFormat: string;                // Date/time format string
  
  // Logo Configuration
  logo: {
    enabled: boolean;                // Show logo on receipt
    type: 'text' | 'upload' | 'default';
    imageUrl: string;                // Base64 or URL
    text: string;                    // Text logo fallback
    size: 'small' | 'medium' | 'large';
  };
  
  // Footer Configuration
  footer: {
    enabled: boolean;
    text: string;                    // Footer message
    showContactInfo: boolean;
    contactInfo: string;             // Contact details
  };
  
  // Business Identity (for receipts)
  business: {
    enabled: boolean;
    businessName: string;            // ✨ WHITE-LABEL: Custom business name
    address: string;                 // Multi-line address
    phone: string;
    email: string;
    website: string;
    taxId: string;                   // Tax registration number
  };
  
  // Invoice Sequence
  sequence: {
    enabled: boolean;
    prefix: string;                  // e.g., "INV-"
    startNumber: number;             // Starting number
    format: 'simple' | 'padded' | 'date-number';
    padding: number;                 // Zero-padding length
  };
  
  // Tax Configuration
  tax: {
    enabled: boolean;
    taxes: Array<{
      id: string;
      name: string;                  // e.g., "GST", "VAT"
      rate: number;                  // Percentage
      type: 'percentage' | 'fixed';
    }>;
    includedInPrice: boolean;        // Tax-inclusive pricing
  };
  
  // Discount Settings
  discount: {
    enabled: boolean;
    type: 'percentage' | 'fixed';
    value: number;
    applyToTotal: boolean;           // Apply after taxes
  };
  
  // Additional Fees
  fees: {
    enabled: boolean;
    fees: Array<{
      id: string;
      name: string;                  // e.g., "Service Charge"
      value: number;
      type: 'percentage' | 'fixed';
    }>;
  };
  
  // QR Code Payment
  qrCode: {
    enabled: boolean;
    type: 'upi' | 'url' | 'text';
    upiId: string;                   // UPI ID for payments
    url: string;                     // Payment gateway URL
    text: string;                    // Custom QR text
    size: 'small' | 'medium' | 'large';
    label: string;                   // QR code label
  };
  
  // ✨ WHITE-LABEL ADDITIONS (BrandingSettings)
  businessLogo?: string;             // Custom business logo (Base64)
  primaryColor?: string;             // Brand primary color (hex)
  secondaryColor?: string;           // Brand secondary color
  accentColor?: string;              // Brand accent color
}
```

### 2.6 PrinterConfig Interface

```typescript
export interface PrinterConfig {
  connectionType: 'wifi' | 'bluetooth' | 'usb';
  printerName: string;
  ipAddress: string;                 // For WiFi printers
  port: string;                      // Network port
  autoPrint: boolean;                // Auto-print on checkout
  paperWidth: '58mm' | '80mm';       // Thermal paper size
  encoding: 'UTF-8' | 'ISO-8859-1';  // Character encoding
}
```

### 2.7 EmailConfig Interface

```typescript
export interface EmailConfig {
  enabled: boolean;
  recipientEmail: string;
  subject: string;
  messageTemplate: string;           // Template with {variables}
  includeReceipt: boolean;
  autoSend: boolean;                 // Auto-send on payment
}
```

### 2.8 MessageConfig Interface

```typescript
export interface MessageConfig {
  enabled: boolean;
  phoneNumber: string;
  messageTemplate: string;           // SMS template
  includeTotal: boolean;
  includeItems: boolean;
  autoSend: boolean;
}
```

---

## 3. STATE MANAGEMENT ARCHITECTURE

### 3.1 Root State (App.tsx)

All application state is managed in the root `App.tsx` component using React `useState`:

```typescript
// Current Active Bill (Temporary State)
const [billItems, setBillItems] = useState<BillItem[]>([]);

// Menu Inventory (Persistent)
const [menuItems, setMenuItems] = useState<MenuItem[]>(DEFAULT_ITEMS);
const [categories, setCategories] = useState<string[]>(DEFAULT_CATEGORIES);

// Order History (Persistent)
const [orders, setOrders] = useState<Order[]>([]);

// Application Configuration (Persistent)
const [appSettings, setAppSettings] = useState<AppSettings>(DEFAULT_APP_SETTINGS);
const [receiptConfig, setReceiptConfig] = useState<ReceiptConfig>(DEFAULT_RECEIPT_CONFIG);
const [printerConfig, setPrinterConfig] = useState<PrinterConfig>(DEFAULT_PRINTER_CONFIG);
const [emailConfig, setEmailConfig] = useState<EmailConfig>(DEFAULT_EMAIL_CONFIG);
const [messageConfig, setMessageConfig] = useState<MessageConfig>(DEFAULT_MESSAGE_CONFIG);

// UI State (Non-Persistent)
const [currentView, setCurrentView] = useState<ViewType>('pos');
const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
const [searchQuery, setSearchQuery] = useState('');
const [printPreviewOpen, setPrintPreviewOpen] = useState(false);
const [currentOrderId, setCurrentOrderId] = useState<string>('');
```

### 3.2 State Flow Diagram

```
┌─────────────────────────────────────────────────────────┐
│                     App.tsx (Root)                       │
│  ┌───────────────────────────────────────────────────┐  │
│  │  State Management (useState)                      │  │
│  │  - billItems, menuItems, orders                   │  │
│  │  - All configuration objects                      │  │
│  └───────────────────────────────────────────────────┘  │
│                          │                               │
│         Props Drilling to Child Components               │
│                          │                               │
│  ┌──────────┬──────────┬┴────────┬──────────┬─────────┐ │
│  │   POS    │  Items   │ Orders  │ Settings │  Stats  │ │
│  │  Screen  │   Mgmt   │ History │   Hub    │ Dashboard│ │
│  └──────────┴──────────┴─────────┴──────────┴─────────┘ │
│       │                                  │                │
│       │                            ┌─────┴──────┐        │
│   Callbacks                        │  Settings  │        │
│  (onUpdate)                        │  Sub-Pages │        │
│       │                            └────────────┘        │
│       └──────────────► Updates State ◄──────────┘        │
└─────────────────────────────────────────────────────────┘
```

### 3.3 Data Persistence Strategy

**Current Implementation:**
- ✅ **No automatic persistence** - User must manually export data
- ✅ **Manual Export:** JSON file download with all state
- ✅ **Manual Import:** Upload JSON to restore state

**Future Implementation (Planned):**
- 🔜 **localStorage auto-save:** Automatic state persistence
- 🔜 **Supabase backend:** Multi-device sync, cloud backup
- 🔜 **Real-time sync:** WebSocket-based live updates

---

## 4. COMPONENT ARCHITECTURE

### 4.1 Component Hierarchy Tree

```
App.tsx (Root Container)
│
├─ Conditional View Rendering
│  │
│  ├─ POS Screen (Main View - currentView === 'pos')
│  │  │
│  │  ├─ Header (Brand Logo + Name)
│  │  │  └─ Dynamic: Uses receiptConfig.business.businessName || "Vada & Gossip"
│  │  │
│  │  ├─ ReceiptTape Component
│  │  │  └─ Props: items={billItems}, total={calculateTotal()}
│  │  │
│  │  ├─ Main Content Area (Flex Container)
│  │  │  │
│  │  │  ├─ Item Grid Section
│  │  │  │  ├─ Search Bar (Input Component)
│  │  │  │  ├─ Category Filter (Button Array)
│  │  │  │  └─ Item Buttons Grid
│  │  │  │     └─ onClick → addItem(item)
│  │  │  │
│  │  │  └─ Sidebar Component
│  │  │     ├─ Props: orders, hasItems, callbacks
│  │  │     ├─ Unpaid Bills Alert Badge
│  │  │     ├─ Icon Navigation Buttons
│  │  │     │  ├─ Package → Items Management
│  │  │     │  ├─ Tag → Categories
│  │  │     │  ├─ History → Order History
│  │  │     │  ├─ BarChart → Statistics
│  │  │     │  ├─ Settings → Settings Hub
│  │  │     │  ├─ Trash → Clear Bill
│  │  │     │  └─ Check → Checkout
│  │  │     └─ Password Protection on Delete
│  │  │
│  │  └─ PrintPreview Dialog (Modal)
│  │     └─ Shows before printing, creates order
│  │
│  ├─ Item Management (currentView === 'items')
│  │  ├─ ItemManagement Component
│  │  │  ├─ Props: items, categories, onBack, onUpdate
│  │  │  ├─ Search Bar
│  │  │  ├─ Add Item Dialog
│  │  │  ├─ Edit Item Dialog
│  │  │  └─ Delete (Password Protected)
│  │
│  ├─ Category Management (currentView === 'categories')
│  │  ├─ CategoryManagement Component
│  │  │  ├─ Add Category
│  │  │  └─ Delete Category
│  │
│  ├─ Order History (currentView === 'history')
│  │  ├─ OrderHistory Component
│  │  │  ├─ Filter: Active/Paid/All
│  │  │  ├─ CSV Export Function
│  │  │  ├─ Order Cards
│  │  │  │  ├─ Status Badge
│  │  │  │  ├─ Mark as Paid Button
│  │  │  │  └─ Delete Order
│  │  │  └─ QRScanner Component (Payment Verification)
│  │
│  ├─ Statistics Dashboard (currentView === 'statistics')
│  │  ├─ Statistics Component
│  │  │  ├─ Total Revenue
│  │  │  ├─ Order Count
│  │  │  ├─ Average Order Value
│  │  │  ├─ Most Sold Items
│  │  │  └─ Category Breakdown
│  │
│  ├─ Settings Hub (currentView === 'settings')
│  │  ├─ Settings Component
│  │  │  ├─ 🌟 Business Branding (White-Label)
│  │  │  ├─ Receipt Settings
│  │  │  ├─ Printer Settings
│  │  │  ├─ Data Settings
│  │  │  ├─ Password Protection
│  │  │  ├─ App Settings (Sound, Vibration)
│  │  │  ├─ Language & Currency
│  │  │  ├─ Email & iMessage Integration
│  │  │  └─ About Gastrolabs
│  │
│  ├─ Receipt Settings (currentView === 'receipt-settings')
│  │  ├─ ReceiptSettings Component
│  │  │  ├─ Header Configuration
│  │  │  ├─ Navigation to Sub-Settings:
│  │  │  │  ├─ Logo Settings
│  │  │  │  ├─ Footer Settings
│  │  │  │  ├─ Time Format Settings
│  │  │  │  ├─ Business Identity
│  │  │  │  ├─ Sequence Settings (Invoice Numbers)
│  │  │  │  ├─ Tax Settings
│  │  │  │  ├─ Discount Settings
│  │  │  │  ├─ Fees Settings
│  │  │  │  └─ QR Code Settings
│  │  │  └─ Display Options Toggles
│  │
│  ├─ 🌟 Branding Settings (currentView === 'branding-settings') ✨ WHITE-LABEL
│  │  ├─ BrandingSettings Component
│  │  │  ├─ Gastrolabs Attribution Banner
│  │  │  ├─ Business Name Input
│  │  │  ├─ Business Tagline Input
│  │  │  ├─ Logo Upload System
│  │  │  ├─ Brand Color Pickers
│  │  │  │  ├─ Primary Color
│  │  │  │  ├─ Secondary Color
│  │  │  │  └─ Accent Color
│  │  │  ├─ Real-time Header Preview
│  │  │  └─ Save Button
│  │
│  ├─ About Gastrolabs (currentView === 'about-gastrolabs')
│  │  ├─ AboutGastrolabs Component
│  │  │  ├─ Gastrolabs Branding
│  │  │  ├─ App Version & Build Info
│  │  │  ├─ Platform Features
│  │  │  ├─ Company Information
│  │  │  ├─ Contact Details
│  │  │  │  ├─ Website Link
│  │  │  │  ├─ Email Support
│  │  │  │  └─ Phone Support
│  │  │  ├─ Mission Statement
│  │  │  ├─ Industries Served (12+ verticals)
│  │  │  ├─ Legal Links
│  │  │  │  ├─ Terms of Service
│  │  │  │  ├─ Privacy Policy
│  │  │  │  └─ White-Label License Agreement
│  │  │  └─ Copyright Notice
│  │
│  └─ [All Other Settings Sub-Pages]
│     ├─ PrinterSettings
│     ├─ DataSettings (Export/Import/Clear)
│     ├─ LanguageSettings
│     ├─ CurrencySettings
│     ├─ EmailSettings
│     ├─ MessageSettings
│     ├─ LogoSettings
│     ├─ FooterSettings
│     ├─ TimeFormatSettings
│     ├─ BusinessIdentity
│     ├─ SequenceSettings
│     ├─ TaxSettings
│     ├─ DiscountSettings
│     ├─ FeesSettings
│     ├─ QRCodeSettings
│     └─ PasswordSetup
│
└─ Global Components (Always Present)
   ├─ Toaster (sonner@2.0.3) - Toast notifications
   └─ PrintPreview Dialog (Conditional render)
```

### 4.2 Component Communication Pattern

**Props Drilling Pattern:**
```typescript
// App.tsx passes state and callbacks down
<ItemManagement
  items={menuItems}              // Read state
  categories={categories}        // Read state
  onBack={() => setCurrentView('pos')}
  onUpdate={setMenuItems}        // State updater callback
/>

// ItemManagement receives and uses
function ItemManagement({ items, categories, onBack, onUpdate }) {
  const handleAddItem = (newItem: MenuItem) => {
    onUpdate([...items, newItem]);  // Calls parent state setter
  };
  
  return (
    <Button onClick={onBack}>Back</Button>  // Navigates back
  );
}
```

**No Context API or Redux** - Simple props drilling due to shallow component tree.

---

## 5. FEATURE MODULES DEEP DIVE

### 5.1 POS Billing System

#### 5.1.1 Add Item to Bill Flow

```typescript
// Step-by-step execution when user taps an item button

// 1. User clicks item button
<Button onClick={() => addItem(item)}>
  {item.name} - ₹{item.price}
</Button>

// 2. addItem function executes
const addItem = (item: MenuItem) => {
  setBillItems((prev) => {
    // 3. Check if item already exists in bill
    const existing = prev.find((i) => i.id === item.id);
    
    if (existing) {
      // 4a. If exists: Increment quantity
      return prev.map((i) =>
        i.id === item.id 
          ? { ...i, quantity: i.quantity + 1 }  // Increment
          : i
      );
    }
    
    // 4b. If new: Add with quantity 1
    return [...prev, { ...item, quantity: 1 }];
  });
};

// 5. Re-render triggered
// 6. ReceiptTape component displays updated billItems
// 7. Total recalculated automatically
```

#### 5.1.2 Total Calculation System

```typescript
// Base calculation
const calculateTotal = () => {
  return billItems.reduce((sum, item) => 
    sum + (item.price * item.quantity), 
    0
  );
};

// Advanced calculation (with taxes, discounts, fees)
const calculateAdvancedTotal = () => {
  let subtotal = calculateTotal();
  
  // Apply discount
  if (receiptConfig.discount?.enabled) {
    if (receiptConfig.discount.type === 'percentage') {
      subtotal -= (subtotal * receiptConfig.discount.value) / 100;
    } else {
      subtotal -= receiptConfig.discount.value;
    }
  }
  
  // Add taxes
  if (receiptConfig.tax?.enabled) {
    receiptConfig.tax.taxes.forEach(tax => {
      if (tax.type === 'percentage') {
        subtotal += (subtotal * tax.rate) / 100;
      } else {
        subtotal += tax.rate;
      }
    });
  }
  
  // Add fees
  if (receiptConfig.fees?.enabled) {
    receiptConfig.fees.fees.forEach(fee => {
      if (fee.type === 'percentage') {
        subtotal += (subtotal * fee.value) / 100;
      } else {
        subtotal += fee.value;
      }
    });
  }
  
  return subtotal;
};
```

#### 5.1.3 Checkout Workflow

```typescript
// Complete checkout flow with all stages

// 1. User clicks Checkout button (Sidebar)
const handleCheckout = () => {
  if (billItems.length > 0) {
    // 2. Generate unique order ID
    const orderId = Date.now().toString();
    setCurrentOrderId(orderId);
    
    // 3. Open print preview dialog
    setPrintPreviewOpen(true);
    
    // Note: Order not created yet! Preview first.
  }
};

// 4. User confirms print in PrintPreview dialog
const handleConfirmPrint = async () => {
  // 5. Create order object
  const newOrder: Order = {
    id: currentOrderId,
    items: [...billItems],        // Snapshot of current bill
    total: calculateTotal(),
    timestamp: new Date(),
    status: 'active'               // Always starts as UNPAID
  };
  
  // 6. Save to order history
  setOrders((prev) => [newOrder, ...prev]);
  
  // 7. Show notification
  toast.warning('Bill created as UNPAID. Please settle payment in Order History.', {
    duration: 4000,
  });
  
  // 8. Generate and print receipt
  await handleThermalPrint(currentOrderId);
  
  // 9. Clear bill after short delay (allows print to process)
  setTimeout(() => {
    clearBill();
  }, 500);
};

// 10. Clear bill function
const clearBill = () => {
  setBillItems([]);
  // Note: Order remains in history with 'active' status
};
```

### 5.2 Order History & Payment Tracking

#### 5.2.1 Order Status Lifecycle

```
┌─────────────────────────────────────────────────────────┐
│                  ORDER LIFECYCLE                         │
└─────────────────────────────────────────────────────────┘

[1] Checkout Initiated
     └─> handleCheckout() called
          └─> Print Preview Opens

[2] Print Confirmed
     └─> handleConfirmPrint() executes
          ├─> Order created with status: 'active' ❌ UNPAID
          ├─> Receipt printed with QR code
          ├─> Order saved to history
          └─> Bill cleared

[3] Payment Received (Manual Process)
     └─> User marks order as paid in Order History
          ├─> Status changes: 'active' → 'paid' ✅
          ├─> Visual badge updates
          └─> Statistics recalculated

[4] Optional: QR Code Payment Verification
     └─> Customer scans QR code
          └─> QR contains order metadata:
              {
                orderId: "1704123456789",
                amount: 150,
                timestamp: "2025-01-24T14:30:00"
              }
```

#### 5.2.2 Mark as Paid Implementation

```typescript
// Order History Component

const handleMarkAsPaid = (orderId: string) => {
  setOrders((prev) =>
    prev.map((order) =>
      order.id === orderId 
        ? { ...order, status: 'paid' }  // Update status
        : order
    )
  );
  
  toast.success('Order marked as PAID ✅');
};

// Visual representation in UI
<Badge variant={order.status === 'paid' ? 'success' : 'warning'}>
  {order.status === 'paid' ? '✅ PAID' : '❌ UNPAID'}
</Badge>
```

#### 5.2.3 CSV Export Functionality

```typescript
// Export orders to CSV file

const handleExportCSV = () => {
  // 1. Prepare CSV headers
  const headers = ['Order ID', 'Date', 'Time', 'Items', 'Total', 'Status'];
  
  // 2. Convert orders to CSV rows
  const rows = filteredOrders.map(order => [
    order.id.slice(-6),
    new Date(order.timestamp).toLocaleDateString(),
    new Date(order.timestamp).toLocaleTimeString(),
    order.items.map(i => `${i.name} x${i.quantity}`).join(', '),
    order.total,
    order.status.toUpperCase()
  ]);
  
  // 3. Combine headers and rows
  const csv = [
    headers.join(','),
    ...rows.map(row => row.join(','))
  ].join('\n');
  
  // 4. Create downloadable file
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `orders-${new Date().toISOString().split('T')[0]}.csv`;
  a.click();
  
  // 5. Cleanup
  URL.revokeObjectURL(url);
  
  toast.success('Orders exported to CSV!');
};
```

### 5.3 Item & Category Management

#### 5.3.1 Add Item Flow (with Password Protection)

```typescript
// ItemManagement Component

const [newItem, setNewItem] = useState<MenuItem>({
  id: '',
  name: '',
  price: 0,
  category: ''
});

const handleAddItem = () => {
  // Validation
  if (newItem.name && newItem.price && newItem.category) {
    // Generate unique ID
    const newItemWithId: MenuItem = {
      id: Date.now().toString(),
      name: newItem.name,
      price: newItem.price,
      category: newItem.category,
    };
    
    // Update parent state
    onUpdate([...items, newItemWithId]);
    
    // Reset form
    setNewItem({ id: '', name: '', price: 0, category: '' });
    setDialogOpen(false);
    
    toast.success(`${newItem.name} added successfully!`);
  }
};
```

#### 5.3.2 Delete Item with Password Protection

```typescript
// Security layer for sensitive operations

const [showPasswordDialog, setShowPasswordDialog] = useState(false);
const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);

// Check if password protection enabled
const isPasswordProtected = () => {
  return !!localStorage.getItem('adminPassword');
};

// Delete button clicked
const handleDeleteClick = (id: string) => {
  if (isPasswordProtected()) {
    // Show password dialog first
    setPendingDeleteId(id);
    setShowPasswordDialog(true);
  } else {
    // Direct delete if no password
    onUpdate(items.filter((item) => item.id !== id));
  }
};

// Password verification success
const handlePasswordSuccess = () => {
  if (pendingDeleteId) {
    // Execute delayed delete
    onUpdate(items.filter((item) => item.id !== pendingDeleteId));
    setPendingDeleteId(null);
    toast.success('Item deleted successfully!');
  }
};

// PasswordDialog Component
<PasswordDialog
  open={showPasswordDialog}
  onClose={() => setShowPasswordDialog(false)}
  onSuccess={handlePasswordSuccess}
  title="Delete Item"
  description="Enter admin password to delete this item"
/>
```

### 5.4 Statistics & Analytics

#### 5.4.1 Revenue Calculation

```typescript
// Statistics Component

const calculateRevenue = () => {
  return {
    totalRevenue: orders
      .filter(o => o.status === 'paid')
      .reduce((sum, order) => sum + order.total, 0),
    
    totalOrders: orders.filter(o => o.status === 'paid').length,
    
    pendingRevenue: orders
      .filter(o => o.status === 'active')
      .reduce((sum, order) => sum + order.total, 0),
    
    averageOrderValue: orders.length > 0
      ? orders.reduce((sum, order) => sum + order.total, 0) / orders.length
      : 0
  };
};
```

#### 5.4.2 Most Sold Items Analysis

```typescript
// Aggregate item sales across all paid orders

const getMostSoldItems = () => {
  const itemSales: Record<string, { name: string; quantity: number; revenue: number }> = {};
  
  // Iterate through paid orders
  orders
    .filter(o => o.status === 'paid')
    .forEach(order => {
      order.items.forEach(item => {
        if (itemSales[item.id]) {
          // Existing item: Add to quantity and revenue
          itemSales[item.id].quantity += item.quantity;
          itemSales[item.id].revenue += item.price * item.quantity;
        } else {
          // New item: Initialize
          itemSales[item.id] = {
            name: item.name,
            quantity: item.quantity,
            revenue: item.price * item.quantity
          };
        }
      });
    });
  
  // Sort by quantity and return top 5
  return Object.values(itemSales)
    .sort((a, b) => b.quantity - a.quantity)
    .slice(0, 5);
};
```

### 5.5 Receipt & Thermal Printing System

#### 5.5.1 Print Preview Dialog

```typescript
// PrintPreview Component
// Shows receipt preview before printing, creates order on confirm

<Dialog open={open} onOpenChange={onOpenChange}>
  <DialogContent className="max-w-sm">
    {/* Preview of thermal receipt */}
    <div className="bg-white p-4 rounded-lg border">
      {/* Business Logo */}
      {config.logo?.enabled && (
        <img src={config.logo.imageUrl} alt="Logo" />
      )}
      
      {/* Business Name */}
      <h2>{config.business?.businessName || config.header}</h2>
      
      {/* Items List */}
      {items.map(item => (
        <div key={item.id}>
          {item.name} x{item.quantity} = ₹{item.price * item.quantity}
        </div>
      ))}
      
      {/* Total */}
      <div>Grand Total: ₹{total}</div>
      
      {/* QR Code Placeholder */}
      {config.qrCode?.enabled && (
        <div>QR Code: Order #{orderId.slice(-6)}</div>
      )}
    </div>
    
    {/* Action Buttons */}
    <Button onClick={onPrint}>Print & Create Order</Button>
    <Button onClick={() => onOpenChange(false)} variant="outline">
      Cancel
    </Button>
  </DialogContent>
</Dialog>
```

#### 5.5.2 Thermal Printer Receipt Generation

```typescript
// Advanced thermal printing with 58mm paper formatting

const handleThermalPrint = async (orderId: string) => {
  // 1. Generate QR code
  const qrData = JSON.stringify({
    orderId: orderId,
    amount: calculateTotal(),
    timestamp: new Date().toISOString(),
  });
  
  let qrCodeDataUrl = '';
  try {
    qrCodeDataUrl = await QRCode.toDataURL(qrData, {
      width: 200,
      margin: 1,
    });
  } catch (error) {
    console.error('QR code generation failed:', error);
  }
  
  // 2. Open new window for printing
  const printWindow = window.open('', '_blank');
  
  if (printWindow) {
    // 3. Build HTML receipt
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Receipt</title>
        <style>
          @page {
            size: 58mm auto;  /* Thermal paper width */
            margin: 0;
          }
          body {
            font-family: 'Courier New', monospace;
            width: 58mm;
            margin: 0;
            padding: 8px;
            font-size: 11px;
            line-height: 1.4;
          }
          .center { text-align: center; }
          .header {
            font-size: 18px;
            font-weight: bold;
            text-align: center;
            text-transform: uppercase;
          }
          table {
            width: 100%;
            border-collapse: collapse;
          }
          th, td {
            padding: 3px 0;
            font-size: 10px;
          }
          .divider {
            border-top: 1px dashed #000;
            margin: 4px 0;
          }
          .grand-total {
            font-weight: bold;
            font-size: 13px;
          }
          .qr-code img {
            width: 120px;
            height: 120px;
          }
        </style>
      </head>
      <body>
        <!-- Logo -->
        ${config.logo?.imageUrl ? 
          `<div class="center"><img src="${config.logo.imageUrl}" style="width: 60px; height: 60px;" /></div>` 
          : ''}
        
        <!-- Business Info -->
        <div class="header">${config.business?.businessName || config.header}</div>
        ${config.business?.address ? `<div class="center">${config.business.address}</div>` : ''}
        
        <!-- Date & Time -->
        <div class="center">
          Date/Time: ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}
        </div>
        
        <div class="divider"></div>
        
        <!-- Items Table -->
        <table>
          <thead>
            <tr>
              <th>Item</th>
              <th>QTY</th>
              <th>Price</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            ${billItems.map(item => `
              <tr>
                <td>${item.name}</td>
                <td class="center">${item.quantity}</td>
                <td class="right">${item.price}</td>
                <td class="right">${item.price * item.quantity}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
        
        <div class="divider"></div>
        
        <!-- Grand Total -->
        <div class="grand-total center">
          Grand Total: Rs ${calculateTotal()}
        </div>
        
        <!-- Footer -->
        <div class="center">
          ${config.footer?.text || 'Thank you for your visit!'}
        </div>
        
        <!-- QR Code -->
        ${qrCodeDataUrl ? `
          <div class="qr-code center">
            <div>Scan to track payment</div>
            <img src="${qrCodeDataUrl}" alt="Order QR" />
            <div>Order ID: #${orderId.slice(-6)}</div>
          </div>
        ` : ''}
      </body>
      </html>
    `);
    
    // 4. Close document and trigger print
    printWindow.document.close();
    printWindow.print();
    printWindow.close();
  }
};
```

---

## 6. WHITE-LABEL SYSTEM

### 6.1 Architecture Overview

The white-label system allows businesses to customize the POS app with their own branding while maintaining "Powered by Gastrolabs" attribution.

#### 6.1.1 Branding Configuration Flow

```typescript
// White-label data stored in receiptConfig

interface WhiteLabelConfig {
  // From receiptConfig.business
  businessName: string;          // Custom business name
  address: string;               // Used as tagline in header
  
  // From receiptConfig (new fields)
  businessLogo?: string;         // Base64 encoded custom logo
  primaryColor?: string;         // Brand primary color (future use)
  secondaryColor?: string;       // Brand secondary color (future use)
  accentColor?: string;          // Brand accent color (future use)
}
```

#### 6.1.2 Dynamic Header Rendering

```typescript
// App.tsx - Header component

<div className="bg-gradient-to-r from-[#EAEF9D] via-[#80B155] to-[#336A29] px-6 py-3">
  <div className="flex items-center gap-3">
    {/* Logo: Custom or Default */}
    <img 
      src={receiptConfig.businessLogo || defaultLogo} 
      alt="Logo" 
      className="h-10 w-10 object-contain rounded-full ring-2 ring-white/30" 
    />
    
    {/* Business Name: Custom or Default */}
    <div>
      <h1 className="text-white font-bold">
        {receiptConfig.business?.businessName || "Vada & Gossip"}
      </h1>
      <p className="text-white/90 text-xs">
        {receiptConfig.business?.address || "Quick Service POS"}
      </p>
    </div>
  </div>
</div>
```

### 6.2 Branding Settings Component

#### 6.2.1 Logo Upload System

```typescript
// BrandingSettings Component

const handleLogoUpload = () => {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  
  input.onchange = (e) => {
    const file = (e.target as HTMLInputElement).files?.[0];
    
    if (file) {
      // Convert to Base64
      const reader = new FileReader();
      
      reader.onload = (event) => {
        const imageUrl = event.target?.result as string;
        
        // Update config
        setConfig({ 
          ...config, 
          businessLogo: imageUrl  // Base64 data URL
        });
      };
      
      reader.readAsDataURL(file);
    }
  };
  
  input.click();
};

// Storage: Saved in localStorage as part of receiptConfig
// Future: Upload to Supabase storage, store URL reference
```

#### 6.2.2 Brand Color System (Future Feature)

```typescript
// Color configuration saved but not yet applied to UI

const handleColorChange = (colorType: 'primary' | 'secondary' | 'accent', value: string) => {
  setConfig({
    ...config,
    [`${colorType}Color`]: value
  });
};

// Future implementation:
// - Generate CSS variables from saved colors
// - Apply theme dynamically using Tailwind CSS
// - Store in CSS custom properties

// Example future implementation:
document.documentElement.style.setProperty('--color-primary', config.primaryColor);
```

### 6.3 Gastrolabs Attribution System

#### 6.3.1 Attribution Placement

```typescript
// 1. Branding Settings Page - Top Banner
<div className="bg-gradient-to-r from-[#C1D95C] to-[#80B155] rounded-2xl p-6">
  <img src={gastrolabsLogo} alt="Gastrolabs" className="h-12" />
  <p>White-Label POS Platform</p>
  <p>Powered by Gastrolabs - Food Service Software Solutions</p>
</div>

// 2. Settings Hub - "About Gastrolabs" Section
<Button onClick={() => setCurrentView('about-gastrolabs')}>
  <Info />
  About Gastrolabs
</Button>

// 3. About Page - Full company information
- Logo & branding
- App version
- Features
- Contact information
- Mission statement
- Industries served
- Legal links
```

#### 6.3.2 About Gastrolabs Page Structure

```typescript
// AboutGastrolabs Component

export function AboutGastrolabs({ onBack }: AboutGastrolabsProps) {
  return (
    <div>
      {/* Gastrolabs Branding Hero */}
      <div className="gradient-bg text-center">
        <img src={gastrolabsLogo} className="h-20" />
        <h2>GASTROLABS</h2>
        <p>Enterprise Software for Food Service & Hospitality Industry</p>
      </div>
      
      {/* App Info */}
      <div>
        Version: 1.0.0
        Build: 2025.01
        Platform: Web, iOS, Android
        License: White-Label SaaS
      </div>
      
      {/* Features */}
      - Fast POS Operations
      - White-Label Ready
      - Global Food Industry
      
      {/* Contact */}
      - Website: www.gastrolabs.com
      - Email: support@gastrolabs.com
      - Phone: +1 (234) 567-890
      
      {/* Mission */}
      "Empowers food service businesses worldwide..."
      
      {/* Industries */}
      - Restaurants, Cafes, Tea Shops, etc. (12+ types)
      
      {/* Legal */}
      - Terms of Service
      - Privacy Policy
      - White-Label License Agreement
      
      {/* Copyright */}
      © 2025 Gastrolabs. All rights reserved.
    </div>
  );
}
```

---

## 7. BUSINESS LOGIC & WORKFLOWS

### 7.1 Critical Business Rules

#### 7.1.1 Order Creation Rules

```typescript
// RULE 1: Orders always start as UNPAID
// Reason: Payment happens AFTER printing receipt

const createOrder = () => {
  const newOrder: Order = {
    id: Date.now().toString(),
    items: [...billItems],
    total: calculateTotal(),
    timestamp: new Date(),
    status: 'active'  // ❌ UNPAID by default
  };
  
  // User must manually mark as paid later
};

// RULE 2: Bills must have items
if (billItems.length === 0) {
  toast.error('Cannot checkout empty bill!');
  return;
}

// RULE 3: Order ID generated before printing
// Ensures QR code contains correct order reference
const orderId = Date.now().toString();
setCurrentOrderId(orderId);
```

#### 7.1.2 Item Quantity Merging

```typescript
// RULE: Same item clicked multiple times = increase quantity
// Controlled by appSettings.mergeSimilarItems

const addItem = (item: MenuItem) => {
  setBillItems((prev) => {
    const existing = prev.find((i) => i.id === item.id);
    
    if (existing && appSettings.mergeSimilarItems) {
      // Merge: Increment quantity
      return prev.map((i) =>
        i.id === item.id 
          ? { ...i, quantity: i.quantity + 1 }
          : i
      );
    } else {
      // Don't merge: Add as separate line item
      return [...prev, { ...item, quantity: 1 }];
    }
  });
};
```

#### 7.1.3 Category Filtering Logic

```typescript
// Multi-stage filtering: Search → Category

let displayedItems = menuItems;

// Stage 1: Text search (if query present)
if (searchQuery.trim()) {
  displayedItems = displayedItems.filter((item) =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.category.toLowerCase().includes(searchQuery.toLowerCase())
  );
}

// Stage 2: Category filter (if category selected)
if (selectedCategory) {
  displayedItems = displayedItems.filter(
    (item) => item.category === selectedCategory
  );
}

// Note: Search and category filters can combine
// Example: Search "tea" + Category "Snacks" = empty results
```

### 7.2 Payment Workflow

```
┌────────────────────────────────────────────────────────┐
│         COMPLETE PAYMENT WORKFLOW                      │
└────────────────────────────────────────────────────────┘

[1] Customer Orders Items
     └─> Items added to bill (billItems state)

[2] Cashier Clicks "Checkout"
     └─> Print Preview opens
     └─> Order ID generated

[3] Cashier Confirms Print
     └─> Order created with status: 'active' (UNPAID)
     └─> Receipt printed with QR code
     └─> Bill cleared (ready for next customer)

[4] Customer Pays
     └─> Cash/Card/UPI payment received
     └─> Physical payment transaction happens

[5] Cashier Marks as Paid
     └─> Opens Order History
     └─> Finds order by ID or amount
     └─> Clicks "Mark as Paid"
     └─> Status: 'active' → 'paid'

[6] Optional: QR Code Verification
     └─> Customer scans QR on receipt
     └─> QR contains order metadata
     └─> Future: Auto-mark as paid via payment gateway
```

### 7.3 Password Protection System

#### 7.3.1 Password Setup Flow

```typescript
// PasswordSetup Component

const [currentPassword, setCurrentPassword] = useState('');
const [newPassword, setNewPassword] = useState('');
const [confirmPassword, setConfirmPassword] = useState('');

// Check if password exists
const hasPassword = !!localStorage.getItem('adminPassword');

// Set new password
const handleSetPassword = () => {
  if (newPassword.length < 4) {
    toast.error('Password must be at least 4 characters');
    return;
  }
  
  if (newPassword !== confirmPassword) {
    toast.error('Passwords do not match');
    return;
  }
  
  // Hash password (simple - future: use bcrypt)
  const hashedPassword = btoa(newPassword); // Base64 encoding
  
  // Store in localStorage
  localStorage.setItem('adminPassword', hashedPassword);
  
  toast.success('Password set successfully!');
};

// Change existing password
const handleChangePassword = () => {
  const storedPassword = localStorage.getItem('adminPassword');
  
  if (btoa(currentPassword) !== storedPassword) {
    toast.error('Current password incorrect');
    return;
  }
  
  // Proceed with setting new password
  handleSetPassword();
};
```

#### 7.3.2 Password Verification Flow

```typescript
// PasswordDialog Component
// Used for: Delete items, Delete orders, Sensitive settings

const [passwordInput, setPasswordInput] = useState('');

const handleSubmit = () => {
  const storedPassword = localStorage.getItem('adminPassword');
  
  // Verify password
  if (btoa(passwordInput) === storedPassword) {
    onSuccess();  // Execute protected action
    onClose();    // Close dialog
    toast.success('Verified ✓');
  } else {
    toast.error('Incorrect password');
    setPasswordInput('');  // Clear input
  }
};

// Usage in components
<PasswordDialog
  open={showPasswordDialog}
  onClose={() => setShowPasswordDialog(false)}
  onSuccess={handleDeleteItem}
  title="Delete Item"
  description="Enter admin password to delete this item"
/>
```

---

## 8. SECURITY IMPLEMENTATION

### 8.1 Current Security Measures

#### 8.1.1 Password Storage

```typescript
// CURRENT (Weak - Development Only)
const hashedPassword = btoa(password);  // Base64 encoding
localStorage.setItem('adminPassword', hashedPassword);

// FUTURE IMPLEMENTATION (Production)
import bcrypt from 'bcryptjs';

const hashedPassword = await bcrypt.hash(password, 10);
localStorage.setItem('adminPassword', hashedPassword);

// Verification
const isValid = await bcrypt.compare(inputPassword, storedHash);
```

#### 8.1.2 Protected Operations

```typescript
// Operations requiring password:
1. Delete menu items
2. Delete orders
3. Clear all data
4. Change password

// Implementation pattern:
if (isPasswordProtected()) {
  showPasswordDialog();
} else {
  executeOperation();
}
```

### 8.2 Data Security Considerations

#### 8.2.1 LocalStorage Security

```typescript
// RISK: localStorage is accessible via browser DevTools
// MITIGATION: Don't store sensitive data

// Safe to store:
✅ Menu items (public data)
✅ Categories (public data)
✅ App settings (non-sensitive)
✅ Receipt configuration (non-sensitive)

// Should NOT store (future considerations):
❌ Customer credit card numbers
❌ Customer personal information
❌ Payment credentials
❌ API keys
```

#### 8.2.2 Future Security Enhancements

```typescript
// 1. Backend Authentication (Supabase)
const { user, session } = await supabase.auth.signUp({
  email: 'shop@example.com',
  password: 'secure_password'
});

// 2. Row-Level Security (RLS)
// Ensures users only see their own data
CREATE POLICY "Users can only see their own orders"
ON orders FOR SELECT
USING (auth.uid() = user_id);

// 3. API Key Management
// Store sensitive keys in environment variables
const RAZORPAY_KEY = import.meta.env.VITE_RAZORPAY_KEY;

// 4. HTTPS Only
// Enforce secure connections in production
```

---

## 9. PRINT & RECEIPT SYSTEM

### 9.1 Receipt Configuration System

#### 9.1.1 Modular Receipt Builder

```typescript
// Receipt is built from multiple optional components

const buildReceipt = () => {
  const components = [];
  
  // 1. Logo (optional)
  if (config.logo?.enabled) {
    components.push(renderLogo());
  }
  
  // 2. Business Info (optional)
  if (config.business?.enabled) {
    components.push(renderBusinessInfo());
  } else {
    components.push(renderSimpleHeader());
  }
  
  // 3. Date/Time (always)
  components.push(renderDateTime());
  
  // 4. Items Table (always)
  components.push(renderItemsTable());
  
  // 5. Taxes (optional)
  if (config.tax?.enabled) {
    components.push(renderTaxes());
  }
  
  // 6. Discounts (optional)
  if (config.discount?.enabled) {
    components.push(renderDiscount());
  }
  
  // 7. Fees (optional)
  if (config.fees?.enabled) {
    components.push(renderFees());
  }
  
  // 8. Total (always)
  components.push(renderGrandTotal());
  
  // 9. Footer (optional)
  if (config.footer?.enabled) {
    components.push(renderFooter());
  }
  
  // 10. QR Code (optional)
  if (config.qrCode?.enabled) {
    components.push(renderQRCode());
  }
  
  return components.join('');
};
```

#### 9.1.2 Invoice Sequencing System

```typescript
// SequenceSettings Component

interface SequenceConfig {
  enabled: boolean;
  prefix: string;        // e.g., "INV-"
  startNumber: number;   // e.g., 1
  format: 'simple' | 'padded' | 'date-number';
  padding: number;       // e.g., 3 → "001"
}

// Generate invoice number
const generateInvoiceNumber = (orderNumber: number) => {
  const config = receiptConfig.sequence;
  
  if (!config.enabled) return null;
  
  switch (config.format) {
    case 'simple':
      // INV-123
      return `${config.prefix}${orderNumber}`;
    
    case 'padded':
      // INV-00123 (with padding)
      const paddedNum = orderNumber.toString().padStart(config.padding, '0');
      return `${config.prefix}${paddedNum}`;
    
    case 'date-number':
      // INV-20250124-00123
      const date = new Date().toISOString().split('T')[0].replace(/-/g, '');
      const padded = orderNumber.toString().padStart(config.padding, '0');
      return `${config.prefix}${date}-${padded}`;
    
    default:
      return `${config.prefix}${orderNumber}`;
  }
};

// Usage in receipt
<div>Invoice No: {generateInvoiceNumber(orderCount)}</div>
```

### 9.2 Thermal Printer Integration

#### 9.2.1 Printer Connection Types

```typescript
// PrinterSettings Component

interface PrinterConfig {
  connectionType: 'wifi' | 'bluetooth' | 'usb';
  printerName: string;
  ipAddress: string;     // WiFi only
  port: string;          // WiFi only
  autoPrint: boolean;
  paperWidth: '58mm' | '80mm';
  encoding: 'UTF-8' | 'ISO-8859-1';
}

// WiFi Printer Discovery (Mock - requires actual printer API)
const discoverWiFiPrinters = async () => {
  // Future: Use printer manufacturer's SDK
  // Example: Epson ePOS SDK, Star Micronics SDK
  
  try {
    const printers = await window.printerSDK.discover();
    setDiscoveredDevices(printers);
  } catch (error) {
    toast.error('Printer discovery failed');
  }
};
```

#### 9.2.2 Paper Width Optimization

```typescript
// CSS styles adjusted based on paper width

const getPaperStyles = (width: '58mm' | '80mm') => {
  return `
    @page {
      size: ${width} auto;
      margin: 0;
    }
    body {
      width: ${width};
      font-size: ${width === '58mm' ? '11px' : '12px'};
    }
  `;
};

// Receipt layout adjusts automatically
```

### 9.3 QR Code Integration

#### 9.3.1 QR Code Generation

```typescript
import QRCode from 'qrcode';

// Generate QR code for order
const generateOrderQR = async (orderId: string, amount: number) => {
  const qrData = JSON.stringify({
    orderId: orderId,
    amount: amount,
    timestamp: new Date().toISOString(),
    businessId: 'gastrolabs_demo', // Future: Unique business ID
  });
  
  try {
    const qrCodeDataUrl = await QRCode.toDataURL(qrData, {
      width: 200,
      margin: 1,
      color: {
        dark: '#000000',
        light: '#FFFFFF'
      }
    });
    
    return qrCodeDataUrl;
  } catch (error) {
    console.error('QR generation failed:', error);
    return null;
  }
};
```

#### 9.3.2 QR Code Types

```typescript
// QRCodeSettings Component

interface QRCodeConfig {
  enabled: boolean;
  type: 'upi' | 'url' | 'text';
  upiId: string;
  url: string;
  text: string;
  size: 'small' | 'medium' | 'large';
  label: string;
}

// Generate QR based on type
const generateQRContent = () => {
  switch (config.type) {
    case 'upi':
      // UPI payment string
      return `upi://pay?pa=${config.upiId}&pn=Business&am=${amount}&cu=INR&tn=Order${orderId}`;
    
    case 'url':
      // Payment gateway URL
      return `${config.url}?order=${orderId}&amount=${amount}`;
    
    case 'text':
      // Custom text/JSON
      return config.text.replace('{orderId}', orderId).replace('{amount}', amount.toString());
    
    default:
      return JSON.stringify({ orderId, amount });
  }
};
```

---

## 10. DATA PERSISTENCE & EXPORT

### 10.1 Export System

#### 10.1.1 Full Data Export

```typescript
// DataSettings Component

const handleExportData = () => {
  // 1. Collect all state
  const data = {
    menuItems,
    categories,
    orders,
    appSettings,
    receiptConfig,
    printerConfig,
    emailConfig,
    messageConfig,
    exportDate: new Date().toISOString(),
    appVersion: '1.0.0'
  };
  
  // 2. Convert to JSON string
  const jsonString = JSON.stringify(data, null, 2);
  
  // 3. Create Blob
  const blob = new Blob([jsonString], { type: 'application/json' });
  
  // 4. Create download link
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `gastrolabs-pos-backup-${new Date().toISOString().split('T')[0]}.json`;
  
  // 5. Trigger download
  a.click();
  
  // 6. Cleanup
  URL.revokeObjectURL(url);
  
  toast.success('Data exported successfully!');
};
```

#### 10.1.2 Data Import

```typescript
const handleImportData = () => {
  // 1. Create file input
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.json';
  
  input.onchange = (e) => {
    const file = (e.target as HTMLInputElement).files?.[0];
    
    if (file) {
      // 2. Read file
      const reader = new FileReader();
      
      reader.onload = (event) => {
        try {
          // 3. Parse JSON
          const data = JSON.parse(event.target?.result as string);
          
          // 4. Validate data structure
          if (!data.menuItems || !data.orders) {
            throw new Error('Invalid data format');
          }
          
          // 5. Restore state
          if (data.menuItems) setMenuItems(data.menuItems);
          if (data.categories) setCategories(data.categories);
          if (data.orders) setOrders(data.orders);
          if (data.appSettings) setAppSettings(data.appSettings);
          if (data.receiptConfig) setReceiptConfig(data.receiptConfig);
          if (data.printerConfig) setPrinterConfig(data.printerConfig);
          if (data.emailConfig) setEmailConfig(data.emailConfig);
          if (data.messageConfig) setMessageConfig(data.messageConfig);
          
          toast.success('Data imported successfully!');
        } catch (error) {
          toast.error('Failed to import data. Invalid file format.');
        }
      };
      
      reader.readAsText(file);
    }
  };
  
  input.click();
};
```

#### 10.1.3 Clear All Data

```typescript
// DESTRUCTIVE OPERATION - Requires password confirmation

const handleClearData = () => {
  // 1. Show confirmation dialog
  if (!confirm('This will delete ALL data. Are you sure?')) {
    return;
  }
  
  // 2. Reset to defaults
  setMenuItems(DEFAULT_ITEMS);
  setCategories(DEFAULT_CATEGORIES);
  setOrders([]);
  setAppSettings(DEFAULT_APP_SETTINGS);
  setReceiptConfig(DEFAULT_RECEIPT_CONFIG);
  setPrinterConfig(DEFAULT_PRINTER_CONFIG);
  setEmailConfig(DEFAULT_EMAIL_CONFIG);
  setMessageConfig(DEFAULT_MESSAGE_CONFIG);
  setBillItems([]);
  
  // 3. Clear localStorage (if implemented)
  localStorage.clear();
  
  toast.success('All data cleared successfully!');
  
  // 4. Navigate back to POS
  setCurrentView('pos');
};
```

### 10.2 Future: LocalStorage Auto-Save

```typescript
// Implementation plan for automatic persistence

// 1. Save on every state change
useEffect(() => {
  const dataToSave = {
    menuItems,
    categories,
    orders,
    appSettings,
    receiptConfig,
    printerConfig,
    emailConfig,
    messageConfig
  };
  
  localStorage.setItem('gastrolabs_pos_data', JSON.stringify(dataToSave));
}, [menuItems, categories, orders, appSettings, receiptConfig, printerConfig, emailConfig, messageConfig]);

// 2. Load on app startup
useEffect(() => {
  const savedData = localStorage.getItem('gastrolabs_pos_data');
  
  if (savedData) {
    try {
      const data = JSON.parse(savedData);
      
      setMenuItems(data.menuItems || DEFAULT_ITEMS);
      setCategories(data.categories || DEFAULT_CATEGORIES);
      setOrders(data.orders || []);
      // ... restore all state
    } catch (error) {
      console.error('Failed to load saved data:', error);
    }
  }
}, []);

// 3. Storage size management
const getStorageSize = () => {
  const data = JSON.stringify({
    menuItems,
    categories,
    orders,
    appSettings,
    receiptConfig
  });
  
  const bytes = new Blob([data]).size;
  const kb = (bytes / 1024).toFixed(2);
  
  return `${kb} KB`;
};

// Warning if approaching 5MB limit
if (bytes > 4_500_000) {
  toast.warning('Storage almost full. Consider exporting old orders.');
}
```

---

## 11. PAYMENT & QR CODE INTEGRATION

### 11.1 Current Implementation (Manual)

```typescript
// Current payment flow is completely manual

[1] Receipt printed with QR code
     └─> QR contains order metadata (ID, amount, timestamp)

[2] Customer scans QR code
     └─> QR reader shows JSON data
     └─> No automatic payment processing

[3] Customer pays via external method
     └─> Cash, card, UPI app, etc.

[4] Cashier manually marks order as paid
     └─> Status: 'active' → 'paid'
```

### 11.2 Future: Payment Gateway Integration

#### 11.2.1 Razorpay Integration (Planned)

```typescript
// Step 1: Initialize Razorpay
import Razorpay from 'razorpay';

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_SECRET,
});

// Step 2: Create payment order
const createPaymentOrder = async (amount: number, orderId: string) => {
  const options = {
    amount: amount * 100,  // Razorpay uses paise
    currency: 'INR',
    receipt: orderId,
    notes: {
      orderId: orderId,
      businessId: 'gastrolabs_demo'
    }
  };
  
  const order = await razorpay.orders.create(options);
  return order;
};

// Step 3: Generate payment QR code
const generatePaymentQR = async (amount: number, orderId: string) => {
  const order = await createPaymentOrder(amount, orderId);
  
  // Payment URL for QR code
  const paymentUrl = `https://razorpay.com/payment/${order.id}`;
  
  const qrCode = await QRCode.toDataURL(paymentUrl);
  return qrCode;
};

// Step 4: Webhook for payment confirmation
app.post('/webhook/razorpay', (req, res) => {
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
  const signature = req.headers['x-razorpay-signature'];
  
  // Verify signature
  const isValid = Razorpay.validateWebhookSignature(
    JSON.stringify(req.body),
    signature,
    secret
  );
  
  if (isValid && req.body.event === 'payment.captured') {
    const orderId = req.body.payload.payment.notes.orderId;
    
    // Auto-mark order as paid in database
    await markOrderAsPaid(orderId);
  }
  
  res.status(200).send('OK');
});
```

#### 11.2.2 UPI Integration

```typescript
// UPI Deep Link Format

const generateUPILink = (
  upiId: string,
  amount: number,
  orderId: string,
  businessName: string
) => {
  const params = new URLSearchParams({
    pa: upiId,                    // Payee address
    pn: businessName,             // Payee name
    am: amount.toString(),        // Amount
    cu: 'INR',                    // Currency
    tn: `Order ${orderId}`,       // Transaction note
  });
  
  return `upi://pay?${params.toString()}`;
};

// Generate UPI QR code
const upiLink = generateUPILink(
  'gastrolabs@paytm',
  150,
  '1704123456789',
  'Vada & Gossip'
);

const qrCode = await QRCode.toDataURL(upiLink);

// Customer scans → Opens UPI app → Completes payment
// Verification still manual (future: UPI callback API)
```

### 11.3 QR Scanner Component

```typescript
// QRScanner Component
// Used in Order History to scan payment QR codes

import { Html5QrcodeScanner } from 'html5-qrcode';

export function QRScanner({ onScanSuccess, onClose }: QRScannerProps) {
  useEffect(() => {
    // Initialize scanner
    const scanner = new Html5QrcodeScanner(
      'qr-reader',
      { fps: 10, qrbox: 250 },
      false
    );
    
    // Handle scan result
    scanner.render(
      (decodedText) => {
        try {
          // Parse QR data
          const data = JSON.parse(decodedText);
          
          // Extract order ID
          if (data.orderId) {
            onScanSuccess(data.orderId);
            scanner.clear();
          }
        } catch (error) {
          toast.error('Invalid QR code');
        }
      },
      (error) => {
        console.log('Scan error:', error);
      }
    );
    
    return () => {
      scanner.clear();
    };
  }, []);
  
  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent>
        <div id="qr-reader"></div>
      </DialogContent>
    </Dialog>
  );
}

// Usage in OrderHistory
const handleScanQR = () => {
  setShowQRScanner(true);
};

const handleQRSuccess = (orderId: string) => {
  // Find and mark order as paid
  const order = orders.find(o => o.id === orderId);
  
  if (order) {
    handleMarkAsPaid(orderId);
    toast.success('Payment verified via QR scan!');
  } else {
    toast.error('Order not found');
  }
  
  setShowQRScanner(false);
};
```

---

## 12. FUTURE DEVELOPMENT ROADMAP

### 12.1 Phase 1: Backend Integration (Q1 2025)

```typescript
// Supabase Setup

// 1. Database Schema
CREATE TABLE businesses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  logo_url TEXT,
  primary_color TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE menu_items (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  business_id UUID REFERENCES businesses(id),
  name TEXT NOT NULL,
  price DECIMAL NOT NULL,
  category TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  business_id UUID REFERENCES businesses(id),
  items JSONB NOT NULL,
  total DECIMAL NOT NULL,
  status TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  paid_at TIMESTAMP
);

// 2. Row-Level Security
ALTER TABLE menu_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can only see their own items"
ON menu_items FOR SELECT
USING (business_id = auth.uid());

// 3. React Integration
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_ANON_KEY!
);

// Sync menu items
const syncMenuItems = async () => {
  const { data, error } = await supabase
    .from('menu_items')
    .select('*')
    .eq('business_id', user.id);
  
  if (data) {
    setMenuItems(data);
  }
};

// Real-time subscriptions
supabase
  .channel('orders')
  .on('postgres_changes', {
    event: 'INSERT',
    schema: 'public',
    table: 'orders'
  }, (payload) => {
    setOrders(prev => [payload.new, ...prev]);
  })
  .subscribe();
```

### 12.2 Phase 2: Advanced Features (Q2 2025)

#### 12.2.1 Multi-User Support

```typescript
// User roles and permissions

enum UserRole {
  OWNER = 'owner',        // Full access
  MANAGER = 'manager',    // All except business settings
  CASHIER = 'cashier',    // POS operations only
  VIEWER = 'viewer'       // Read-only access
}

interface User {
  id: string;
  email: string;
  role: UserRole;
  businessId: string;
}

// Permission checks
const canDeleteItem = (user: User) => {
  return [UserRole.OWNER, UserRole.MANAGER].includes(user.role);
};

const canChangeSettings = (user: User) => {
  return user.role === UserRole.OWNER;
};
```

#### 12.2.2 Inventory Management

```typescript
interface InventoryItem extends MenuItem {
  stock: number;
  lowStockThreshold: number;
  unit: string;  // kg, liters, pieces
}

// Stock tracking
const reduceStock = (itemId: string, quantity: number) => {
  const item = inventoryItems.find(i => i.id === itemId);
  
  if (item) {
    item.stock -= quantity;
    
    // Low stock alert
    if (item.stock <= item.lowStockThreshold) {
      toast.warning(`Low stock: ${item.name} (${item.stock} ${item.unit} remaining)`);
    }
    
    // Out of stock
    if (item.stock <= 0) {
      toast.error(`Out of stock: ${item.name}`);
      // Disable item in POS
    }
  }
};
```

#### 12.2.3 Customer Management

```typescript
interface Customer {
  id: string;
  name: string;
  phone: string;
  email: string;
  totalOrders: number;
  totalSpent: number;
  lastVisit: Date;
  loyaltyPoints: number;
}

// Loyalty program
const addLoyaltyPoints = (customerId: string, orderAmount: number) => {
  const points = Math.floor(orderAmount / 10); // 1 point per ₹10
  
  updateCustomer(customerId, {
    loyaltyPoints: customer.loyaltyPoints + points
  });
};
```

### 12.3 Phase 3: Mobile Apps (Q3 2025)

```typescript
// React Native conversion

// 1. Expo setup
npx expo init gastrolabs-pos-mobile

// 2. Shared codebase
// - UI components → React Native Paper
// - Tailwind CSS → NativeWind
// - Print → Bluetooth printer SDK

// 3. Platform-specific features
import { Platform } from 'react-native';

const printReceipt = async () => {
  if (Platform.OS === 'web') {
    window.print();
  } else {
    // Use native printer module
    await BluetoothPrinter.print(receiptData);
  }
};
```

### 12.4 Phase 4: App Store Release (Q4 2025)

```typescript
// White-label distribution strategy

// 1. Base App (Free)
- Core POS features
- 100 orders/month limit
- Gastrolabs branding
- Single device

// 2. Professional ($29/month)
- Unlimited orders
- Custom branding
- Multi-device sync
- Email/SMS integration
- Priority support

// 3. Enterprise ($99/month)
- All Professional features
- Multi-location support
- Advanced analytics
- Custom integrations
- Dedicated account manager

// 4. White-Label License ($499/month)
- Complete rebranding
- Custom domain
- Remove Gastrolabs attribution
- Source code access (optional)
- Revenue sharing model
```

---

## 13. TECHNICAL SPECIFICATIONS

### 13.1 Performance Targets

```typescript
// Key performance indicators

const PERFORMANCE_TARGETS = {
  // Page Load
  initialLoad: '< 2 seconds',
  routeChange: '< 200ms',
  
  // User Interactions
  buttonClick: '< 100ms',
  searchFilter: '< 50ms',
  
  // Data Operations
  addItem: '< 50ms',
  checkout: '< 500ms',
  print: '< 3 seconds',
  
  // Bundle Size
  mainBundle: '< 500KB',
  totalAssets: '< 2MB',
  
  // Mobile Performance
  firstContentfulPaint: '< 1.5s',
  timeToInteractive: '< 3.5s'
};
```

### 13.2 Browser Compatibility

```typescript
// Supported browsers

const BROWSER_SUPPORT = {
  chrome: '>= 90',
  firefox: '>= 88',
  safari: '>= 14',
  edge: '>= 90',
  
  // Mobile browsers
  chromeMobile: '>= 90',
  safariMobile: '>= 14'
};

// Polyfills required for older browsers
import 'core-js/stable';
import 'regenerator-runtime/runtime';
```

### 13.3 Accessibility (WCAG 2.1 AA)

```typescript
// Accessibility features

const ACCESSIBILITY_FEATURES = {
  // Keyboard Navigation
  tabIndex: 'All interactive elements',
  focusVisible: 'Clear focus indicators',
  shortcuts: 'Alt+N (New Order), Alt+H (History)',
  
  // Screen Reader Support
  ariaLabels: 'Descriptive labels on all buttons',
  ariaLive: 'Dynamic content announcements',
  semanticHTML: 'Proper heading hierarchy',
  
  // Visual
  colorContrast: '> 4.5:1 ratio',
  fontSize: 'Minimum 14px',
  touchTargets: 'Minimum 44x44px',
  
  // Internationalization
  lang: 'HTML lang attribute',
  rtl: 'Right-to-left support (future)'
};
```

---

## 14. DEPLOYMENT GUIDE

### 14.1 Development Setup

```bash
# 1. Clone repository
git clone https://github.com/gastrolabs/pos-platform.git
cd pos-platform

# 2. Install dependencies
npm install

# 3. Environment variables
cp .env.example .env.local

# Edit .env.local:
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_anon_key
VITE_RAZORPAY_KEY=your_razorpay_key

# 4. Start development server
npm run dev

# 5. Open browser
# http://localhost:5173
```

### 14.2 Production Build

```bash
# 1. Build for production
npm run build

# 2. Output location
# dist/ folder

# 3. Preview production build
npm run preview

# 4. Deploy to hosting
# Vercel
vercel --prod

# Netlify
netlify deploy --prod

# Firebase
firebase deploy
```

### 14.3 Environment Configuration

```typescript
// .env.local structure

# App Configuration
VITE_APP_NAME=Gastrolabs POS
VITE_APP_VERSION=1.0.0
VITE_API_URL=https://api.gastrolabs.com

# Supabase (Future)
VITE_SUPABASE_URL=https://xxxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOi...

# Payment Gateways (Future)
VITE_RAZORPAY_KEY=rzp_live_xxxxx
VITE_STRIPE_KEY=pk_live_xxxxx

# Feature Flags
VITE_ENABLE_ANALYTICS=true
VITE_ENABLE_PAYMENTS=false
VITE_ENABLE_MULTI_LOCATION=false
```

---

## 15. FILE STRUCTURE EXPLAINED

### 15.1 Core Application Files

```
/App.tsx
├─ Purpose: Root component, main application logic
├─ Responsibilities:
│  ├─ State management (all useState hooks)
│  ├─ View routing (currentView state)
│  ├─ Business logic (addItem, checkout, etc.)
│  ├─ Prop drilling to child components
│  └─ Default configurations (DEFAULT_ITEMS, etc.)
├─ Key Functions:
│  ├─ addItem() - Add item to current bill
│  ├─ handleCheckout() - Initiate checkout process
│  ├─ handleConfirmPrint() - Create order & print
│  ├─ handleThermalPrint() - Generate thermal receipt
│  ├─ handleMarkAsPaid() - Update order status
│  └─ calculateTotal() - Calculate bill total
└─ Lines of Code: ~1,037
```

### 15.2 Component Organization

```
/components/
│
├─ Core POS Components
│  ├─ ReceiptTape.tsx - Live bill display
│  ├─ Sidebar.tsx - Navigation & checkout buttons
│  ├─ PrintPreview.tsx - Receipt preview dialog
│  └─ QRScanner.tsx - QR code scanning for payments
│
├─ Management Screens
│  ├─ ItemManagement.tsx - CRUD for menu items
│  ├─ CategoryManagement.tsx - CRUD for categories
│  ├─ OrderHistory.tsx - Order list & payment tracking
│  └─ Statistics.tsx - Analytics dashboard
│
├─ Settings Hub
│  ├─ Settings.tsx - Main settings navigation
│  │
│  ├─ Receipt Customization
│  │  ├─ ReceiptSettings.tsx - Receipt configuration hub
│  │  ├─ LogoSettings.tsx - Logo upload & configuration
│  │  ├─ FooterSettings.tsx - Footer message
│  │  ├─ TimeFormatSettings.tsx - Date/time format
│  │  ├─ BusinessIdentity.tsx - Business info for receipts
│  │  ├─ SequenceSettings.tsx - Invoice numbering
│  │  ├─ TaxSettings.tsx - Tax configuration
│  │  ├─ DiscountSettings.tsx - Discount rules
│  │  ├─ FeesSettings.tsx - Additional fees
│  │  └─ QRCodeSettings.tsx - Payment QR codes
│  │
│  ├─ Hardware & Connectivity
│  │  ├─ PrinterSettings.tsx - Thermal printer config
│  │  ├─ EmailSettings.tsx - Email integration
│  │  └─ MessageSettings.tsx - SMS/iMessage integration
│  │
│  ├─ Data & Security
│  │  ├─ DataSettings.tsx - Export/import/backup
│  │  ├─ PasswordSetup.tsx - Password configuration
│  │  └─ PasswordDialog.tsx - Password verification modal
│  │
│  ├─ Localization
│  │  ├─ LanguageSettings.tsx - Multi-language support
│  │  └─ CurrencySettings.tsx - Currency symbols
│  │
│  └─ 🌟 White-Label System
│     ├─ BrandingSettings.tsx - Business branding config
│     └─ AboutGastrolabs.tsx - Company information
│
├─ Payment Dashboard
│  └─ PaymentDashboard.tsx - Payment tracking (future)
│
└─ UI Components (shadcn/ui)
   └─ /ui/ - 40+ reusable UI primitives
```

### 15.3 Styling & Assets

```
/styles/
└─ globals.css
   ├─ Tailwind v4.0 imports
   ├─ CSS custom properties (color tokens)
   ├─ Global typography rules
   └─ Print media queries

/assets/
└─ chai-logo.png - Default logo (Vada & Gossip)

Imported Assets (Figma):
├─ defaultLogo - Chai tea logo
└─ gastrolabsLogo - Gastrolabs company logo
```

---

## 16. API INTEGRATION GUIDE (Future)

### 16.1 Supabase Integration

```typescript
// supabase.ts - Client configuration

import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types
export interface Database {
  public: {
    Tables: {
      businesses: {
        Row: {
          id: string;
          name: string;
          email: string;
          logo_url: string | null;
          primary_color: string | null;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['businesses']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['businesses']['Insert']>;
      };
      menu_items: {
        Row: {
          id: string;
          business_id: string;
          name: string;
          price: number;
          category: string;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['menu_items']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['menu_items']['Insert']>;
      };
      orders: {
        Row: {
          id: string;
          business_id: string;
          items: any;
          total: number;
          status: string;
          created_at: string;
          paid_at: string | null;
        };
        Insert: Omit<Database['public']['Tables']['orders']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['orders']['Insert']>;
      };
    };
  };
}

// API hooks
export const useMenuItems = (businessId: string) => {
  const [items, setItems] = useState<MenuItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchItems = async () => {
      const { data, error } = await supabase
        .from('menu_items')
        .select('*')
        .eq('business_id', businessId);

      if (data) setItems(data);
      setLoading(false);
    };

    fetchItems();

    // Real-time subscription
    const subscription = supabase
      .channel('menu_items_changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'menu_items',
        filter: `business_id=eq.${businessId}`
      }, (payload) => {
        if (payload.eventType === 'INSERT') {
          setItems(prev => [...prev, payload.new]);
        } else if (payload.eventType === 'UPDATE') {
          setItems(prev => prev.map(item => 
            item.id === payload.new.id ? payload.new : item
          ));
        } else if (payload.eventType === 'DELETE') {
          setItems(prev => prev.filter(item => item.id !== payload.old.id));
        }
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [businessId]);

  return { items, loading };
};
```

---

## 17. TESTING STRATEGY

### 17.1 Unit Testing

```typescript
// Example: Item calculation tests

import { describe, it, expect } from 'vitest';
import { calculateTotal } from './App';

describe('Bill Calculation', () => {
  it('calculates total for single item', () => {
    const billItems = [
      { id: '1', name: 'Tea', price: 10, category: 'Tea', quantity: 2 }
    ];
    
    expect(calculateTotal(billItems)).toBe(20);
  });
  
  it('calculates total for multiple items', () => {
    const billItems = [
      { id: '1', name: 'Tea', price: 10, category: 'Tea', quantity: 2 },
      { id: '2', name: 'Samosa', price: 15, category: 'Snacks', quantity: 3 }
    ];
    
    expect(calculateTotal(billItems)).toBe(65); // (10*2) + (15*3)
  });
  
  it('handles empty bill', () => {
    expect(calculateTotal([])).toBe(0);
  });
});
```

### 17.2 Integration Testing

```typescript
// Example: Checkout workflow test

import { render, screen, fireEvent } from '@testing-library/react';
import App from './App';

describe('Checkout Flow', () => {
  it('creates order on checkout', async () => {
    render(<App />);
    
    // Add item to bill
    const teaButton = screen.getByText('Regular Tea');
    fireEvent.click(teaButton);
    
    // Click checkout
    const checkoutButton = screen.getByText('Checkout');
    fireEvent.click(checkoutButton);
    
    // Verify print preview opens
    expect(screen.getByText('Print Preview')).toBeInTheDocument();
    
    // Confirm print
    const confirmButton = screen.getByText('Print & Create Order');
    fireEvent.click(confirmButton);
    
    // Verify order created
    // (Would need to mock order state)
  });
});
```

---

## 18. TROUBLESHOOTING & FAQ

### 18.1 Common Issues

```typescript
// Issue 1: Print not working
Problem: Browser blocks window.open()
Solution: User must allow popups for the domain

// Issue 2: QR code not generating
Problem: qrcode library missing
Solution: npm install qrcode

// Issue 3: State not persisting
Problem: No localStorage implementation yet
Solution: Manual export/import for now

// Issue 4: Password reset locked out
Problem: Forgot admin password
Solution: localStorage.removeItem('adminPassword')

// Issue 5: Images not loading
Problem: Figma imports not resolving
Solution: Ensure figma:asset paths are correct
```

### 18.2 Performance Optimization

```typescript
// Optimization techniques

// 1. Memoize expensive calculations
const memoizedTotal = useMemo(() => 
  calculateTotal(billItems), 
  [billItems]
);

// 2. Virtualize large lists
import { FixedSizeList } from 'react-window';

<FixedSizeList
  height={600}
  itemCount={orders.length}
  itemSize={100}
>
  {({ index, style }) => (
    <OrderCard order={orders[index]} style={style} />
  )}
</FixedSizeList>

// 3. Lazy load settings pages
const LazyPrinterSettings = lazy(() => import('./components/PrinterSettings'));

// 4. Debounce search input
const debouncedSearch = useDebounce(searchQuery, 300);
```

---

## 19. CONTACT & SUPPORT

### 19.1 Gastrolabs Team

```
Technical Support:
├─ Email: support@gastrolabs.com
├─ Phone: +1 (234) 567-890
├─ Hours: 9 AM - 6 PM IST (Mon-Fri)
└─ Emergency: +1 (234) 567-891

Sales & White-Label Inquiries:
├─ Email: sales@gastrolabs.com
└─ Website: www.gastrolabs.com/contact

Developer Resources:
├─ Documentation: docs.gastrolabs.com
├─ API Reference: api.gastrolabs.com/docs
├─ GitHub: github.com/gastrolabs
└─ Discord: discord.gg/gastrolabs
```

---

## 20. CHANGELOG

```
Version 1.0.0 (January 2025)
├─ ✅ Core POS functionality
├─ ✅ Item & category management
├─ ✅ Order history tracking
├─ ✅ Thermal printer integration (58mm/80mm)
├─ ✅ Receipt customization (18+ settings)
├─ ✅ Password protection
├─ ✅ QR code generation
├─ ✅ Statistics dashboard
├─ ✅ CSV export
├─ ✅ Manual data export/import
├─ ✅ White-label branding system
└─ ✅ Gastrolabs company attribution

Coming in Version 1.1.0 (Q1 2025)
├─ 🔜 Supabase backend integration
├─ 🔜 Cloud sync across devices
├─ 🔜 Automatic localStorage persistence
├─ 🔜 Payment gateway integration (Razorpay)
├─ 🔜 Multi-user support
└─ 🔜 Mobile app (iOS/Android)
```

---

**END OF TECHNICAL DOCUMENTATION**

*This document is maintained by Gastrolabs development team.*  
*Last Updated: January 24, 2025*  
*Version: 1.0.0*
