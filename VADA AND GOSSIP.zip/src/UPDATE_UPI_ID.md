# 🔧 How to Update Your UPI ID

Your old UPI ID `jyothish.rajendran@federal` is cached in browser localStorage. Here's how to update it:

---

## 🚀 Quick Fix (Recommended)

### **Option 1: Update via App Settings**

1. Open your app
2. Go to: **Settings → Receipt Settings → Payment QR code**
3. Clear the current UPI ID field completely (delete all text)
4. Type your new UPI ID
5. Click back (the green check icon shows it saved)
6. **Refresh the page** (F5 or Cmd+R)
7. Done! ✅

---

## 🔍 Option 2: Clear Cache & Reconfigure

### **Step 1: Clear localStorage**
Open browser console (F12) and run:
```javascript
localStorage.removeItem('gastrolabs_receipt_config');
location.reload();
```

### **Step 2: Reconfigure**
After reload:
1. Go to Settings → Receipt Settings → Payment QR code
2. Enter your new UPI ID
3. Save and test

---

## 🛠️ Option 3: Manual localStorage Edit

### **Step 1: Open Console**
Press F12 → Go to "Console" tab

### **Step 2: View Current Config**
```javascript
JSON.parse(localStorage.getItem('gastrolabs_receipt_config'))
```

### **Step 3: Update UPI ID**
```javascript
const config = JSON.parse(localStorage.getItem('gastrolabs_receipt_config'));
config.paymentQR.upiId = 'YOUR_NEW_UPI_ID@paytm';  // ← Replace with your UPI
localStorage.setItem('gastrolabs_receipt_config', JSON.stringify(config));
location.reload();
```

---

## ✅ Verify It Worked

After updating:

1. Go to POS screen
2. Add an item
3. Click Checkout
4. Look at browser console

You should see:
```
🔍 PrintPreview - Generating UPI QR with: {
  upiId: 'YOUR_NEW_UPI_ID@paytm',  ← Your new UPI!
  businessName: 'VADA AND GOSSIP',
  total: 15
}
```

---

## 🎯 What's Your New UPI ID?

Tell me your new UPI ID and I can give you the exact command to paste!

---

## 🐛 Why This Happens

The app caches your settings in browser localStorage for:
- ✅ Faster loading
- ✅ Offline functionality
- ✅ Data persistence

But this means when you update settings, you need to:
1. Clear the old cached value completely
2. Enter the new value
3. Refresh the page to reload

---

## 💡 Pro Tip

After updating any critical setting like UPI ID:
1. Save the change
2. **Refresh the page** (F5)
3. Verify in console logs

This ensures the cache is updated!
