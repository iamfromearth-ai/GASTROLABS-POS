import { useState, useEffect } from 'react';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { toast, Toaster } from 'sonner@2.0.3';
import { Trash2, Plus, ShoppingCart, X, Minus, Printer, Package, History, Settings as SettingsIcon, BarChart3, Scan, Search, Bug, Users } from 'lucide-react';
import { Sidebar } from './components/Sidebar';
import { ReceiptTape } from './components/ReceiptTape';
import { InventoryManagement } from './components/InventoryManagement';
import { PrintPreview } from './components/PrintPreview';
import { OrderHistory } from './components/OrderHistory';
import { Settings, AppSettings } from './components/Settings';
import { ReceiptSettings, ReceiptConfig, LogoConfig, FooterConfig, BusinessInfo, SequenceConfig, TaxConfig, DiscountConfig, FeesConfig, QRCodeConfig } from './components/ReceiptSettings';
import { Statistics } from './components/Statistics';
import { PrinterSettings, PrinterConfig } from './components/PrinterSettings';
import { DataSettings } from './components/DataSettings';
import { LanguageSettings } from './components/LanguageSettings';
import { CurrencySettings } from './components/CurrencySettings';
import { EmailSettings } from './components/EmailSettings';
import { MessageSettings } from './components/MessageSettings';
import { LogoSettings } from './components/LogoSettings';
import { FooterSettings } from './components/FooterSettings';
import { TimeFormatSettings } from './components/TimeFormatSettings';
import { BusinessIdentity } from './components/BusinessIdentity';
import { SequenceSettings } from './components/SequenceSettings';
import { TaxSettings } from './components/TaxSettings';
import { DiscountSettings } from './components/DiscountSettings';
import { FeesSettings } from './components/FeesSettings';
import { QRCodeSettings } from './components/QRCodeSettings';
import { PasswordSetup } from './components/PasswordSetup';
import { PasswordDialog } from './components/PasswordDialog';
import { BrandingSettings } from './components/BrandingSettings';
import { AboutGastrolabs } from './components/AboutGastrolabs';
import { SubscriptionManager } from './components/SubscriptionManager';
import { AuditLogViewer } from './components/AuditLogViewer';
import { SubdomainSettings } from './components/SubdomainSettings';
import { QuickAddShortcuts } from './components/QuickAddShortcuts';
import { PaymentDashboard } from './components/PaymentDashboard';
import { QRScanner } from './components/QRScanner';
import { OfflineSyncStatus } from './components/OfflineSyncStatus';
import { SetupGuide } from './components/SetupGuide';
import { PaymentQRSettings, PaymentQRConfig } from './components/PaymentQRSettings';
import { TableManagement, TableBill } from './components/TableManagement';
import { ImageWithFallback } from './components/figma/ImageWithFallback';
import { AuthProvider, useAuth } from './lib/auth-context';
import QRCode from 'qrcode';
import { generatePaymentQRData, generateUPIPaymentURL, isValidUPIId } from './lib/upi-payment-generator';
import defaultLogo from './assets/chai-logo.png';
import vadaLogo from 'figma:asset/542ff8b3ec0d8d5f4d50195ad5cda9aaa8a9e39e.png';
import gastrolabsLogo from 'figma:asset/40e32a5289d65a2b6179706a1a6cf20239f14e08.png';
import eruda from 'eruda';

export interface MenuItem {
  id: string;
  name: string;
  price: number;
  category: string;
  stock?: number; // Optional: undefined = unlimited, number = tracked inventory
}

export interface BillItem extends MenuItem {
  quantity: number;
}

export interface Order {
  id: string;
  items: BillItem[];
  total: number;
  timestamp: Date;
  status: 'active' | 'paid';
}

const DEFAULT_ITEMS: MenuItem[] = [
  { id: '1', name: 'Regular Tea', price: 10, category: 'Tea' },
  { id: '2', name: 'Special Tea', price: 15, category: 'Tea' },
  { id: '3', name: 'Ginger Tea', price: 12, category: 'Tea' },
  { id: '4', name: 'Lemon Tea', price: 15, category: 'Tea' },
  { id: '5', name: 'Samosa', price: 20, category: 'Snacks' },
  { id: '6', name: 'Vada', price: 15, category: 'Snacks' },
  { id: '7', name: 'Biscuit', price: 5, category: 'Snacks' },
  { id: '8', name: 'Bun', price: 10, category: 'Snacks' },
];

const DEFAULT_CATEGORIES = ['Tea', 'Snacks'];

const DEFAULT_APP_SETTINGS: AppSettings = {
  sound: true,
  vibration: true,
  currency: 'Rs',
  sortManually: false,
  mergeSimilarItems: true,
};

const DEFAULT_RECEIPT_CONFIG: ReceiptConfig = {
  header: 'Tea Shop',
  showCustomer: false,
  showTotalQty: true,
  showSubtotal: false,
  showPaymentMethods: false,
  showCash: false,
  showChange: false,
  showGrandTotal: true,
  showPaidTime: false,
  showWatermark: false,
  timeFormat: 'dd MM yyyy hh.mm',
  logo: {
    enabled: false,
    type: 'text',
    imageUrl: '',
    text: 'Tea Shop',
    size: 'medium',
  },
  footer: {
    enabled: true,
    text: 'Thank you for your visit!',
    showContactInfo: false,
    contactInfo: '',
  },
  business: {
    enabled: true,
    businessName: 'Vada and Gossip',
    address: 'Breakfast, Chat & Bun',
    phone: '',
    email: '',
    website: '',
    taxId: '',
  },
  sequence: {
    enabled: false,
    prefix: 'INV-',
    startNumber: 1,
    format: 'padded',
    padding: 3,
  },
  tax: {
    enabled: false,
    taxes: [],
    includedInPrice: false,
  },
  discount: {
    enabled: false,
    type: 'percentage',
    value: 0,
    applyToTotal: false,
  },
  fees: {
    enabled: false,
    fees: [],
  },
  qrCode: {
    enabled: false,
    type: 'upi',
    upiId: '',
    url: '',
    text: '',
    size: 'medium',
    label: 'Scan to Pay',
  },
  paymentQR: {
    enabled: false,
    imageUrl: '',
    upiId: '',
  },
};

const DEFAULT_PRINTER_CONFIG: PrinterConfig = {
  connectionType: 'wifi',
  printerName: 'Thermal Printer',
  ipAddress: '192.168.1.100',
  port: '9100',
  autoPrint: false,
  paperWidth: '58mm',
  encoding: 'UTF-8',
  // Professional thermal printer settings (matching real printer apps)
  printingMethod: 'TXT',
  adjustment: 0.95,
  fontSize: 25,
  continuousPrinting: 1,
  fontSizePreset: 'Larger',
  lineSpacing: 'Default',
  blankSpacing: 1,
};

const DEFAULT_DATA_SETTINGS = {
  backupFrequency: 'daily',
  autoSave: true,
};

const DEFAULT_LANGUAGE_SETTINGS: Language = 'en';

const DEFAULT_CURRENCY_SETTINGS = {
  currencySymbol: 'Rs',
  currencyCode: 'INR',
};

const DEFAULT_EMAIL_CONFIG: EmailConfig = {
  enabled: false,
  recipientEmail: '',
  subject: 'Receipt from Tea Shop',
  messageTemplate: 'Thank you for your purchase!\n\nPlease find your receipt details above.',
  includeReceipt: true,
  autoSend: false,
};

const DEFAULT_MESSAGE_CONFIG: MessageConfig = {
  enabled: false,
  phoneNumber: '',
  messageTemplate: 'Thank you for visiting Tea Shop!\nTotal: {total}\n{items}',
  includeTotal: true,
  includeItems: true,
  autoSend: false,
};

const DEFAULT_LOGO_CONFIG: LogoConfig = {
  enabled: false,
  type: 'text',
  imageUrl: '',
  text: 'Tea Shop',
  size: 'medium',
};

const DEFAULT_FOOTER_CONFIG: FooterConfig = {
  enabled: true,
  text: 'Thank you for your visit!',
  showContactInfo: false,
  contactInfo: '',
};

const DEFAULT_BUSINESS_INFO: BusinessInfo = {
  enabled: false,
  businessName: '',
  address: '',
  phone: '',
  email: '',
  website: '',
  taxId: '',
};

const DEFAULT_SEQUENCE_CONFIG: SequenceConfig = {
  enabled: false,
  prefix: 'INV-',
  startNumber: 1,
  format: 'padded',
  padding: 3,
};

const DEFAULT_TAX_CONFIG: TaxConfig = {
  enabled: false,
  taxes: [],
  includedInPrice: false,
};

const DEFAULT_DISCOUNT_CONFIG: DiscountConfig = {
  enabled: false,
  type: 'percentage',
  value: 0,
  applyToTotal: false,
};

const DEFAULT_FEES_CONFIG: FeesConfig = {
  enabled: false,
  fees: [],
};

const DEFAULT_QRCODE_CONFIG: QRCodeConfig = {
  enabled: false,
  type: 'upi',
  upiId: '',
  url: '',
  text: '',
  size: 'medium',
  label: 'Scan to Pay',
};

function AppContent() {
  const [billItems, setBillItems] = useState<BillItem[]>([]);
  const [menuItems, setMenuItems] = useState<MenuItem[]>(DEFAULT_ITEMS);
  const [categories, setCategories] = useState<string[]>(DEFAULT_CATEGORIES);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [orders, setOrders] = useState<Order[]>([]);
  const [appSettings, setAppSettings] = useState<AppSettings>(DEFAULT_APP_SETTINGS);
  const [receiptConfig, setReceiptConfig] = useState<ReceiptConfig>(DEFAULT_RECEIPT_CONFIG);
  const [printerConfig, setPrinterConfig] = useState<PrinterConfig>(DEFAULT_PRINTER_CONFIG);
  const [dataSettings, setDataSettings] = useState(DEFAULT_DATA_SETTINGS);
  const [languageSettings, setLanguageSettings] = useState<Language>(DEFAULT_LANGUAGE_SETTINGS);
  const [currencySettings, setCurrencySettings] = useState(DEFAULT_CURRENCY_SETTINGS);
  const [emailConfig, setEmailConfig] = useState<EmailConfig>(DEFAULT_EMAIL_CONFIG);
  const [messageConfig, setMessageConfig] = useState<MessageConfig>(DEFAULT_MESSAGE_CONFIG);
  const [logoConfig, setLogoConfig] = useState<LogoConfig>(DEFAULT_LOGO_CONFIG);
  const [footerConfig, setFooterConfig] = useState<FooterConfig>(DEFAULT_FOOTER_CONFIG);
  const [businessInfo, setBusinessInfo] = useState<BusinessInfo>(DEFAULT_BUSINESS_INFO);
  const [sequenceConfig, setSequenceConfig] = useState<SequenceConfig>(DEFAULT_SEQUENCE_CONFIG);
  const [taxConfig, setTaxConfig] = useState<TaxConfig>(DEFAULT_TAX_CONFIG);
  const [discountConfig, setDiscountConfig] = useState<DiscountConfig>(DEFAULT_DISCOUNT_CONFIG);
  const [feesConfig, setFeesConfig] = useState<FeesConfig>(DEFAULT_FEES_CONFIG);
  const [qrCodeConfig, setQRCodeConfig] = useState<QRCodeConfig>(DEFAULT_QRCODE_CONFIG);
  const [currentView, setCurrentView] = useState<'pos' | 'inventory' | 'history' | 'settings' | 'receipt-settings' | 'statistics' | 'printer-settings' | 'data-settings' | 'language-settings' | 'currency-settings' | 'email-settings' | 'message-settings' | 'logo-settings' | 'footer-settings' | 'time-format-settings' | 'business-identity' | 'sequence-settings' | 'tax-settings' | 'discount-settings' | 'fees-settings' | 'qrcode-settings' | 'payment-qr-settings' | 'password-settings' | 'branding-settings' | 'about-gastrolabs' | 'subscription-settings' | 'audit-logs' | 'subdomain-settings' | 'setup-guide'>('pos');
  const [printPreviewOpen, setPrintPreviewOpen] = useState(false);
  const [currentOrderId, setCurrentOrderId] = useState<string>('');
  
  // Password protection state
  const [passwordDialogOpen, setPasswordDialogOpen] = useState(false);
  const [pendingView, setPendingView] = useState<'settings' | 'statistics' | 'inventory' | null>(null);
  
  // Table Service Mode state
  const [tableServiceMode, setTableServiceMode] = useState(false);
  const [tables, setTables] = useState<TableBill[]>([]);
  
  // Use auth context
  const { isAuthenticated, isPasswordConfigured, checkAuth, authSession } = useAuth();

  // REMOVED: Global password protection - only protecting Settings, Inventory, Statistics
  // Password dialog only shows when accessing protected sections via handleProtectedNavigation

  // Load saved branding settings from localStorage on app start
  useEffect(() => {
    try {
      const savedConfig = localStorage.getItem('gastrolabs_receipt_config');
      if (savedConfig) {
        const parsedConfig = JSON.parse(savedConfig);
        // Deep merge - preserve default values if not present in saved config
        const mergedConfig = {
          ...DEFAULT_RECEIPT_CONFIG,
          ...parsedConfig,
          logo: {
            ...DEFAULT_RECEIPT_CONFIG.logo,
            ...(parsedConfig.logo || {}),
          },
          footer: {
            ...DEFAULT_RECEIPT_CONFIG.footer,
            ...(parsedConfig.footer || {}),
          },
          business: {
            ...DEFAULT_RECEIPT_CONFIG.business,
            ...(parsedConfig.business || {}),
          },
          sequence: {
            ...DEFAULT_RECEIPT_CONFIG.sequence,
            ...(parsedConfig.sequence || {}),
          },
          tax: {
            ...DEFAULT_RECEIPT_CONFIG.tax,
            ...(parsedConfig.tax || {}),
          },
          discount: {
            ...DEFAULT_RECEIPT_CONFIG.discount,
            ...(parsedConfig.discount || {}),
          },
          fees: {
            ...DEFAULT_RECEIPT_CONFIG.fees,
            ...(parsedConfig.fees || {}),
          },
          qrCode: {
            ...DEFAULT_RECEIPT_CONFIG.qrCode,
            ...(parsedConfig.qrCode || {}),
          },
          paymentQR: {
            ...DEFAULT_RECEIPT_CONFIG.paymentQR,
            ...(parsedConfig.paymentQR || {}),
          },
        };
        setReceiptConfig(mergedConfig);
        console.log('✅ Loaded saved branding settings from localStorage');
        console.log('📋 Business Name:', mergedConfig.business.businessName);
        console.log('📍 Address:', mergedConfig.business.address);
        console.log('🖼️ Logo URL:', mergedConfig.logo.imageUrl ? 'Set' : 'Not set');
      } else {
        console.log('📦 No saved config found, using defaults');
        console.log('📋 Default Business Name:', DEFAULT_RECEIPT_CONFIG.business.businessName);
      }
    } catch (error) {
      console.error('❌ Failed to load branding settings:', error);
    }
  }, []);

  // Save receiptConfig to localStorage whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem('gastrolabs_receipt_config', JSON.stringify(receiptConfig));
      
      // Debug logging for payment QR changes
      if (receiptConfig.paymentQR?.upiId) {
        console.log('💾 Saved receipt config with UPI ID:', receiptConfig.paymentQR.upiId);
      }
    } catch (error) {
      console.error('Failed to save receipt config:', error);
    }
  }, [receiptConfig]);

  // Load menuItems from localStorage on app start
  useEffect(() => {
    try {
      const savedItems = localStorage.getItem('gastrolabs_menu_items');
      if (savedItems) {
        setMenuItems(JSON.parse(savedItems));
        console.log('✅ Loaded menu items from localStorage');
      }
    } catch (error) {
      console.error('❌ Failed to load menu items:', error);
    }
  }, []);

  // Save menuItems to localStorage whenever they change
  useEffect(() => {
    try {
      localStorage.setItem('gastrolabs_menu_items', JSON.stringify(menuItems));
    } catch (error) {
      console.error('Failed to save menu items:', error);
    }
  }, [menuItems]);

  const addItem = (item: MenuItem) => {
    // Check stock availability if item has stock tracking enabled
    if (item.stock !== undefined) {
      if (item.stock <= 0) {
        toast.error(`${item.name} is out of stock!`);
        return;
      }
      
      // Check current quantity already in bill
      const currentBillItem = billItems.find(i => i.id === item.id);
      const currentQuantityInBill = currentBillItem ? currentBillItem.quantity : 0;
      
      if (currentQuantityInBill >= item.stock) {
        toast.error(`Only ${item.stock} ${item.name} available in stock!`);
        return;
      }
    }
    
    setBillItems((prev) => {
      const existing = prev.find((i) => i.id === item.id);
      if (existing) {
        return prev.map((i) =>
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [...prev, { ...item, quantity: 1 }];
    });
    
    // Show low stock warning
    if (item.stock !== undefined && item.stock <= 5) {
      const remainingAfterAdd = item.stock - ((billItems.find(i => i.id === item.id)?.quantity || 0) + 1);
      if (remainingAfterAdd <= 3 && remainingAfterAdd > 0) {
        toast.warning(`Low stock: Only ${remainingAfterAdd} ${item.name} remaining!`);
      }
    }
  };

  const clearBill = () => {
    setBillItems([]);
  };

  const calculateTotal = () => {
    return billItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleCheckout = () => {
    if (billItems.length > 0) {
      // Generate order ID before showing print preview (with unique suffix to prevent duplicates)
      const orderId = `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
      setCurrentOrderId(orderId);
      // Show print preview instead of directly printing
      setPrintPreviewOpen(true);
    }
  };

  const handleConfirmPrint = async () => {
    // Check if this is a table checkout
    const pendingTableNumber = (window as any).__pendingTableCheckout;
    
    // Deduct stock from inventory when order is confirmed
    setMenuItems((prev) => 
      prev.map(menuItem => {
        const billItem = billItems.find(bi => bi.id === menuItem.id);
        if (billItem && menuItem.stock !== undefined) {
          return {
            ...menuItem,
            stock: Math.max(0, menuItem.stock - billItem.quantity)
          };
        }
        return menuItem;
      })
    );
    
    // Save order with the pre-generated ID (ONE TIME ONLY)
    const newOrder: Order = {
      id: currentOrderId,
      items: [...billItems],
      total: calculateTotal(),
      timestamp: new Date(),
      status: 'active',
    };
    setOrders((prev) => [newOrder, ...prev]);
    
    // If table checkout, clear the table now
    if (pendingTableNumber) {
      console.log('🧹 Clearing table after print confirmation:', pendingTableNumber);
      setTables((prev) => prev.filter(t => t.tableNumber !== pendingTableNumber));
      (window as any).__pendingTableCheckout = null; // Clear the pending table
      toast.success(`Table ${pendingTableNumber} settled! Bill created as UNPAID.`);
    } else {
      // Regular POS checkout
      toast.warning('Bill created as UNPAID. Please settle payment in Order History.', {
        duration: 4000,
      });
    }
    
    // Print with thermal printer formatting (QR masked for table bills)
    if (pendingTableNumber) {
      await handleThermalPrintTableBill(currentOrderId, billItems, calculateTotal());
    } else {
      await handleThermalPrint(currentOrderId);
    }
    
    setTimeout(() => {
      clearBill();
    }, 500);
  };

  // Table Service Mode - Handle table checkout
  const handleCheckoutTable = async (tableNumber: string) => {
    console.log('💳 ===== APP.TSX CHECKOUT HANDLER =====');
    console.log('📋 Received Table Number:', tableNumber);
    console.log('📦 Current Tables State:', tables);
    
    const table = tables.find(t => t.tableNumber === tableNumber);
    console.log('🔍 Found Table Data:', table);
    
    if (!table || table.items.length === 0) {
      console.error('❌ ERROR: Table not found or has no items');
      toast.error('Table has no items to checkout');
      return;
    }

    console.log('✅ Table validation passed');
    console.log('📝 Table Items:', table.items);
    
    // Generate order ID with unique suffix to prevent duplicates
    const orderId = `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
    console.log('🆔 Generated Order ID:', orderId);
    setCurrentOrderId(orderId);
    
    // Set bill items for preview
    setBillItems(table.items);
    
    // Store table number temporarily to clear it after print confirmation
    (window as any).__pendingTableCheckout = tableNumber;
    
    // Show print preview dialog (QR will be masked in PrintPreview for table bills)
    console.log('🖨️ Opening print preview...');
    setPrintPreviewOpen(true);
    
    console.log('✅ Preview opened, waiting for user confirmation');
    console.log('=====================================');
  };

  const handleThermalPrint = async (orderId: string) => {
    const total = calculateTotal();
    
    // Generate dynamic UPI payment QR code if UPI ID is configured
    let qrCodeDataUrl = '';
    let qrLabel = 'Scan to track payment';
    
    // Enhanced debug logging
    console.log('🖨️ ========== THERMAL PRINT DEBUG ==========');
    console.log('📋 Receipt Config:', receiptConfig);
    console.log('💳 Payment QR Config:', receiptConfig.paymentQR);
    console.log('🔑 UPI ID from config:', receiptConfig.paymentQR?.upiId);
    console.log('💰 Total amount:', total);
    console.log('🆔 Order ID:', orderId);
    
    try {
      // Check if UPI payment is configured
      const upiId = receiptConfig.paymentQR?.upiId;
      const businessName = receiptConfig.business?.businessName || 'Shop';
      
      console.log('🔍 Checking UPI validation...');
      console.log('   UPI ID:', upiId);
      console.log('   UPI ID exists:', !!upiId);
      console.log('   UPI ID valid format:', upiId ? isValidUPIId(upiId) : false);
      
      if (upiId && isValidUPIId(upiId)) {
        // Generate UPI payment URL with dynamic amount
        const upiPaymentUrl = generateUPIPaymentURL({
          upiId: upiId,
          name: businessName,
          amount: total,
          orderId: orderId,
          note: `Payment for Order #${orderId.slice(-6)}`,
        });
        
        console.log('🎯 Generated UPI URL:', upiPaymentUrl);
        
        qrCodeDataUrl = await QRCode.toDataURL(upiPaymentUrl, {
          width: 200,
          margin: 1,
          errorCorrectionLevel: 'M',
        });
        
        qrLabel = `Scan to Pay ₹${total}`;
        console.log('✅ Generated UPI payment QR code for ₹' + total);
        console.log('✅ QR Data URL length:', qrCodeDataUrl.length);
      } else {
        // Fallback: Generate order tracking QR code
        const qrData = JSON.stringify({
          orderId: orderId,
          amount: total,
          timestamp: new Date().toISOString(),
        });
        
        console.log('⚠️ UPI not configured, generating fallback order tracking QR');
        console.log('📦 QR Data:', qrData);
        
        qrCodeDataUrl = await QRCode.toDataURL(qrData, {
          width: 200,
          margin: 1,
        });
        
        qrLabel = 'Scan to track payment';
        console.log('ℹ️ Generated order tracking QR code (UPI not configured)');
        console.log('✅ QR Data URL length:', qrCodeDataUrl.length);
      }
    } catch (error) {
      console.error('❌ QR code generation failed:', error);
    }
    
    console.log('🖼️ Final QR Code Data URL:', qrCodeDataUrl ? 'Generated (' + qrCodeDataUrl.length + ' chars)' : 'EMPTY!');
    console.log('🏷️ QR Label:', qrLabel);
    console.log('========================================');
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      const totalQty = billItems.reduce((sum, item) => sum + item.quantity, 0);
      
      // Determine logo display
      const logoHtml = receiptConfig.logo?.type === 'upload' && receiptConfig.logo.imageUrl
        ? `<div class="logo-img"><img src="${receiptConfig.logo.imageUrl}" alt="Logo" style="max-width: 60px; max-height: 60px; object-fit: contain;" /></div>`
        : receiptConfig.logo?.type === 'text' && receiptConfig.logo.text
        ? `<div class="logo-text">${receiptConfig.logo.text}</div>`
        : `<div class="logo-img"><img src="${defaultLogo}" alt="Chai Tea" style="width: 60px; height: 60px; border-radius: 50%; object-fit: cover;" /></div>`;
      
      // Determine business info display
      const businessInfoHtml = receiptConfig.business?.enabled && receiptConfig.business.businessName
        ? `
          <div class="business-info">
            <div class="business-name">${receiptConfig.business.businessName}</div>
            ${receiptConfig.business.address ? `<div class="business-detail">${receiptConfig.business.address.replace(/\n/g, '<br>')}</div>` : ''}
            ${receiptConfig.business.phone ? `<div class="business-detail">Tel: ${receiptConfig.business.phone}</div>` : ''}
            ${receiptConfig.business.email ? `<div class="business-detail">${receiptConfig.business.email}</div>` : ''}
            ${receiptConfig.business.taxId ? `<div class="business-detail">${receiptConfig.business.taxId}</div>` : ''}
          </div>
        `
        : receiptConfig.header
        ? `<div class="header">${receiptConfig.header}</div>`
        : '';
      
      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Receipt</title>
          <style>
            @page {
              size: 58mm auto;
              margin: 0;
            }
            body {
              font-family: 'Courier New', monospace;
              width: 58mm;
              margin: 0;
              padding: 8px;
              font-size: 11px;
              line-height: 1.4;
            }
            .center {
              text-align: center;
            }
            .logo-img {
              text-align: center;
              margin: 0 auto 8px;
            }
            .logo-text {
              font-size: 24px;
              font-weight: bold;
              text-align: center;
              margin-bottom: 8px;
            }
            .business-info {
              text-align: center;
              margin-bottom: 8px;
            }
            .business-name {
              font-size: 16px;
              font-weight: bold;
              text-transform: uppercase;
              margin-bottom: 4px;
            }
            .business-detail {
              font-size: 9px;
              margin: 2px 0;
            }
            .header {
              font-size: 18px;
              font-weight: bold;
              text-align: center;
              margin-bottom: 4px;
              text-transform: uppercase;
            }
            .datetime {
              font-size: 10px;
              text-align: center;
              margin-bottom: 8px;
              padding-bottom: 4px;
              border-bottom: 1px dashed #000;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin-bottom: 4px;
            }
            th {
              font-size: 10px;
              padding: 2px 0;
              border-bottom: 1px dashed #000;
              text-align: left;
            }
            th.qty, td.qty {
              text-align: center;
              width: 15%;
            }
            th.price, td.price {
              text-align: right;
              width: 25%;
            }
            th.total, td.total {
              text-align: right;
              width: 18%;
            }
            td {
              padding: 3px 0;
              font-size: 10px;
            }
            .divider {
              border-top: 1px dashed #000;
              margin: 4px 0;
            }
            .summary {
              display: flex;
              justify-content: space-between;
              font-size: 10px;
              margin: 3px 0;
            }
            .grand-total {
              display: flex;
              justify-content: space-between;
              font-weight: bold;
              font-size: 13px;
              margin: 6px 0;
            }
            .footer {
              text-align: center;
              margin-top: 8px;
              padding-top: 4px;
              border-top: 1px dashed #000;
              font-size: 10px;
            }
            .qr-code {
              text-align: center;
              margin-top: 8px;
              padding-top: 8px;
              border-top: 1px dashed #000;
            }
            .qr-code img {
              width: 120px;
              height: 120px;
              margin: 4px auto;
            }
            .qr-label {
              font-size: 9px;
              margin-top: 4px;
            }
            @media print {
              body {
                margin: 0;
                padding: 8px;
              }
            }
          </style>
        </head>
        <body>
          ${logoHtml}
          ${businessInfoHtml}
          <div class="datetime">
            Date/Time: ${new Date().toLocaleDateString('en-GB')} ${new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}
          </div>
          
          <table>
            <thead>
              <tr>
                <th>Item</th>
                <th class="qty">QTY</th>
                <th class="price">Price</th>
                <th class="total">Total</th>
              </tr>
            </thead>
            <tbody>
              ${billItems.map(item => `
                <tr>
                  <td>${item.name}</td>
                  <td class="qty">${item.quantity}</td>
                  <td class="price">${item.price}</td>
                  <td class="total">${item.price * item.quantity}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          
          <div class="divider"></div>
          
          ${receiptConfig.showTotalQty ? `
            <div class="summary">
              <span>TOTAL QTY:</span>
              <span>${totalQty}</span>
            </div>
          ` : ''}
          
          ${receiptConfig.showSubtotal ? `
            <div class="summary">
              <span>Subtotal:</span>
              <span>Rs ${calculateTotal()}</span>
            </div>
          ` : ''}
          
          ${receiptConfig.showGrandTotal ? `
            <div class="grand-total">
              <span>Grand Total:</span>
              <span>Rs ${calculateTotal()}</span>
            </div>
          ` : ''}
          
          <div class="footer">
            Thank you for your visit!
            ${receiptConfig.showPaidTime ? `<br><span style="font-size: 9px;">Paid: ${new Date().toLocaleTimeString('en-IN')}</span>` : ''}
          </div>
          
          ${qrCodeDataUrl ? `
            <div class="qr-code">
              <div class="qr-label">${qrLabel}</div>
              <img src="${qrCodeDataUrl}" alt="Order QR Code" />
              <div class="qr-label">Order ID: #${orderId.slice(-6)}</div>
            </div>
          ` : ''}
        </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
      printWindow.close();
    }
  };

  const handleThermalPrintTableBill = async (orderId: string, items: BillItem[], total: number) => {
    const totalQty = items.reduce((sum, item) => sum + item.quantity, 0);
    
    // NO QR CODE FOR TABLE BILLS - masked like old billing system
    console.log('🖨️ ========== TABLE BILL PRINT (NO QR) ==========');
    console.log('🆔 Order ID:', orderId);
    console.log('💰 Total amount:', total);
    console.log('📋 Items:', items.length);
    console.log('🚫 QR Code: MASKED (like old billing system)');
    console.log('========================================');
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      
      // Determine logo display
      const logoHtml = receiptConfig.logo?.type === 'upload' && receiptConfig.logo.imageUrl
        ? `<div class="logo-img"><img src="${receiptConfig.logo.imageUrl}" alt="Logo" style="max-width: 60px; max-height: 60px; object-fit: contain;" /></div>`
        : receiptConfig.logo?.type === 'text' && receiptConfig.logo.text
        ? `<div class="logo-text">${receiptConfig.logo.text}</div>`
        : `<div class="logo-img"><img src="${defaultLogo}" alt="Chai Tea" style="width: 60px; height: 60px; border-radius: 50%; object-fit: cover;" /></div>`;
      
      // Determine business info display
      const businessInfoHtml = receiptConfig.business?.enabled && receiptConfig.business.businessName
        ? `
          <div class="business-info">
            <div class="business-name">${receiptConfig.business.businessName}</div>
            ${receiptConfig.business.address ? `<div class="business-detail">${receiptConfig.business.address.replace(/\n/g, '<br>')}</div>` : ''}
            ${receiptConfig.business.phone ? `<div class="business-detail">Tel: ${receiptConfig.business.phone}</div>` : ''}
            ${receiptConfig.business.email ? `<div class="business-detail">${receiptConfig.business.email}</div>` : ''}
            ${receiptConfig.business.taxId ? `<div class="business-detail">${receiptConfig.business.taxId}</div>` : ''}
          </div>
        `
        : receiptConfig.header
        ? `<div class="header">${receiptConfig.header}</div>`
        : '';
      
      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Receipt</title>
          <style>
            @page {
              size: 58mm auto;
              margin: 0;
            }
            body {
              font-family: 'Courier New', monospace;
              width: 58mm;
              margin: 0;
              padding: 8px;
              font-size: 11px;
              line-height: 1.4;
            }
            .center {
              text-align: center;
            }
            .logo-img {
              text-align: center;
              margin: 0 auto 8px;
            }
            .logo-text {
              font-size: 24px;
              font-weight: bold;
              text-align: center;
              margin-bottom: 8px;
            }
            .business-info {
              text-align: center;
              margin-bottom: 8px;
            }
            .business-name {
              font-size: 16px;
              font-weight: bold;
              text-transform: uppercase;
              margin-bottom: 4px;
            }
            .business-detail {
              font-size: 9px;
              margin: 2px 0;
            }
            .header {
              font-size: 18px;
              font-weight: bold;
              text-align: center;
              margin-bottom: 4px;
              text-transform: uppercase;
            }
            .datetime {
              font-size: 10px;
              text-align: center;
              margin-bottom: 8px;
              padding-bottom: 4px;
              border-bottom: 1px dashed #000;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin-bottom: 4px;
            }
            th {
              font-size: 10px;
              padding: 2px 0;
              border-bottom: 1px dashed #000;
              text-align: left;
            }
            th.qty, td.qty {
              text-align: center;
              width: 15%;
            }
            th.price, td.price {
              text-align: right;
              width: 25%;
            }
            th.total, td.total {
              text-align: right;
              width: 18%;
            }
            td {
              padding: 3px 0;
              font-size: 10px;
            }
            .divider {
              border-top: 1px dashed #000;
              margin: 4px 0;
            }
            .summary {
              display: flex;
              justify-content: space-between;
              font-size: 10px;
              margin: 3px 0;
            }
            .grand-total {
              display: flex;
              justify-content: space-between;
              font-weight: bold;
              font-size: 13px;
              margin: 6px 0;
            }
            .footer {
              text-align: center;
              margin-top: 8px;
              padding-top: 4px;
              border-top: 1px dashed #000;
              font-size: 10px;
            }
            .qr-code {
              text-align: center;
              margin-top: 8px;
              padding-top: 8px;
              border-top: 1px dashed #000;
            }
            .qr-code img {
              width: 120px;
              height: 120px;
              margin: 4px auto;
            }
            .qr-label {
              font-size: 9px;
              margin-top: 4px;
            }
            @media print {
              body {
                margin: 0;
                padding: 8px;
              }
            }
          </style>
        </head>
        <body>
          ${logoHtml}
          ${businessInfoHtml}
          <div class="datetime">
            Date/Time: ${new Date().toLocaleDateString('en-GB')} ${new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}
          </div>
          
          <table>
            <thead>
              <tr>
                <th>Item</th>
                <th class="qty">QTY</th>
                <th class="price">Price</th>
                <th class="total">Total</th>
              </tr>
            </thead>
            <tbody>
              ${items.map(item => `
                <tr>
                  <td>${item.name}</td>
                  <td class="qty">${item.quantity}</td>
                  <td class="price">${item.price}</td>
                  <td class="total">${item.price * item.quantity}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          
          <div class="divider"></div>
          
          ${receiptConfig.showTotalQty ? `
            <div class="summary">
              <span>TOTAL QTY:</span>
              <span>${totalQty}</span>
            </div>
          ` : ''}
          
          ${receiptConfig.showSubtotal ? `
            <div class="summary">
              <span>Subtotal:</span>
              <span>Rs ${total}</span>
            </div>
          ` : ''}
          
          ${receiptConfig.showGrandTotal ? `
            <div class="grand-total">
              <span>Grand Total:</span>
              <span>Rs ${total}</span>
            </div>
          ` : ''}
          
          <div class="footer">
            Thank you for your visit!
            ${receiptConfig.showPaidTime ? `<br><span style="font-size: 9px;">Paid: ${new Date().toLocaleTimeString('en-IN')}</span>` : ''}
          </div>
        </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
      printWindow.close();
    }
  };

  const handleMarkAsPaid = (orderId: string) => {
    setOrders((prev) =>
      prev.map((order) =>
        order.id === orderId ? { ...order, status: 'paid' } : order
      )
    );
  };

  const handleDeleteOrder = (orderId: string) => {
    setOrders((prev) => prev.filter((order) => order.id !== orderId));
  };
  
  // Password-protected navigation handlers
  const handleProtectedNavigation = (view: 'settings' | 'statistics' | 'inventory') => {
    console.log('🔐 handleProtectedNavigation called for:', view);
    
    // Check if password is configured
    if (!isPasswordConfigured) {
      console.log('✅ No password configured, allowing direct access');
      toast.info('💡 Tip: Set a password in Settings > Password Protection to secure these sections', {
        duration: 3000,
      });
      setCurrentView(view);
      return;
    }
    
    // CRITICAL FIX: Always verify session is still valid, don't trust the state
    const sessionValid = authSession.isAuthenticated();
    
    // Check if session is still valid
    if (sessionValid) {
      console.log('✅ Session valid, allowing access');
      // Extend session on successful access
      authSession.extendSession();
      setCurrentView(view);
      return;
    }
    
    // Session expired or not authenticated - show password dialog
    console.log('🚨 Session expired or not authenticated! Opening dialog...');
    toast.warning('⏰ Session expired. Please enter your password.', {
      duration: 3000,
    });
    setPendingView(view);
    setPasswordDialogOpen(true);
  };
  
  const handlePasswordSuccess = () => {
    console.log('✅ Password verified successfully');
    console.log('📍 Pending view to navigate to:', pendingView);
    if (pendingView) {
      console.log('📍 Navigating to:', pendingView);
      const targetView = pendingView;
      setPendingView(null);
      setPasswordDialogOpen(false);
      
      // Ensure dialog closes and view changes
      setTimeout(() => {
        setCurrentView(targetView);
        toast.success('✅ Access granted!');
      }, 100);
    } else {
      // Global password protection - just close dialog and allow access to app
      setPasswordDialogOpen(false);
      toast.success('✅ Access granted!');
    }
  };

  if (currentView === 'inventory') {
    return (
      <InventoryManagement
        items={menuItems}
        categories={categories}
        onBack={() => setCurrentView('pos')}
        onUpdateItems={setMenuItems}
        onUpdateCategories={setCategories}
      />
    );
  }

  if (currentView === 'history') {
    return (
      <OrderHistory
        orders={orders}
        onBack={() => setCurrentView('pos')}
        onMarkAsPaid={handleMarkAsPaid}
        onDelete={handleDeleteOrder}
      />
    );
  }

  if (currentView === 'settings') {
    return (
      <Settings
        onBack={() => setCurrentView('pos')}
        onReceiptSettings={() => setCurrentView('receipt-settings')}
        onPrinterSettings={() => setCurrentView('printer-settings')}
        onDataSettings={() => setCurrentView('data-settings')}
        onLanguageSettings={() => setCurrentView('language-settings')}
        onCurrencySettings={() => setCurrentView('currency-settings')}
        onEmailSettings={() => setCurrentView('email-settings')}
        onMessageSettings={() => setCurrentView('message-settings')}
        onPasswordSettings={() => setCurrentView('password-settings')}
        onBrandingSettings={() => setCurrentView('branding-settings')}
        onAboutGastrolabs={() => setCurrentView('about-gastrolabs')}
        onSubscriptionSettings={() => setCurrentView('subscription-settings')}
        onAuditLogs={() => setCurrentView('audit-logs')}
        onSubdomainSettings={() => setCurrentView('subdomain-settings')}
        onSetupGuide={() => setCurrentView('setup-guide')}
        settings={appSettings}
        onUpdateSettings={setAppSettings}
      />
    );
  }

  if (currentView === 'receipt-settings') {
    return (
      <ReceiptSettings
        onBack={() => setCurrentView('settings')}
        onLogoSettings={() => setCurrentView('logo-settings')}
        onFooterSettings={() => setCurrentView('footer-settings')}
        onTimeFormatSettings={() => setCurrentView('time-format-settings')}
        onBusinessIdentity={() => setCurrentView('business-identity')}
        onSequenceSettings={() => setCurrentView('sequence-settings')}
        onTaxSettings={() => setCurrentView('tax-settings')}
        onDiscountSettings={() => setCurrentView('discount-settings')}
        onFeesSettings={() => setCurrentView('fees-settings')}
        onQRCodeSettings={() => setCurrentView('qrcode-settings')}
        onPaymentQRSettings={() => setCurrentView('payment-qr-settings')}
        settings={receiptConfig}
        onUpdateSettings={setReceiptConfig}
      />
    );
  }

  if (currentView === 'statistics') {
    return (
      <Statistics
        orders={orders}
        onBack={() => setCurrentView('pos')}
      />
    );
  }

  if (currentView === 'printer-settings') {
    return (
      <PrinterSettings
        onBack={() => setCurrentView('settings')}
        settings={printerConfig}
        onUpdateSettings={setPrinterConfig}
      />
    );
  }

  if (currentView === 'data-settings') {
    const handleExportData = () => {
      const data = {
        menuItems,
        categories,
        orders,
        appSettings,
        receiptConfig,
        printerConfig,
        emailConfig,
        messageConfig,
      };
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `teashop-data-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success('Data exported successfully!');
    };

    const handleImportData = () => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = '.json';
      input.onchange = (e) => {
        const file = (e.target as HTMLInputElement).files?.[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = (event) => {
            try {
              const data = JSON.parse(event.target?.result as string);
              if (data.menuItems) setMenuItems(data.menuItems);
              if (data.categories) setCategories(data.categories);
              if (data.orders) setOrders(data.orders);
              if (data.appSettings) setAppSettings(data.appSettings);
              if (data.receiptConfig) setReceiptConfig(data.receiptConfig);
              if (data.printerConfig) setPrinterConfig(data.printerConfig);
              if (data.emailConfig) setEmailConfig(data.emailConfig);
              if (data.messageConfig) setMessageConfig(data.messageConfig);
              toast.success('Data imported successfully!');
            } catch (error) {
              toast.error('Failed to import data. Invalid file format.');
            }
          };
          reader.readAsText(file);
        }
      };
      input.click();
    };

    const handleClearData = () => {
      setMenuItems(DEFAULT_ITEMS);
      setCategories(DEFAULT_CATEGORIES);
      setOrders([]);
      setAppSettings(DEFAULT_APP_SETTINGS);
      setReceiptConfig(DEFAULT_RECEIPT_CONFIG);
      setPrinterConfig(DEFAULT_PRINTER_CONFIG);
      setEmailConfig(DEFAULT_EMAIL_CONFIG);
      setMessageConfig(DEFAULT_MESSAGE_CONFIG);
      setBillItems([]);
      toast.success('All data cleared successfully!');
      setCurrentView('pos');
    };

    return (
      <DataSettings
        onBack={() => setCurrentView('settings')}
        onExportData={handleExportData}
        onImportData={handleImportData}
        onClearData={handleClearData}
      />
    );
  }

  if (currentView === 'language-settings') {
    return (
      <LanguageSettings
        onBack={() => setCurrentView('settings')}
        currentLanguage={languageSettings}
        onUpdateLanguage={setLanguageSettings}
      />
    );
  }

  if (currentView === 'currency-settings') {
    const handleCurrencyUpdate = (symbol: string) => {
      setAppSettings({ ...appSettings, currency: symbol });
      toast.success(`Currency changed to ${symbol}`);
    };

    return (
      <CurrencySettings
        onBack={() => setCurrentView('settings')}
        currentCurrency={appSettings.currency}
        onUpdateCurrency={handleCurrencyUpdate}
      />
    );
  }

  if (currentView === 'email-settings') {
    return (
      <EmailSettings
        onBack={() => setCurrentView('settings')}
        settings={emailConfig}
        onUpdateSettings={setEmailConfig}
      />
    );
  }

  if (currentView === 'message-settings') {
    return (
      <MessageSettings
        onBack={() => setCurrentView('settings')}
        settings={messageConfig}
        onUpdateSettings={setMessageConfig}
      />
    );
  }

  if (currentView === 'logo-settings') {
    return (
      <LogoSettings
        onBack={() => setCurrentView('receipt-settings')}
        settings={receiptConfig.logo}
        onUpdateSettings={(logo) => setReceiptConfig({ ...receiptConfig, logo })}
      />
    );
  }

  if (currentView === 'footer-settings') {
    return (
      <FooterSettings
        onBack={() => setCurrentView('receipt-settings')}
        settings={receiptConfig.footer}
        onUpdateSettings={(footer) => setReceiptConfig({ ...receiptConfig, footer })}
      />
    );
  }

  if (currentView === 'time-format-settings') {
    return (
      <TimeFormatSettings
        onBack={() => setCurrentView('receipt-settings')}
        currentFormat={receiptConfig.timeFormat}
        onUpdateFormat={(timeFormat) => setReceiptConfig({ ...receiptConfig, timeFormat })}
      />
    );
  }

  if (currentView === 'business-identity') {
    return (
      <BusinessIdentity
        onBack={() => setCurrentView('receipt-settings')}
        settings={receiptConfig.business}
        onUpdateSettings={(business) => setReceiptConfig({ ...receiptConfig, business })}
      />
    );
  }

  if (currentView === 'sequence-settings') {
    return (
      <SequenceSettings
        onBack={() => setCurrentView('receipt-settings')}
        settings={receiptConfig.sequence}
        onUpdateSettings={(sequence) => setReceiptConfig({ ...receiptConfig, sequence })}
      />
    );
  }

  if (currentView === 'tax-settings') {
    return (
      <TaxSettings
        onBack={() => setCurrentView('receipt-settings')}
        settings={receiptConfig.tax}
        onUpdateSettings={(tax) => setReceiptConfig({ ...receiptConfig, tax })}
      />
    );
  }

  if (currentView === 'discount-settings') {
    return (
      <DiscountSettings
        onBack={() => setCurrentView('receipt-settings')}
        settings={receiptConfig.discount}
        onUpdateSettings={(discount) => setReceiptConfig({ ...receiptConfig, discount })}
      />
    );
  }

  if (currentView === 'fees-settings') {
    return (
      <FeesSettings
        onBack={() => setCurrentView('receipt-settings')}
        settings={receiptConfig.fees}
        onUpdateSettings={(fees) => setReceiptConfig({ ...receiptConfig, fees })}
      />
    );
  }

  if (currentView === 'qrcode-settings') {
    return (
      <QRCodeSettings
        onBack={() => setCurrentView('receipt-settings')}
        settings={receiptConfig.qrCode}
        onUpdateSettings={(qrCode) => setReceiptConfig({ ...receiptConfig, qrCode })}
      />
    );
  }

  if (currentView === 'payment-qr-settings') {
    return (
      <PaymentQRSettings
        onBack={() => setCurrentView('receipt-settings')}
        settings={receiptConfig.paymentQR}
        onUpdateSettings={(paymentQR) => setReceiptConfig({ ...receiptConfig, paymentQR })}
      />
    );
  }

  if (currentView === 'password-settings') {
    return (
      <PasswordSetup
        onBack={() => setCurrentView('settings')}
      />
    );
  }

  if (currentView === 'branding-settings') {
    return (
      <BrandingSettings
        onBack={() => setCurrentView('settings')}
        settings={receiptConfig}
        onUpdateSettings={setReceiptConfig}
      />
    );
  }

  if (currentView === 'about-gastrolabs') {
    return (
      <AboutGastrolabs
        onBack={() => setCurrentView('settings')}
      />
    );
  }

  // NEW ENHANCED FEATURES - Subscription, Audit Logs, Subdomain Settings
  if (currentView === 'subscription-settings') {
    return (
      <SubscriptionManager
        onBack={() => setCurrentView('settings')}
      />
    );
  }

  if (currentView === 'audit-logs') {
    return (
      <AuditLogViewer
        onBack={() => setCurrentView('settings')}
      />
    );
  }

  if (currentView === 'subdomain-settings') {
    return (
      <SubdomainSettings
        onBack={() => setCurrentView('settings')}
      />
    );
  }

  if (currentView === 'setup-guide') {
    return (
      <SetupGuide
        onBack={() => setCurrentView('settings')}
      />
    );
  }

  // Filter items by search query first, then by category
  let displayedItems = menuItems;

  // Apply search filter if there's a query
  if (searchQuery.trim()) {
    displayedItems = displayedItems.filter((item) =>
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.category.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }

  // Apply category filter if a category is selected
  if (selectedCategory) {
    displayedItems = displayedItems.filter((item) => item.category === selectedCategory);
  }

  // Show Table Management view when table service mode is enabled
  if (tableServiceMode) {
    return (
      <>
        <TableManagement
          tables={tables}
          menuItems={menuItems}
          onBack={() => setTableServiceMode(false)}
          onUpdateTables={setTables}
          onCheckoutTable={handleCheckoutTable}
          currency={appSettings.currency}
        />
        
        {/* Print Preview Dialog for table checkouts */}
        <PrintPreview
          open={printPreviewOpen}
          onOpenChange={setPrintPreviewOpen}
          items={billItems}
          total={calculateTotal()}
          config={receiptConfig}
          onPrint={handleConfirmPrint}
          orderId={currentOrderId}
        />
      </>
    );
  }

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col overflow-hidden print:bg-white">
      {/* Mobile Container Wrapper */}
      <div className="flex-1 flex flex-col max-w-[600px] w-full mx-auto relative overflow-hidden">
        {/* Brand Header */}
        <div className="print:hidden bg-[#ff5c39] px-4 py-3 shadow-2xl">
          <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 min-w-0 flex-1">
            <ImageWithFallback 
              src={vadaLogo} 
              alt="Logo" 
              className="h-12 w-12 object-contain flex-shrink-0" 
            />
            <div className="min-w-0 flex-1">
              <h1 className="text-white font-bold tracking-tight truncate">
                {receiptConfig.business?.businessName || 'Vada and Gossip'}
              </h1>
              <p className="text-white/90 text-xs truncate">
                {receiptConfig.business?.address || 'Breakfast, Chat & Bun'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0 ml-2">
            <div className="bg-white/20 backdrop-blur-sm px-3 py-1.5 rounded-full border border-white/30">
              <span className="text-white font-medium text-sm">{billItems.length} items</span>
            </div>
            <Button
              onClick={() => setTableServiceMode(true)}
              className="bg-white/20 hover:bg-white/30 text-white border-white/30"
              size="sm"
            >
              <Users className="h-4 w-4 mr-1.5" />
              Tables
            </Button>
          </div>
        </div>
      </div>

        {/* Receipt Tape Display */}
        <div className="print:hidden px-4 pt-4">
          <ReceiptTape items={billItems} total={calculateTotal()} />
        </div>

        {/* Main Content Area */}
        <div className="flex-1 flex overflow-hidden px-4 gap-4 relative">
        {/* Item Grid */}
        <div className="flex-1 flex flex-col overflow-hidden print:p-0">
          {/* Search Bar */}
          <div className="pt-3 pb-2 print:hidden">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/70" />
              <Input
                type="text"
                placeholder="Search items..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-12 bg-[#C1D95C] border-[#336A29]/20 text-white placeholder:text-white/70 focus:bg-[#80B155] focus:border-[#49842B] rounded-2xl"
              />
            </div>
          </div>

          {/* Category Filter */}
          <div className="pb-2 flex gap-2 overflow-x-auto print:hidden scrollbar-hide">
            <Button
              onClick={() => setSelectedCategory(null)}
              variant={selectedCategory === null ? 'default' : 'outline'}
              size="sm"
              className={
                selectedCategory === null
                  ? 'bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white h-10 rounded-full px-5 shadow-lg border-0 text-sm font-medium'
                  : 'bg-[#C1D95C] hover:bg-[#80B155] text-white border-[#336A29]/20 h-10 rounded-full px-5 text-sm font-medium'
              }
            >
              All
            </Button>
            {categories.map((category) => (
              <Button
                key={category}
                onClick={() => setSelectedCategory(category)}
                variant={selectedCategory === category ? 'default' : 'outline'}
                size="sm"
                className={
                  selectedCategory === category
                    ? 'bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white h-10 rounded-full px-5 shadow-lg border-0 text-sm font-medium'
                    : 'bg-[#C1D95C] hover:bg-[#80B155] text-white border-[#336A29]/20 h-10 rounded-full px-5 text-sm font-medium'
                }
              >
                {category}
              </Button>
            ))}
          </div>

          <div className="flex-1 py-3 overflow-auto">
            <div className="grid grid-cols-2 gap-3">
              {displayedItems.map((item) => (
                <Button
                  key={item.id}
                  onClick={() => addItem(item)}
                  disabled={item.stock !== undefined && item.stock <= 0}
                  className={`h-36 flex flex-col items-start justify-between p-4 border rounded-2xl transition-all active:scale-95 shadow-lg hover:shadow-2xl hover:shadow-[#49842B]/30 print:hidden group ${
                    item.stock !== undefined && item.stock <= 0
                      ? 'bg-gray-400 border-gray-500 cursor-not-allowed opacity-60'
                      : 'bg-[#C1D95C] hover:bg-[#80B155] border-[#336A29]/20 hover:border-[#49842B]'
                  }`}
                >
                  <div className="flex items-start justify-between w-full">
                    <span className="text-white text-left font-medium group-hover:text-white transition-colors line-clamp-2">{item.name}</span>
                    {item.stock !== undefined && (
                      <span 
                        className={`text-xs px-2 py-0.5 rounded-full ml-2 flex-shrink-0 ${
                          item.stock === 0 
                            ? 'bg-red-500 text-white' 
                            : item.stock <= 5 
                            ? 'bg-orange-500 text-white' 
                            : 'bg-green-600 text-white'
                        }`}
                      >
                        {item.stock}
                      </span>
                    )}
                  </div>
                  <div className="flex items-baseline gap-2 self-stretch justify-between">
                    <span className="text-white font-bold text-xl">₹{item.price}</span>
                    <span className="text-white/90 text-xs bg-[#80B155] px-3 py-1 rounded-full">{item.category}</span>
                  </div>
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Sidebar */}
        <div className="print:hidden py-4">
          <Sidebar
            onClear={clearBill}
            onCheckout={handleCheckout}
            onManageItems={() => handleProtectedNavigation('inventory')}
            onManageCategories={() => setCurrentView('categories')}
            onViewHistory={() => setCurrentView('history')}
            onSettings={() => handleProtectedNavigation('settings')}
            onStatistics={() => handleProtectedNavigation('statistics')}
            hasItems={billItems.length > 0}
            orders={orders}
          />
        </div>

          {/* Powered by Gastrolabs - Bottom Branding */}
          <div className="absolute bottom-2 left-1/2 -translate-x-1/2 opacity-70 hover:opacity-100 transition-opacity print:hidden pointer-events-none">
            <p className="text-white text-[10px] tracking-wide font-medium">POWERED BY GASTROLABS</p>
          </div>
        </div>
      </div>

      {/* Print Preview Dialog */}
      <PrintPreview
        open={printPreviewOpen}
        onOpenChange={setPrintPreviewOpen}
        items={billItems}
        total={calculateTotal()}
        config={receiptConfig}
        onPrint={handleConfirmPrint}
        orderId={currentOrderId}
      />

      {/* Password Dialog */}
      <PasswordDialog
        open={passwordDialogOpen}
        onOpenChange={setPasswordDialogOpen}
        onSuccess={handlePasswordSuccess}
        title="Admin Password Required"
        description="Enter your admin password to access this section"
        dismissible={true} // Always dismissible since we only protect specific sections
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
      {/* Toaster at root level to ensure it's always visible */}
      <Toaster 
        position="top-right" 
        expand={true}
        richColors
        closeButton
      />
    </AuthProvider>
  );
}