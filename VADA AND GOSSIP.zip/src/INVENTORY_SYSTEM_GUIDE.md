# Inventory System Guide

## Overview
The POS system now includes a simple inventory tracking system that allows you to manage stock levels for menu items.

## How to Enter Stock

### 1. Access Inventory Management
- Click the **Package icon** in the left sidebar (or navigate to Inventory Management)
- Enter your admin password if prompted

### 2. Add New Item with Stock
1. Click **"Add Item"** button
2. Fill in:
   - **Item Name**: e.g., "Masala Tea"
   - **Price**: e.g., 15
   - **Category**: e.g., "Tea"
   - **Initial Stock**: Enter a number (e.g., 50) or leave empty for unlimited stock
3. Click **"Add Item"**

### 3. Update Stock for Existing Items (Two Modes)

The edit dialog now has **two modes** for managing stock:

#### Mode 1: Add Stock (Default - For Restocking)
1. Click the **Edit icon** (pencil) on any item
2. Ensure **"Add Stock"** button is selected (highlighted green)
3. See current stock displayed at the top
4. Enter quantity to add (e.g., 50 to add 50 more items)
5. See preview of new stock total
6. Click **"Update Item"**

**Example**: Current stock is 10. Enter 20 in "Add Stock". New total = 30

#### Mode 2: Set Stock (For Manual Corrections)
1. Click the **Edit icon** (pencil) on any item
2. Click the **"Set Stock"** button
3. Enter the exact stock quantity you want (e.g., 100)
4. Or leave empty for unlimited stock
5. Click **"Update Item"**

**Example**: Current stock is 75. Set to 100. New total = 100

## How Stock Works

### Stock Tracking
- **Undefined/Empty**: Item has unlimited stock (no tracking)
- **Number (e.g., 50)**: Item has tracked inventory

### Stock Indicators
Menu item buttons show color-coded stock badges:
- 🟢 **Green**: Healthy stock (> 5 items)
- 🟠 **Orange**: Low stock (1-5 items)
- 🔴 **Red**: Out of stock (0 items)

### Stock Deduction
1. **Adding to Bill**: System checks if enough stock is available
2. **Stock Validation**: 
   - If out of stock → Shows error message, cannot add
   - If limited stock → Can only add available quantity
   - Low stock warning appears when < 3 items remain
3. **Order Confirmation**: Stock is deducted when order is printed/confirmed
4. **Automatic Persistence**: Stock levels are saved automatically

### Visual Indicators
- **POS Screen**: Stock count shown in top-right corner of menu item buttons
- **Inventory Management**: Color-coded badges next to each item
- **Out of Stock Items**: Grayed out and disabled, cannot be added to bill

## Examples

### Example 1: Adding Tracked Inventory
```
Item: Samosa
Price: 20
Category: Snacks
Initial Stock: 100
```
→ Stock count of 100 shown on button

### Example 2: Unlimited Stock
```
Item: Regular Tea
Price: 10
Category: Tea
Initial Stock: (leave empty)
```
→ No stock badge shown, always available

### Example 3: Restocking (Dynamic Stock Addition)
1. Go to Inventory Management
2. Click Edit on "Samosa" (currently at 15)
3. Make sure **"Add Stock"** mode is selected
4. Enter **50** in the "Quantity to Add" field
5. See preview: "New stock will be: 65"
6. Click Update Item
→ Stock is now 65!

### Example 4: Setting Absolute Stock
1. Go to Inventory Management  
2. Click Edit on "Samosa" (currently at 15)
3. Click **"Set Stock"** button
4. Enter **100** to set exact stock level
5. Click Update Item
→ Stock is now exactly 100!

## Password Protection
- Only users with the admin password can:
  - Add new items
  - Edit existing items (including stock levels)
  - Delete items
- This prevents unauthorized stock manipulation

## Best Practices
1. **Set initial stock** when adding perishable or limited items
2. **Leave stock empty** for items that don't need tracking
3. **Restock regularly** by editing items and updating stock counts
4. **Monitor low stock warnings** during busy hours
5. **Check inventory** at end of day to plan restocking

## Technical Notes
- Stock is deducted **only when order is confirmed/printed**
- Stock validation happens **both in POS mode and Table Service mode**
- Stock data is **persisted in localStorage**
- System prevents adding more items to bill than available stock
