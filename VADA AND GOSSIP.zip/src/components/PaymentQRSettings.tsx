import { useState } from 'react';
import { Button } from './ui/button';
import { ChevronLeft, Upload, X } from 'lucide-react';
import { Label } from './ui/label';
import { Input } from './ui/input';

export interface PaymentQRConfig {
  enabled: boolean;
  imageUrl: string;
  upiId?: string;
}

interface PaymentQRSettingsProps {
  onBack: () => void;
  settings: PaymentQRConfig;
  onUpdateSettings: (settings: PaymentQRConfig) => void;
}

export function PaymentQRSettings({ onBack, settings, onUpdateSettings }: PaymentQRSettingsProps) {
  // Initialize with default values if settings is undefined
  const defaultConfig: PaymentQRConfig = {
    enabled: false,
    imageUrl: '',
    upiId: '',
  };
  
  const [config, setConfig] = useState<PaymentQRConfig>(settings || defaultConfig);

  const updateConfig = (key: keyof PaymentQRConfig, value: any) => {
    const updated = { ...config, [key]: value };
    setConfig(updated);
    onUpdateSettings(updated);
    
    // Enhanced debug logging
    if (key === 'upiId') {
      console.log('💳 PaymentQRSettings - UPI ID updated!');
      console.log('   Old value:', config.upiId || '(empty)');
      console.log('   New value:', value || '(empty)');
      console.log('✅ Change will be saved to localStorage automatically');
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        updateConfig('imageUrl', reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = () => {
    updateConfig('imageUrl', '');
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-3 flex items-center gap-3 shadow-lg">
        <Button
          onClick={onBack}
          variant="ghost"
          size="icon"
          className="text-[#49842B] hover:bg-[#49842B]/10"
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-[#336A29] font-semibold">Payment QR Code</h1>
      </div>

      <div className="flex-1 overflow-auto">
        {/* Instructions */}
        <div className="mt-4 mx-4 bg-white/60 backdrop-blur-sm rounded-2xl p-4 border border-[#336A29]/10">
          <p className="text-sm text-[#336A29] font-medium mb-2">
            💳 Dynamic UPI Payment QR Codes
          </p>
          <p className="text-sm text-[#336A29]">
            Enter your UPI ID below to automatically generate <strong>dynamic payment QR codes</strong> on receipts. Each QR code will include the exact order amount and order ID, allowing customers to scan and pay instantly.
          </p>
        </div>

        {/* UPI ID Input (Required for Dynamic QR) */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
          <Label htmlFor="upi-id" className="text-[#336A29] font-medium mb-2">
            🔑 UPI ID (For Dynamic Payment QR Codes)
          </Label>
          <Input
            id="upi-id"
            name="upi-id"
            value={config.upiId || ''}
            onChange={(e) => updateConfig('upiId', e.target.value)}
            placeholder="yourname@paytm or yourname@ybl"
            className="bg-[#80B155] border-[#336A29]/20 text-[#336A29] placeholder:text-[#336A29]/60 focus:border-[#49842B] rounded-xl mt-2"
          />
          <p className="text-xs text-[#336A29]/80 mt-2 bg-white/40 p-2 rounded-lg">
            ✅ <strong>With UPI ID:</strong> QR codes will contain payment link with exact amount<br/>
            ❌ <strong>Without UPI ID:</strong> QR codes will only contain order tracking info
          </p>
        </div>

        {/* Upload QR Code Image */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
          <Label className="text-[#336A29] font-medium mb-3 block">
            Payment QR Code Image
          </Label>

          {!config.imageUrl ? (
            <div className="border-2 border-dashed border-[#336A29]/30 rounded-xl p-8 text-center bg-white/40">
              <Upload className="h-12 w-12 text-[#336A29]/50 mx-auto mb-3" />
              <p className="text-sm text-[#336A29] mb-3">
                Upload your payment QR code
              </p>
              <label className="inline-block">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
                <span className="inline-flex items-center gap-2 px-4 py-2 bg-[#80B155] text-white rounded-lg cursor-pointer hover:bg-[#336A29] transition-colors">
                  <Upload className="h-4 w-4" />
                  Choose Image
                </span>
              </label>
              <p className="text-xs text-[#336A29]/60 mt-3">
                PNG, JPG, or JPEG (max 5MB)
              </p>
            </div>
          ) : (
            <div className="relative">
              <div className="bg-white rounded-xl p-4 border border-[#336A29]/20">
                <img
                  src={config.imageUrl}
                  alt="Payment QR Code"
                  className="max-w-full h-auto max-h-64 mx-auto"
                />
              </div>
              <Button
                onClick={handleRemoveImage}
                variant="destructive"
                size="sm"
                className="absolute top-2 right-2"
              >
                <X className="h-4 w-4 mr-1" />
                Remove
              </Button>
            </div>
          )}
        </div>

        {/* Preview */}
        {config.upiId && (
          <div className="mt-4 mx-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-4 border-2 border-green-200">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-green-800 mb-1">
                  ✅ Dynamic Payment QR Enabled!
                </p>
                <p className="text-xs text-green-700">
                  All receipts will now include QR codes with payment links containing the exact order amount. Customers can scan and pay instantly with any UPI app.
                </p>
                <div className="mt-2 bg-white/60 rounded-lg p-2">
                  <p className="text-xs text-green-900">
                    <strong>UPI ID:</strong> {config.upiId}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {config.imageUrl && (
          <div className="mt-4 mx-4 bg-white/60 backdrop-blur-sm rounded-2xl p-4 border border-[#336A29]/10">
            <div className="flex items-center gap-2 text-sm text-[#336A29]/70">
              <div className="h-2 w-2 rounded-full bg-[#336A29]/50"></div>
              Static payment QR code image uploaded (will be ignored if UPI ID is set)
            </div>
          </div>
        )}

        <div className="h-8"></div>
      </div>
    </div>
  );
}