import { Button } from './ui/button';
import { ChevronLeft, Upload, Palette, Store } from 'lucide-react';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import React, { useState } from 'react';
import { toast } from 'sonner@2.0.3';
import gastrolabsLogo from 'figma:asset/40e32a5289d65a2b6179706a1a6cf20239f14e08.png';
import { ReceiptConfig } from './ReceiptSettings';

interface BrandingSettingsProps {
  onBack: () => void;
  settings: ReceiptConfig;
  onUpdateSettings: (settings: ReceiptConfig) => void;
}

export function BrandingSettings({ onBack, settings, onUpdateSettings }: BrandingSettingsProps) {
  const [config, setConfig] = useState<ReceiptConfig>(settings);
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    console.log('🔵 Save button clicked - handleSave started');
    console.log('Current config:', config);
    
    setIsSaving(true);
    
    try {
      console.log('🔵 Step 1: Updating parent state');
      onUpdateSettings(config);
      console.log('✅ Parent state updated');
      
      // Persist to localStorage for trial usage
      const configToSave = {
        ...config,
        // Ensure logo data is included
        logo: config.logo || { enabled: false, type: 'upload', imageUrl: '', text: '', size: 'medium' },
        // Ensure business data is included
        business: config.business || { enabled: false, businessName: '', address: '', phone: '', email: '', website: '', taxId: '', businessType: '' }
      };
      
      console.log('🔵 Step 2: Saving to localStorage');
      console.log('Data to save:', configToSave);
      
      localStorage.setItem('gastrolabs_receipt_config', JSON.stringify(configToSave));
      console.log('✅ localStorage.setItem() completed');
      
      // Verify it was saved
      const verification = localStorage.getItem('gastrolabs_receipt_config');
      if (verification) {
        console.log('✅ Verification successful - data persisted');
        const parsed = JSON.parse(verification);
        console.log('Verified data:', parsed);
        
        toast.success('Branding settings saved successfully!', {
          duration: 3000,
          position: 'top-right',
        });
        console.log('✅ Toast notification triggered');
      } else {
        throw new Error('localStorage verification failed - data not found');
      }
    } catch (error) {
      console.error('❌ Save error:', error);
      alert('❌ Error: ' + error);
      toast.error('Failed to save settings. Please try again.', {
        position: 'top-right',
      });
    } finally {
      console.log('🔵 Step 3: Resetting isSaving state');
      setIsSaving(false);
      console.log('✅ handleSave completed');
    }
  };

  const handleLogoUpload = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        // Check file size (max 2MB)
        if (file.size > 2 * 1024 * 1024) {
          toast.error('Image size should be less than 2MB');
          return;
        }

        // Check file type
        if (!file.type.startsWith('image/')) {
          toast.error('Please upload a valid image file');
          return;
        }

        const reader = new FileReader();
        reader.onload = (event) => {
          const imageUrl = event.target?.result as string;
          setConfig({ 
            ...config, 
            logo: {
              ...config.logo,
              imageUrl,
              type: 'upload',
              enabled: true
            }
          });
          toast.success('✅ Logo uploaded! Click "Save Branding Settings" to apply.', {
            duration: 3000,
          });
          console.log('✅ Logo uploaded to preview. Click Save to persist.');
        };
        reader.onerror = () => {
          toast.error('Failed to read image file');
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  };
  
  const handleBusinessNameChange = (value: string) => {
    setConfig({ 
      ...config, 
      business: { 
        ...config.business, 
        businessName: value,
        enabled: true
      } 
    });
    if (value) {
      toast.success('✅ Business name updated! Click "Save" to apply.');
    }
  };
  
  const handleAddressChange = (value: string) => {
    setConfig({ 
      ...config, 
      business: { 
        ...config.business, 
        address: value,
        enabled: true
      } 
    });
    if (value) {
      toast.success('✅ Tagline updated! Click "Save" to apply.');
    }
  };

  const businessTypes = [
    'Restaurant',
    'Cafe',
    'Tea Shop',
    'Coffee Shop',
    'Food Truck',
    'Bakery',
    'Juice Bar',
    'Quick Service',
    'Fine Dining',
    'Cloud Kitchen',
    'Catering',
    'Other',
  ];

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-6 py-3 flex items-center gap-3 shadow-lg">
        <Button onClick={onBack} variant="ghost" size="icon" className="text-white hover:bg-[#49842B]/10">
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="flex-1 text-white font-semibold">White-Label Branding</h1>
        <Button
          onClick={handleSave}
          size="sm"
          className="bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white border-0"
        >
          Save Changes
        </Button>
      </div>

      <div className="flex-1 overflow-auto">
        {/* Powered by Gastrolabs Attribution */}
        <div className="mt-4 mx-6 bg-gradient-to-r from-[#C1D95C] to-[#80B155] rounded-2xl p-6 border border-[#336A29]/20">
          <div className="flex items-center gap-4">
            <img src={gastrolabsLogo} alt="Gastrolabs" className="h-12 w-auto" />
            <div>
              <p className="text-[#336A29] font-medium">White-Label POS Platform</p>
              <p className="text-sm text-[#336A29]/70">Powered by Gastrolabs - Food Service Software Solutions</p>
            </div>
          </div>
        </div>

        {/* Business Identity */}
        <div className="mt-4 mx-6 bg-[#C1D95C] rounded-2xl p-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center shadow-md">
              <Store className="h-5 w-5 text-white" />
            </div>
            <Label className="text-[#336A29] font-semibold text-lg">Business Identity</Label>
          </div>

          <div className="space-y-4">
            <div>
              <Label htmlFor="business-name" className="text-[#336A29]">Business Name *</Label>
              <Input
                id="business-name"
                value={config.business?.businessName || ''}
                onChange={(e) => handleBusinessNameChange(e.target.value)}
                placeholder="e.g. Vada & Gossip, The Coffee House, etc."
                className="bg-[#80B155] border-[#336A29]/20 text-[#336A29] placeholder:text-[#336A29]/60 focus:border-[#49842B] rounded-xl mt-2"
              />
              <p className="text-xs text-[#336A29]/60 mt-1">This will appear in the header and receipts</p>
            </div>

            <div>
              <Label htmlFor="business-address" className="text-[#336A29]">Tagline / Address</Label>
              <Input
                id="business-address"
                value={config.business?.address || ''}
                onChange={(e) => handleAddressChange(e.target.value)}
                placeholder="e.g. Quick Service POS, Fresh Brews Daily"
                className="bg-[#80B155] border-[#336A29]/20 text-[#336A29] placeholder:text-[#336A29]/60 focus:border-[#49842B] rounded-xl mt-2"
              />
            </div>
          </div>
        </div>

        {/* Business Logo */}
        <div className="mt-4 mx-6 bg-[#C1D95C] rounded-2xl p-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center shadow-md">
              <Upload className="h-5 w-5 text-white" />
            </div>
            <Label className="text-[#336A29] font-semibold text-lg">Business Logo</Label>
          </div>

          <div className="space-y-4">
            <div className="border border-[#336A29]/20 rounded-xl p-6 bg-[#80B155]/30 flex flex-col items-center">
              {config.logo?.imageUrl ? (
                <img
                  src={config.logo.imageUrl}
                  alt="Business Logo"
                  className="h-24 w-24 object-contain rounded-xl mb-4"
                />
              ) : (
                <div className="h-24 w-24 bg-[#336A29]/10 rounded-xl flex items-center justify-center mb-4">
                  <Store className="h-12 w-12 text-[#336A29]/40" />
                </div>
              )}
              <Button
                onClick={handleLogoUpload}
                className="bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white rounded-full border-0"
              >
                <Upload className="h-4 w-4 mr-2" />
                {config.logo?.imageUrl ? 'Change Logo' : 'Upload Logo'}
              </Button>
              <p className="text-xs text-[#336A29]/60 mt-2 text-center">
                Recommended: Square image, 512x512px, PNG format
              </p>
            </div>
          </div>
        </div>

        {/* Brand Colors */}
        <div className="mt-4 mx-6 bg-[#C1D95C] rounded-2xl p-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center shadow-md">
              <Palette className="h-5 w-5 text-white" />
            </div>
            <div className="flex-1">
              <Label className="text-[#336A29] font-semibold text-lg">Brand Colors</Label>
              <p className="text-xs text-[#336A29]/60">Coming soon - customize app theme</p>
            </div>
          </div>

          <div className="bg-[#49842B]/10 border border-[#49842B]/30 p-3 rounded-lg">
            <p className="text-xs text-[#336A29]">
              💡 <strong>Note:</strong> Brand colors will be available in a future update. Currently using default Gastrolabs color scheme.
            </p>
          </div>
        </div>

        {/* Preview */}
        <div className="mt-4 mb-4 mx-6 bg-[#C1D95C] rounded-2xl p-4">
          <Label className="text-[#336A29] mb-3 block font-semibold">Header Preview</Label>
          <div className="border border-[#336A29]/20 rounded-xl p-4 bg-gradient-to-r from-[#EAEF9D] via-[#80B155] to-[#336A29]">
            <div className="flex items-center gap-3">
              {config.logo?.imageUrl ? (
                <img
                  src={config.logo.imageUrl}
                  alt="Preview Logo"
                  className="h-10 w-10 object-contain rounded-full ring-2 ring-white/30"
                />
              ) : (
                <div className="h-10 w-10 bg-white/20 rounded-full flex items-center justify-center">
                  <Store className="h-5 w-5 text-white" />
                </div>
              )}
              <div>
                <h1 className="text-white font-bold tracking-tight">
                  {config.business?.businessName || 'Your Business Name'}
                </h1>
                <p className="text-white/90 text-xs">
                  {config.business?.address || 'Your tagline here'}
                </p>
              </div>
            </div>
          </div>
          <p className="text-xs text-[#336A29]/60 mt-2 text-center">
            This is how your brand will appear in the POS header
          </p>
        </div>

        {/* Save Button */}
        <div className="mt-4 mb-6 mx-6">
          <Button
            onClick={handleSave}
            disabled={isSaving}
            className="w-full bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white rounded-full border-0 py-6 text-lg shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSaving ? 'Saving...' : 'Save Branding Settings'}
          </Button>
        </div>
      </div>
    </div>
  );
}