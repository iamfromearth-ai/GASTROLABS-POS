import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { ChevronLeft, MessageCircle, Send } from 'lucide-react';
import { Switch } from './ui/switch';

export interface MessageConfig {
  enabled: boolean;
  phoneNumber: string;
  messageTemplate: string;
  includeTotal: boolean;
  includeItems: boolean;
  autoSend: boolean;
}

interface MessageSettingsProps {
  onBack: () => void;
  settings: MessageConfig;
  onUpdateSettings: (settings: MessageConfig) => void;
}

export function MessageSettings({ onBack, settings, onUpdateSettings }: MessageSettingsProps) {
  const [config, setConfig] = useState<MessageConfig>(settings);

  const updateConfig = (key: keyof MessageConfig, value: any) => {
    const updated = { ...config, [key]: value };
    setConfig(updated);
    onUpdateSettings(updated);
  };

  const sendTestMessage = () => {
    const message = encodeURIComponent(
      config.messageTemplate || 'Thank you for your purchase at Tea Shop!\n\nYour receipt has been generated.'
    );
    
    // Try to open SMS/iMessage based on platform
    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    const phoneNumber = config.phoneNumber.replace(/\D/g, ''); // Remove non-digits
    
    if (isMobile) {
      // Mobile devices
      window.location.href = `sms:${phoneNumber}?body=${message}`;
    } else {
      // Desktop - try iMessage or fallback to WhatsApp Web
      const isMac = /Mac/i.test(navigator.userAgent);
      if (isMac) {
        window.location.href = `sms:${phoneNumber}&body=${message}`;
      } else {
        // Fallback to WhatsApp Web for non-Mac desktops
        window.open(`https://wa.me/${phoneNumber}?text=${message}`, '_blank');
      }
    }
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-3 flex items-center gap-3 shadow-lg">
        <Button
          onClick={onBack}
          variant="ghost"
          size="icon"
          className="text-[#49842B] hover:bg-[#49842B]/10"
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-[#336A29] font-semibold">Message Settings</h1>
      </div>

      <div className="flex-1 overflow-auto">
        {/* Enable Messaging */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-full flex items-center justify-center shadow-md">
                <MessageCircle className="h-5 w-5 text-white" />
              </div>
              <div>
                <div className="text-[#336A29] font-medium">Enable SMS/Message Receipts</div>
                <div className="text-sm text-[#336A29]/70">Send receipts via text message</div>
              </div>
            </div>
            <Switch
              checked={config.enabled}
              onCheckedChange={(checked) => updateConfig('enabled', checked)}
            />
          </div>
        </div>

        {/* Message Configuration */}
        {config.enabled && (
          <>
            <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4 space-y-4">
              <div>
                <Label htmlFor="phone-number" className="text-[#336A29]">
                  Default Phone Number
                </Label>
                <Input
                  id="phone-number"
                  type="tel"
                  value={config.phoneNumber}
                  onChange={(e) => updateConfig('phoneNumber', e.target.value)}
                  placeholder="+91 9876543210"
                  className="mt-1 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                />
                <p className="text-xs text-[#336A29]/70 mt-1">
                  Include country code for international numbers
                </p>
              </div>

              <div>
                <Label htmlFor="message-template" className="text-[#336A29]">
                  Message Template
                </Label>
                <Textarea
                  id="message-template"
                  value={config.messageTemplate}
                  onChange={(e) => updateConfig('messageTemplate', e.target.value)}
                  placeholder="Thank you for visiting Tea Shop!&#10;Your total: {total}&#10;{items}"
                  className="mt-1 min-h-[100px] bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                />
                <p className="text-xs text-[#336A29]/70 mt-1">
                  Use {'{total}'} for order total and {'{items}'} for item list
                </p>
              </div>
            </div>

            {/* Options */}
            <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[#336A29] font-medium">Include Total Amount</div>
                  <div className="text-sm text-[#336A29]/70">Show order total in message</div>
                </div>
                <Switch
                  checked={config.includeTotal}
                  onCheckedChange={(checked) => updateConfig('includeTotal', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[#336A29] font-medium">Include Item List</div>
                  <div className="text-sm text-[#336A29]/70">List all purchased items</div>
                </div>
                <Switch
                  checked={config.includeItems}
                  onCheckedChange={(checked) => updateConfig('includeItems', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[#336A29] font-medium">Auto Send After Checkout</div>
                  <div className="text-sm text-[#336A29]/70">Automatically open messaging app</div>
                </div>
                <Switch
                  checked={config.autoSend}
                  onCheckedChange={(checked) => updateConfig('autoSend', checked)}
                />
              </div>
            </div>

            {/* Test Message */}
            <div className="mt-4 mb-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
              <Button
                onClick={sendTestMessage}
                disabled={!config.phoneNumber}
                className="w-full bg-[#49842B] hover:bg-[#336A29]"
              >
                <Send className="h-5 w-5 mr-2" />
                Send Test Message
              </Button>
              <p className="text-sm text-[#336A29]/70 text-center mt-2">
                Opens messaging app with a test message
              </p>
            </div>
          </>
        )}

        {/* Platform Info */}
        <div className="mt-4 mb-4 bg-[#49842B]/10 border border-[#49842B]/30 p-4 mx-4 rounded-lg space-y-2">
          <p className="text-sm text-[#336A29]">
            📱 <strong>iOS/Mac:</strong> Opens Messages app (iMessage/SMS)
          </p>
          <p className="text-sm text-[#336A29]">
            🤖 <strong>Android:</strong> Opens default messaging app
          </p>
          <p className="text-sm text-[#336A29]">
            💻 <strong>Windows/Linux:</strong> Opens WhatsApp Web
          </p>
        </div>
      </div>
    </div>
  );
}