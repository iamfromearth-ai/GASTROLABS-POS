import { useState } from 'react';
import { Button } from './ui/button';
import { ChevronLeft, Plus, Trash2 } from 'lucide-react';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Switch } from './ui/switch';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';

export interface FeeItem {
  id: string;
  name: string;
  type: 'percentage' | 'fixed';
  value: number;
  enabled: boolean;
}

export interface FeesConfig {
  enabled: boolean;
  fees: FeeItem[];
}

interface FeesSettingsProps {
  onBack: () => void;
  settings: FeesConfig;
  onUpdateSettings: (settings: FeesConfig) => void;
}

export function FeesSettings({ onBack, settings, onUpdateSettings }: FeesSettingsProps) {
  const [config, setConfig] = useState<FeesConfig>(settings);

  const updateConfig = (updates: Partial<FeesConfig>) => {
    const updated = { ...config, ...updates };
    setConfig(updated);
    onUpdateSettings(updated);
  };

  const addFee = () => {
    const newFee: FeeItem = {
      id: Date.now().toString(),
      name: 'Service Charge',
      type: 'percentage',
      value: 0,
      enabled: true,
    };
    updateConfig({ fees: [...config.fees, newFee] });
  };

  const updateFee = (id: string, updates: Partial<FeeItem>) => {
    const fees = config.fees.map(fee =>
      fee.id === id ? { ...fee, ...updates } : fee
    );
    updateConfig({ fees });
  };

  const deleteFee = (id: string) => {
    const fees = config.fees.filter(fee => fee.id !== id);
    updateConfig({ fees });
  };

  const calculateFees = (subtotal: number) => {
    return config.fees
      .filter(fee => fee.enabled)
      .reduce((sum, fee) => {
        if (fee.type === 'percentage') {
          return sum + (subtotal * fee.value / 100);
        }
        return sum + fee.value;
      }, 0);
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-3 flex items-center gap-3 shadow-lg">
        <Button
          onClick={onBack}
          variant="ghost"
          size="icon"
          className="text-[#49842B] hover:bg-[#49842B]/10"
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-[#336A29] font-semibold">Other Fees</h1>
      </div>

      <div className="flex-1 overflow-auto">
        {/* Enable Fees */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-[#336A29] font-medium">Enable Additional Fees</div>
              <div className="text-sm text-[#336A29]/70">Add service charges, packaging, etc.</div>
            </div>
            <Switch
              checked={config.enabled}
              onCheckedChange={(checked) => updateConfig({ enabled: checked })}
            />
          </div>
        </div>

        {config.enabled && (
          <>
            {/* Fee Items */}
            <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl overflow-hidden">
              <div className="px-4 py-3 border-b border-[#336A29]/15 flex items-center justify-between">
                <Label className="text-[#336A29] font-semibold">Fee Items</Label>
                <Button
                  onClick={addFee}
                  size="sm"
                  className="bg-[#49842B] hover:bg-[#336A29]"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Add Fee
                </Button>
              </div>

              {config.fees.length === 0 ? (
                <div className="p-8 text-center text-[#336A29]/50">
                  No fees configured. Click "Add Fee" to create one.
                </div>
              ) : (
                config.fees.map((fee) => (
                  <div key={fee.id} className="px-4 py-3 border-b border-[#336A29]/15">
                    <div className="flex items-center justify-between mb-3">
                      <Switch
                        checked={fee.enabled}
                        onCheckedChange={(checked) => updateFee(fee.id, { enabled: checked })}
                      />
                      <Button
                        onClick={() => deleteFee(fee.id)}
                        variant="ghost"
                        size="sm"
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <div className="space-y-2">
                      <Input
                        id={`fee-name-${fee.id}`}
                        name={`fee-name-${fee.id}`}
                        value={fee.name}
                        onChange={(e) => updateFee(fee.id, { name: e.target.value })}
                        placeholder="Fee name (e.g., Service Charge, Packaging)"
                        className="text-sm bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                      />
                      
                      <RadioGroup
                        value={fee.type}
                        onValueChange={(value) => updateFee(fee.id, { type: value as 'percentage' | 'fixed' })}
                        className="flex gap-4"
                      >
                        <div className="flex items-center gap-2">
                          <RadioGroupItem value="percentage" id={`${fee.id}-percentage`} />
                          <label htmlFor={`${fee.id}-percentage`} className="text-sm text-[#336A29]">Percentage</label>
                        </div>
                        <div className="flex items-center gap-2">
                          <RadioGroupItem value="fixed" id={`${fee.id}-fixed`} />
                          <label htmlFor={`${fee.id}-fixed`} className="text-sm text-[#336A29]">Fixed</label>
                        </div>
                      </RadioGroup>
                      
                      <div className="flex items-center gap-2">
                        <Input
                          id={`fee-value-${fee.id}`}
                          name={`fee-value-${fee.id}`}
                          type="number"
                          step={fee.type === 'percentage' ? '0.1' : '1'}
                          min="0"
                          max={fee.type === 'percentage' ? '100' : undefined}
                          value={fee.value}
                          onChange={(e) => updateFee(fee.id, { value: parseFloat(e.target.value) || 0 })}
                          placeholder="Value"
                          className="text-sm bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                        />
                        <span className="text-[#336A29] font-medium">
                          {fee.type === 'percentage' ? '%' : 'Rs'}
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Preview */}
            <div className="mt-4 mb-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
              <Label className="text-[#336A29] mb-3 block font-semibold">Preview (on Rs 100 subtotal)</Label>
              <div className="border border-[#336A29]/20 rounded-lg p-4 bg-[#80B155]/30 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-[#336A29]/70">Subtotal</span>
                  <span className="text-[#336A29]">Rs 100.00</span>
                </div>
                
                {config.fees.filter(f => f.enabled).map(fee => {
                  const amount = fee.type === 'percentage' 
                    ? 100 * fee.value / 100 
                    : fee.value;
                  return (
                    <div key={fee.id} className="flex justify-between text-sm">
                      <span className="text-[#336A29]/70">
                        {fee.name} {fee.type === 'percentage' ? `(${fee.value}%)` : ''}
                      </span>
                      <span className="text-[#336A29]">Rs {amount.toFixed(2)}</span>
                    </div>
                  );
                })}
                
                <div className="border-t border-[#336A29]/30 pt-2 flex justify-between">
                  <span className="text-[#336A29] font-semibold">Total</span>
                  <span className="text-[#336A29] font-semibold">
                    Rs {(100 + calculateFees(100)).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          </>
        )}

        {/* Info */}
        <div className="mt-4 mb-4 bg-[#49842B]/10 border border-[#49842B]/30 p-4 mx-4 rounded-lg">
          <p className="text-sm text-[#336A29]">
            💡 Common fees: Service Charge, Packaging Fee, Delivery Charge, Platform Fee
          </p>
        </div>
      </div>
    </div>
  );
}