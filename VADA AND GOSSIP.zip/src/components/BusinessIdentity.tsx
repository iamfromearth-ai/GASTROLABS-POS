import { useState } from 'react';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Switch } from './ui/switch';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { ChevronLeft } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export interface BusinessInfo {
  enabled: boolean;
  businessName: string;
  address: string;
  phone: string;
  email: string;
  website: string;
  taxId: string;
}

interface BusinessIdentityProps {
  onBack: () => void;
  settings: BusinessInfo;
  onUpdateSettings: (settings: BusinessInfo) => void;
}

export function BusinessIdentity({ onBack, settings, onUpdateSettings }: BusinessIdentityProps) {
  const [config, setConfig] = useState<BusinessInfo>(settings);

  const updateConfig = (key: keyof BusinessInfo, value: any) => {
    const updated = { ...config, [key]: value };
    setConfig(updated);
    onUpdateSettings(updated);
    
    // Show toast notification for important changes
    if (key === 'businessName') {
      toast.success('✅ Business name updated!');
    } else if (key === 'address') {
      toast.success('✅ Address updated!');
    } else if (key === 'enabled') {
      toast.success(value ? '✅ Business info enabled!' : '✅ Business info disabled!');
    } else {
      toast.success('✅ Settings saved!');
    }
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-3 flex items-center gap-3 shadow-lg">
        <Button
          onClick={onBack}
          variant="ghost"
          size="icon"
          className="text-white hover:bg-[#49842B]/10"
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-white font-semibold">Business Identity</h1>
      </div>

      <div className="flex-1 overflow-auto">
        {/* Enable */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-[#336A29] font-medium">Show Business Info</div>
              <div className="text-sm text-[#336A29]/70">Display on receipts</div>
            </div>
            <Switch
              checked={config.enabled}
              onCheckedChange={(checked) => updateConfig('enabled', checked)}
            />
          </div>
        </div>

        {config.enabled && (
          <>
            {/* Business Details */}
            <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4 space-y-4">
              <div>
                <Label htmlFor="business-name" className="text-[#336A29]">Business Name</Label>
                <Input
                  id="business-name"
                  value={config.businessName}
                  onChange={(e) => updateConfig('businessName', e.target.value)}
                  placeholder="Tea Shop"
                  className="mt-1 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                />
              </div>

              <div>
                <Label htmlFor="address" className="text-[#336A29]">Address</Label>
                <Textarea
                  id="address"
                  value={config.address}
                  onChange={(e) => updateConfig('address', e.target.value)}
                  placeholder="123 Main Street&#10;City, State - 123456"
                  className="mt-1 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                />
              </div>

              <div>
                <Label htmlFor="phone" className="text-[#336A29]">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={config.phone}
                  onChange={(e) => updateConfig('phone', e.target.value)}
                  placeholder="+91 98765 43210"
                  className="mt-1 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                />
              </div>

              <div>
                <Label htmlFor="email" className="text-[#336A29]">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={config.email}
                  onChange={(e) => updateConfig('email', e.target.value)}
                  placeholder="contact@teashop.com"
                  className="mt-1 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                />
              </div>

              <div>
                <Label htmlFor="website" className="text-[#336A29]">Website</Label>
                <Input
                  id="website"
                  type="url"
                  value={config.website}
                  onChange={(e) => updateConfig('website', e.target.value)}
                  placeholder="www.teashop.com"
                  className="mt-1 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                />
              </div>

              <div>
                <Label htmlFor="tax-id" className="text-[#336A29]">Tax ID / GST Number</Label>
                <Input
                  id="tax-id"
                  value={config.taxId}
                  onChange={(e) => updateConfig('taxId', e.target.value)}
                  placeholder="GSTIN: 22AAAAA0000A1Z5"
                  className="mt-1 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                />
              </div>
            </div>

            {/* Preview */}
            <div className="mt-4 mb-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
              <Label className="text-[#336A29] mb-3 block font-semibold">Preview</Label>
              <div className="border border-[#336A29]/20 rounded-lg p-4 bg-[#80B155]">
                <div className="text-center space-y-1 text-sm">
                  {config.businessName && (
                    <div className="text-white font-semibold">{config.businessName}</div>
                  )}
                  {config.address && (
                    <div className="text-white/90 whitespace-pre-wrap">{config.address}</div>
                  )}
                  {config.phone && (
                    <div className="text-white/90">Tel: {config.phone}</div>
                  )}
                  {config.email && (
                    <div className="text-white/90">{config.email}</div>
                  )}
                  {config.website && (
                    <div className="text-white/90">{config.website}</div>
                  )}
                  {config.taxId && (
                    <div className="text-white/90">{config.taxId}</div>
                  )}
                  {!config.businessName && !config.address && !config.phone && (
                    <div className="text-white/50">No business information</div>
                  )}
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}