import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { ChevronLeft, Mail, Send } from 'lucide-react';
import { Switch } from './ui/switch';

export interface EmailConfig {
  enabled: boolean;
  recipientEmail: string;
  subject: string;
  messageTemplate: string;
  includeReceipt: boolean;
  autoSend: boolean;
}

interface EmailSettingsProps {
  onBack: () => void;
  settings: EmailConfig;
  onUpdateSettings: (settings: EmailConfig) => void;
}

export function EmailSettings({ onBack, settings, onUpdateSettings }: EmailSettingsProps) {
  const [config, setConfig] = useState<EmailConfig>(settings);

  const updateConfig = (key: keyof EmailConfig, value: any) => {
    const updated = { ...config, [key]: value };
    setConfig(updated);
    onUpdateSettings(updated);
  };

  const sendTestEmail = () => {
    const subject = encodeURIComponent(config.subject || 'Test Receipt from Tea Shop');
    const body = encodeURIComponent(
      config.messageTemplate || 'This is a test email from your Tea Shop POS.\n\nThank you for your business!'
    );
    const mailtoLink = `mailto:${config.recipientEmail}?subject=${subject}&body=${body}`;
    window.location.href = mailtoLink;
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-3 flex items-center gap-3 shadow-lg">
        <Button
          onClick={onBack}
          variant="ghost"
          size="icon"
          className="text-[#49842B] hover:bg-[#49842B]/10"
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-[#336A29] font-semibold">Email Settings</h1>
      </div>

      <div className="flex-1 overflow-auto">
        {/* Enable Email */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-full flex items-center justify-center shadow-md">
                <Mail className="h-5 w-5 text-white" />
              </div>
              <div>
                <div className="text-[#336A29] font-medium">Enable Email Receipts</div>
                <div className="text-sm text-[#336A29]/70">Send receipts via email</div>
              </div>
            </div>
            <Switch
              checked={config.enabled}
              onCheckedChange={(checked) => updateConfig('enabled', checked)}
            />
          </div>
        </div>

        {/* Email Configuration */}
        {config.enabled && (
          <>
            <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4 space-y-4">
              <div>
                <Label htmlFor="recipient-email" className="text-[#336A29]">
                  Default Recipient Email
                </Label>
                <Input
                  id="recipient-email"
                  type="email"
                  value={config.recipientEmail}
                  onChange={(e) => updateConfig('recipientEmail', e.target.value)}
                  placeholder="customer@example.com"
                  className="mt-1 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                />
                <p className="text-xs text-[#336A29]/70 mt-1">
                  This email will receive receipts by default
                </p>
              </div>

              <div>
                <Label htmlFor="subject" className="text-[#336A29]">
                  Email Subject
                </Label>
                <Input
                  id="subject"
                  value={config.subject}
                  onChange={(e) => updateConfig('subject', e.target.value)}
                  placeholder="Receipt from Tea Shop"
                  className="mt-1 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                />
              </div>

              <div>
                <Label htmlFor="message" className="text-[#336A29]">
                  Message Template
                </Label>
                <Textarea
                  id="message"
                  value={config.messageTemplate}
                  onChange={(e) => updateConfig('messageTemplate', e.target.value)}
                  placeholder="Thank you for your purchase!&#10;&#10;Please find your receipt attached."
                  className="mt-1 min-h-[100px] bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                />
                <p className="text-xs text-[#336A29]/70 mt-1">
                  This message will be included in every receipt email
                </p>
              </div>
            </div>

            {/* Options */}
            <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[#336A29] font-medium">Include Receipt Details</div>
                  <div className="text-sm text-[#336A29]/70">Attach full receipt in email body</div>
                </div>
                <Switch
                  checked={config.includeReceipt}
                  onCheckedChange={(checked) => updateConfig('includeReceipt', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[#336A29] font-medium">Auto Send After Checkout</div>
                  <div className="text-sm text-[#336A29]/70">Automatically open email client</div>
                </div>
                <Switch
                  checked={config.autoSend}
                  onCheckedChange={(checked) => updateConfig('autoSend', checked)}
                />
              </div>
            </div>

            {/* Test Email */}
            <div className="mt-4 mb-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
              <Button
                onClick={sendTestEmail}
                disabled={!config.recipientEmail}
                className="w-full bg-[#49842B] hover:bg-[#336A29]"
              >
                <Send className="h-5 w-5 mr-2" />
                Send Test Email
              </Button>
              <p className="text-sm text-[#336A29]/70 text-center mt-2">
                Opens your default email client with a test message
              </p>
            </div>
          </>
        )}

        {/* Info */}
        <div className="mt-4 mb-4 bg-[#49842B]/10 border border-[#49842B]/30 p-4 mx-4 rounded-lg">
          <p className="text-sm text-[#336A29]">
            ℹ️ Email functionality uses your device's default email client. Make sure you have an email app configured.
          </p>
        </div>
      </div>
    </div>
  );
}