import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ArrowLeft, Users, Trash2, Receipt, X, ShoppingCart } from 'lucide-react';
import { BillItem, MenuItem } from '../App';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { toast } from 'sonner@2.0.3';

export interface TableBill {
  tableNumber: string;
  items: BillItem[];
  openedAt: Date;
  customerName?: string;
}

interface TableManagementProps {
  tables: TableBill[];
  menuItems: MenuItem[];
  onBack: () => void;
  onUpdateTables: (tables: TableBill[]) => void;
  onCheckoutTable: (tableNumber: string) => void;
  currency: string;
}

export function TableManagement({
  tables,
  menuItems,
  onBack,
  onUpdateTables,
  onCheckoutTable,
  currency,
}: TableManagementProps) {
  const [selectedTable, setSelectedTable] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [settleDialogOpen, setSettleDialogOpen] = useState(false);
  const [tableToSettle, setTableToSettle] = useState<string | null>(null);

  // Get all table numbers (occupied + available)
  const maxTables = 20;
  const occupiedTables = tables.map(t => t.tableNumber);
  const allTableNumbers = Array.from({ length: maxTables }, (_, i) => `${i + 1}`);

  const currentTable = tables.find(t => t.tableNumber === selectedTable);

  const calculateTableTotal = (table: TableBill) => {
    return table.items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  };

  const handleOpenTable = (tableNumber: string) => {
    const existingTable = tables.find(t => t.tableNumber === tableNumber);
    if (existingTable) {
      setSelectedTable(tableNumber);
    } else {
      // Create new table
      const newTable: TableBill = {
        tableNumber,
        items: [],
        openedAt: new Date(),
      };
      onUpdateTables([...tables, newTable]);
      setSelectedTable(tableNumber);
    }
  };

  const handleAddItem = (item: MenuItem) => {
    if (!selectedTable) return;

    // Check stock availability if item has stock tracking enabled
    if (item.stock !== undefined) {
      if (item.stock <= 0) {
        toast.error(`${item.name} is out of stock!`);
        return;
      }
      
      // Check current quantity already in the table's bill
      const currentTable = tables.find(t => t.tableNumber === selectedTable);
      const currentTableItem = currentTable?.items.find(i => i.id === item.id);
      const currentQuantityInTable = currentTableItem ? currentTableItem.quantity : 0;
      
      if (currentQuantityInTable >= item.stock) {
        toast.error(`Only ${item.stock} ${item.name} available in stock!`);
        return;
      }
    }

    const updatedTables = tables.map(table => {
      if (table.tableNumber === selectedTable) {
        const existingItem = table.items.find(i => i.id === item.id);
        if (existingItem) {
          return {
            ...table,
            items: table.items.map(i =>
              i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
            ),
          };
        }
        return {
          ...table,
          items: [...table.items, { ...item, quantity: 1 }],
        };
      }
      return table;
    });

    onUpdateTables(updatedTables);
  };

  const handleRemoveItem = (itemId: string) => {
    if (!selectedTable) return;

    const updatedTables = tables.map(table => {
      if (table.tableNumber === selectedTable) {
        return {
          ...table,
          items: table.items.filter(i => i.id !== itemId),
        };
      }
      return table;
    });

    onUpdateTables(updatedTables);
  };

  const handleSettleTable = () => {
    if (!tableToSettle) return;
    
    onCheckoutTable(tableToSettle);
    setSettleDialogOpen(false);
    setTableToSettle(null);
    setSelectedTable(null);
  };

  const handleClearTable = (tableNumber: string) => {
    const updatedTables = tables.filter(t => t.tableNumber !== tableNumber);
    onUpdateTables(updatedTables);
    if (selectedTable === tableNumber) {
      setSelectedTable(null);
    }
  };

  const openSettleDialog = (tableNumber: string) => {
    setTableToSettle(tableNumber);
    setSettleDialogOpen(true);
  };

  // Filter menu items by search
  const filteredMenuItems = searchQuery.trim()
    ? menuItems.filter(item =>
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : menuItems;

  // Group by category
  const groupedItems = filteredMenuItems.reduce((acc, item) => {
    if (!acc[item.category]) {
      acc[item.category] = [];
    }
    acc[item.category].push(item);
    return acc;
  }, {} as Record<string, MenuItem[]>);

  // Table Grid View (when no table selected)
  if (!selectedTable) {
    return (
      <div className="min-h-screen bg-[#EAEF9D] flex flex-col">
        {/* Mobile Container */}
        <div className="flex-1 flex flex-col max-w-[600px] w-full mx-auto">
          {/* Header */}
          <div className="bg-[#49842B] px-4 py-3 shadow-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Button
                  onClick={onBack}
                  variant="ghost"
                  size="icon"
                  className="text-white hover:bg-white/20 rounded-full"
                >
                  <ArrowLeft className="h-5 w-5" />
                </Button>
                <div>
                  <h1 className="text-white font-bold">Table Service Mode</h1>
                  <p className="text-white/80 text-xs">Tap a table to start</p>
                </div>
              </div>
              <Badge variant="secondary" className="bg-white/20 text-white border-0">
                {occupiedTables.length}/{maxTables}
              </Badge>
            </div>
          </div>

          {/* Table Grid */}
          <ScrollArea className="flex-1">
            <div className="p-4">
              <div className="grid grid-cols-3 gap-3">
                {allTableNumbers.map(tableNum => {
                  const table = tables.find(t => t.tableNumber === tableNum);
                  const isOccupied = !!table;
                  const total = table ? calculateTableTotal(table) : 0;
                  const itemCount = table?.items.reduce((sum, item) => sum + item.quantity, 0) || 0;

                  return (
                    <button
                      key={tableNum}
                      onClick={() => handleOpenTable(tableNum)}
                      className={`
                        relative rounded-2xl p-4 transition-all duration-200 active:scale-95
                        shadow-md hover:shadow-xl border-2
                        ${isOccupied
                          ? 'bg-gradient-to-br from-[#C1D95C] to-[#80B155] border-[#49842B]'
                          : 'bg-white border-gray-200 hover:border-[#49842B]'
                        }
                      `}
                    >
                      <div className="flex flex-col items-center justify-center gap-2 min-h-[100px]">
                        <Users className={`h-10 w-10 ${isOccupied ? 'text-white' : 'text-gray-400'}`} />
                        <div className="text-center">
                          <div className={`font-bold ${isOccupied ? 'text-white' : 'text-gray-700'}`}>
                            Table {tableNum}
                          </div>
                          {isOccupied ? (
                            <>
                              <div className="text-white text-xs mt-0.5">
                                {itemCount} items
                              </div>
                              <div className="text-white font-bold text-sm mt-1">
                                {currency} {total}
                              </div>
                            </>
                          ) : (
                            <div className="text-gray-400 text-xs mt-0.5">Available</div>
                          )}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </ScrollArea>
        </div>
      </div>
    );
  }

  // Single Table View
  const tableTotal = currentTable ? calculateTableTotal(currentTable) : 0;
  const tableItemCount = currentTable?.items.reduce((sum, item) => sum + item.quantity, 0) || 0;

  return (
    <div className="min-h-screen bg-[#EAEF9D] flex flex-col">
      {/* Mobile Container */}
      <div className="flex-1 flex flex-col max-w-[600px] w-full mx-auto">
        {/* Header */}
        <div className="bg-[#49842B] px-4 py-3 shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Button
                onClick={() => setSelectedTable(null)}
                variant="ghost"
                size="icon"
                className="text-white hover:bg-white/20 rounded-full"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-white font-bold">Table {selectedTable}</h1>
                <p className="text-white/80 text-xs">
                  {tableItemCount} items • {currency} {tableTotal}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {currentTable && currentTable.items.length > 0 && (
                <Button
                  onClick={() => openSettleDialog(selectedTable)}
                  className="bg-green-600 hover:bg-green-700 text-white h-9 px-3"
                  size="sm"
                >
                  <Receipt className="h-4 w-4 mr-1.5" />
                  <span className="hidden sm:inline">Settle</span>
                </Button>
              )}
              <Button
                onClick={() => {
                  if (confirm('Clear this table?')) {
                    handleClearTable(selectedTable);
                  }
                }}
                variant="destructive"
                size="icon"
                className="h-9 w-9"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Current Bill */}
        {currentTable && currentTable.items.length > 0 && (
          <div className="bg-white border-b shadow-md">
            <div className="px-4 py-2">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-bold text-sm flex items-center gap-2">
                  <ShoppingCart className="h-4 w-4" />
                  Current Bill
                </h3>
                <span className="text-sm text-gray-600">{tableItemCount} items</span>
              </div>
              <ScrollArea className="max-h-32">
                <div className="space-y-1.5">
                  {currentTable.items.map(item => (
                    <div key={item.id} className="flex items-center justify-between bg-gray-50 rounded-lg p-2 text-sm">
                      <div className="flex-1 min-w-0 mr-2">
                        <span className="font-medium">{item.name}</span>
                        <span className="text-gray-600 ml-2">× {item.quantity}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold whitespace-nowrap">
                          {currency} {item.price * item.quantity}
                        </span>
                        <Button
                          onClick={() => handleRemoveItem(item.id)}
                          size="icon"
                          variant="ghost"
                          className="h-6 w-6 text-red-600"
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
              <div className="flex justify-between items-center pt-2 mt-2 border-t">
                <span className="font-bold">Total:</span>
                <span className="font-bold text-lg">{currency} {tableTotal}</span>
              </div>
            </div>
          </div>
        )}

        {/* Empty State */}
        {(!currentTable || currentTable.items.length === 0) && (
          <div className="bg-blue-50 border-b border-blue-200 px-4 py-3">
            <div className="flex items-start gap-3">
              <div className="bg-blue-500 rounded-full p-2 flex-shrink-0">
                <Users className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="font-medium text-blue-900 text-sm">No items added yet</p>
                <p className="text-blue-700 text-xs mt-0.5">
                  Tap menu items below to add to this table
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Search */}
        <div className="px-4 pt-4 pb-2">
          <Input
            type="text"
            placeholder="🔍 Search items..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="h-11 bg-white text-base"
          />
        </div>

        {/* Menu Items */}
        <ScrollArea className="flex-1">
          <div className="px-4 pb-4">
            {Object.keys(groupedItems).length === 0 ? (
              <div className="text-center text-gray-400 mt-8">
                <p>No items found</p>
              </div>
            ) : (
              <div className="space-y-4">
                {Object.entries(groupedItems).map(([category, items]) => (
                  <div key={category}>
                    <h3 className="font-bold text-gray-700 mb-2 px-1">{category}</h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                      {items.map(item => {
                        const inCart = currentTable?.items.find(i => i.id === item.id);
                        return (
                          <button
                            key={item.id}
                            onClick={() => handleAddItem(item)}
                            className="relative bg-white hover:bg-[#C1D95C] border-2 border-gray-200 hover:border-[#49842B] rounded-xl p-4 transition-all active:scale-95 shadow-sm hover:shadow-md"
                          >
                            {inCart && (
                              <Badge className="absolute -top-2 -right-2 bg-green-600 text-white rounded-full h-6 w-6 flex items-center justify-center text-xs">
                                {inCart.quantity}
                              </Badge>
                            )}
                            <div className="text-left">
                              <div className="font-medium text-gray-800 text-sm mb-1 line-clamp-2">
                                {item.name}
                              </div>
                              <div className="font-bold text-gray-900 text-lg">
                                {currency} {item.price}
                              </div>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Settlement Dialog - Custom Implementation */}
        {settleDialogOpen && (
          <>
            {/* Backdrop */}
            <div 
              className="fixed inset-0 bg-black/50 z-[9998]"
              onClick={() => setSettleDialogOpen(false)}
            />
            
            {/* Dialog Container - Centered */}
            <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
              <div className="w-full max-w-lg">
                <div className="bg-gradient-to-br from-[#EAEF9D] to-[#C1D95C] rounded-2xl shadow-2xl p-8 border-2 border-[#49842B]/20 mx-auto">
                  {/* Header */}
                  <div className="mb-6 text-center">
                    <h2 className="font-bold text-2xl text-[#336A29] mb-2">Settle Table {tableToSettle}?</h2>
                    <p className="text-sm text-[#49842B]/80">
                      This will print the final bill and clear the table for the next customer.
                    </p>
                  </div>

                  {/* Bill Summary */}
                  {tableToSettle && (
                    <div className="bg-white/60 backdrop-blur-sm p-5 rounded-xl space-y-3 mb-6 border border-[#49842B]/20 shadow-md">
                      <div className="flex justify-between items-center">
                        <span className="text-[#336A29]/80">Items:</span>
                        <span className="font-bold text-[#336A29] text-lg">
                          {tables.find(t => t.tableNumber === tableToSettle)?.items.reduce(
                            (sum, item) => sum + item.quantity,
                            0
                          )}
                        </span>
                      </div>
                      <div className="flex justify-between items-center text-xl font-bold pt-3 border-t-2 border-[#49842B]/20">
                        <span className="text-[#336A29]">Total:</span>
                        <span className="text-[#49842B]">
                          {currency}{' '}
                          {calculateTableTotal(tables.find(t => t.tableNumber === tableToSettle)!)}
                        </span>
                      </div>
                    </div>
                  )}

                  {/* Buttons */}
                  <div className="flex flex-col sm:flex-row gap-3">
                    <button
                      onClick={() => setSettleDialogOpen(false)}
                      className="flex-1 px-6 py-3 rounded-xl border-2 border-[#49842B]/30 bg-white/40 hover:bg-white/60 text-[#336A29] font-bold transition-all active:scale-95 shadow-md hover:shadow-lg"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSettleTable}
                      className="flex-1 px-6 py-3 rounded-xl bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white font-bold transition-all active:scale-95 shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
                    >
                      <Receipt className="h-5 w-5" />
                      Print & Settle
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}