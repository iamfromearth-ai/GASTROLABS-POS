import { useState, useRef } from 'react';
import { Order } from '../App';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ArrowLeft, Trash2, Search, Calendar, Download, Scan, X, QrCode } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from './ui/tabs';
import { Badge } from './ui/badge';
import { PasswordDialog } from './PasswordDialog';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Calendar as CalendarComponent } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { toast } from 'sonner@2.0.3';
import { useEffect } from 'react';
import { QRScanner } from './QRScanner';

interface OrderHistoryProps {
  orders: Order[];
  onBack: () => void;
  onMarkAsPaid: (orderId: string) => void;
  onDelete: (orderId: string) => void;
}

export function OrderHistory({ orders, onBack, onMarkAsPaid, onDelete }: OrderHistoryProps) {
  const [filterPeriod, setFilterPeriod] = useState<'today' | 'all'>('today');
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchInput, setShowSearchInput] = useState(false);
  const [dateRange, setDateRange] = useState<{ from?: Date; to?: Date }>({});
  const [showCalendar, setShowCalendar] = useState(false);
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);
  const [showQRScanner, setShowQRScanner] = useState(false);

  // Check if password protection is enabled
  const isPasswordProtected = () => {
    return !!localStorage.getItem('adminPassword');
  };

  const handleDeleteClick = (orderId: string) => {
    if (isPasswordProtected()) {
      setPendingDeleteId(orderId);
      setShowPasswordDialog(true);
    } else {
      onDelete(orderId);
    }
  };

  const handlePasswordSuccess = () => {
    if (pendingDeleteId) {
      onDelete(pendingDeleteId);
      setPendingDeleteId(null);
    }
  };

  const handleQRScan = (data: string) => {
    // The QR code contains the order ID
    const scannedOrderId = data;
    
    // Find the order by exact match or partial match (last 6 characters)
    const order = orders.find(
      (o) => o.id === scannedOrderId || o.id.endsWith(scannedOrderId) || scannedOrderId.includes(o.id)
    );

    if (order) {
      if (order.status === 'active') {
        onMarkAsPaid(order.id);
        toast.success(`✓ Order #${order.id.slice(-6)} marked as PAID!`, {
          description: `Amount: Rs ${order.total}`,
        });
      } else {
        toast.info(`Order #${order.id.slice(-6)} is already paid.`);
      }
    } else {
      toast.error('Order not found. Please check the QR code.');
    }
  };

  const isToday = (date: Date) => {
    const today = new Date();
    const orderDate = new Date(date);
    return (
      orderDate.getDate() === today.getDate() &&
      orderDate.getMonth() === today.getMonth() &&
      orderDate.getFullYear() === today.getFullYear()
    );
  };

  const filteredOrders = orders.filter((order) => {
    const matchesPeriod = filterPeriod === 'all' || isToday(order.timestamp);
    const matchesSearch = order.items.some((item) =>
      item.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
    const matchesDateRange =
      !dateRange.from ||
      !dateRange.to ||
      (new Date(order.timestamp) >= dateRange.from && new Date(order.timestamp) <= dateRange.to);
    return matchesPeriod && (searchQuery === '' || matchesSearch) && matchesDateRange;
  });

  const activeOrders = filteredOrders.filter((o) => o.status === 'active');
  const paidOrders = filteredOrders.filter((o) => o.status === 'paid');

  const handleExportCSV = () => {
    const csvContent = [
      ['Order ID', 'Date', 'Time', 'Items', 'Total', 'Status'],
      ...orders.map((order) => [
        order.id,
        new Date(order.timestamp).toLocaleDateString('en-IN'),
        new Date(order.timestamp).toLocaleTimeString('en-IN'),
        order.items.map((item) => `${item.quantity}x ${item.name}`).join('; '),
        order.total,
        order.status,
      ]),
    ]
      .map((row) => row.join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `orders-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const OrderCard = ({ order }: { order: Order }) => (
    <div className="px-4 py-4 border-b border-[#336A29]/15 hover:bg-[#80B155] transition-colors">
      <div className="flex items-start justify-between mb-2">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-mono text-[#336A29] font-medium">
              #{order.id.slice(-6)}
            </span>
            <Badge
              variant={order.status === 'active' ? 'default' : 'secondary'}
              className={
                order.status === 'active'
                  ? 'bg-gradient-to-r from-[#FF8A65] to-[#FF7043] text-white border-0'
                  : 'bg-gradient-to-r from-[#66BB6A] to-[#4CAF50] text-white border-0'
              }
            >
              {order.status === 'active' ? 'UNPAID' : 'PAID'}
            </Badge>
          </div>
          <p className="text-sm text-[#336A29]/70">
            {new Date(order.timestamp).toLocaleDateString('en-IN', {
              day: 'numeric',
              month: 'short',
              year: 'numeric',
            })}
            {' • '}
            {new Date(order.timestamp).toLocaleTimeString('en-IN', {
              hour: '2-digit',
              minute: '2-digit',
            })}
          </p>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => handleDeleteClick(order.id)}
          className="text-[#336A29]/70 hover:text-[#ff6b6b] hover:bg-[#ff6b6b]/10"
        >
          <Trash2 className="h-5 w-5" />
        </Button>
      </div>

      <div className="space-y-1 mb-3">
        {order.items.map((item, idx) => (
          <div key={idx} className="flex justify-between text-sm">
            <span className="text-[#336A29]/80">
              {item.quantity}x {item.name}
            </span>
            <span className="text-[#336A29] font-medium">Rs {item.price * item.quantity}</span>
          </div>
        ))}
      </div>

      <div className="pt-2 border-t border-[#336A29]/15">
        <div className="flex items-center justify-between">
          <span className="text-[#336A29] font-semibold">Total: Rs {order.total}</span>
          {order.status === 'active' && (
            <div className="flex items-center gap-2 text-sm text-[#49842B]">
              <QrCode className="h-4 w-4" />
              <span>QR Code Payment Enabled</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-3 shadow-lg">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <Button onClick={onBack} variant="ghost" size="icon" className="text-white hover:bg-[#49842B]/10">
              <ArrowLeft className="h-6 w-6" />
            </Button>
            <h1 className="text-white font-semibold">Orders</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:bg-[#49842B]/10"
              onClick={handleExportCSV}
              title="Export to CSV"
            >
              <Download className="h-5 w-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="text-[#49842B] hover:bg-[#49842B]/10"
              onClick={() => setShowSearchInput(!showSearchInput)}
              title="Search Orders"
            >
              <Search className="h-5 w-5" />
            </Button>
            <Popover open={showCalendar} onOpenChange={setShowCalendar}>
              <PopoverTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-white hover:bg-[#49842B]/10"
                  title="Filter by Date"
                >
                  <Calendar className="h-5 w-5" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="end">
                <div className="p-3 bg-white rounded-lg">
                  <CalendarComponent
                    mode="single"
                    selected={dateRange.from}
                    onSelect={(date) => {
                      if (date) {
                        setDateRange({ from: date, to: date });
                        toast.success('Date filter applied');
                      }
                    }}
                  />
                  <div className="mt-2 flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex-1"
                      onClick={() => {
                        setDateRange({});
                        setShowCalendar(false);
                        toast.success('Date filter cleared');
                      }}
                    >
                      Clear
                    </Button>
                    <Button
                      size="sm"
                      className="flex-1 bg-gradient-to-r from-[#49842B] to-[#336A29] text-white"
                      onClick={() => setShowCalendar(false)}
                    >
                      Done
                    </Button>
                  </div>
                </div>
              </PopoverContent>
            </Popover>
            <Button
              variant="ghost"
              size="icon"
              className="text-[#49842B] hover:bg-[#49842B]/10"
              onClick={() => setShowQRScanner(true)}
              title="Scan QR Code"
            >
              <Scan className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Period Filter */}
        <div className="flex gap-2">
          <Button
            variant={filterPeriod === 'today' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilterPeriod('today')}
            className={filterPeriod === 'today' ? 'bg-gradient-to-r from-[#49842B] to-[#336A29] text-white border-0' : 'bg-[#80B155] text-white border-[#336A29]/20 hover:bg-[#49842B]'}
          >
            Today
            <Badge variant="secondary" className="ml-2 bg-white/20 text-white border-0">
              {orders.filter((o) => isToday(o.timestamp)).length}
            </Badge>
          </Button>
          <Button
            variant={filterPeriod === 'all' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilterPeriod('all')}
            className={filterPeriod === 'all' ? 'bg-gradient-to-r from-[#49842B] to-[#336A29] text-white border-0' : 'bg-[#80B155] text-white border-[#336A29]/20 hover:bg-[#49842B]'}
          >
            All
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="unpaid" className="flex-1 flex flex-col">
        <TabsList className="w-full justify-start rounded-none border-b border-[#336A29]/15 bg-[#C1D95C] p-0">
          <TabsTrigger
            value="unpaid"
            className="flex-1 rounded-none border-b-2 border-transparent data-[state=active]:border-[#FF8A65] data-[state=active]:bg-transparent text-[#336A29]/70 data-[state=active]:text-[#336A29] gap-2"
          >
            Unpaid Bills
            {activeOrders.length > 0 && (
              <Badge className="bg-gradient-to-r from-[#FF8A65] to-[#FF7043] text-white border-0">
                {activeOrders.length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger
            value="paid"
            className="flex-1 rounded-none border-b-2 border-transparent data-[state=active]:border-[#66BB6A] data-[state=active]:bg-transparent text-[#336A29]/70 data-[state=active]:text-[#336A29]"
          >
            Paid History
          </TabsTrigger>
        </TabsList>

        <TabsContent value="unpaid" className="flex-1 overflow-auto mt-0 bg-[#EAEF9D]">
          {activeOrders.length === 0 ? (
            <div className="text-center py-16 text-[#336A29]/60">
              <QrCode className="h-16 w-16 mx-auto mb-4 text-[#336A29]/40" />
              <p className="text-lg text-[#336A29]">No unpaid bills</p>
              <p className="text-sm mt-2">All orders have been settled!</p>
            </div>
          ) : (
            <>
              <div className="bg-gradient-to-r from-[#FF8A65]/20 to-[#FF7043]/20 border-b border-[#FF8A65]/30 px-4 py-3 backdrop-blur-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-[#336A29]">
                      <span className="font-semibold">{activeOrders.length}</span> unpaid {activeOrders.length === 1 ? 'order' : 'orders'}
                    </p>
                    <p className="text-xs text-[#336A29]/70 mt-0.5">
                      Scan QR codes to settle payments quickly
                    </p>
                  </div>
                  <Button
                    onClick={() => setShowQRScanner(true)}
                    size="sm"
                    className="bg-gradient-to-r from-[#FF8A65] to-[#FF7043] hover:from-[#FF7043] hover:to-[#FF8A65] text-white border-0"
                  >
                    <Scan className="h-4 w-4 mr-2" />
                    Scan Now
                  </Button>
                </div>
              </div>
              <div className="bg-[#EAEF9D]">
                {activeOrders.map((order) => <OrderCard key={order.id} order={order} />)}
              </div>
            </>
          )}
        </TabsContent>

        <TabsContent value="paid" className="flex-1 overflow-auto mt-0 bg-[#EAEF9D]">
          {paidOrders.length === 0 ? (
            <div className="text-center py-16 text-[#336A29]/60">
              <p className="text-lg text-[#336A29]">No payment history</p>
              <p className="text-sm mt-2">Settled orders will appear here</p>
            </div>
          ) : (
            <div className="bg-[#EAEF9D]">
              {paidOrders.map((order) => <OrderCard key={order.id} order={order} />)}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Password Dialog */}
      <PasswordDialog
        open={showPasswordDialog}
        onOpenChange={setShowPasswordDialog}
        onSuccess={handlePasswordSuccess}
        title="Delete Order - Admin Password Required"
        description="Enter admin password to delete this order"
      />

      {/* QR Scanner */}
      <QRScanner
        open={showQRScanner}
        onOpenChange={setShowQRScanner}
        onScan={handleQRScan}
        startWithCamera={true}
      />

      {/* Floating Scan Button - Shows when there are active orders */}
      {activeOrders.length > 0 && (
        <Button
          onClick={() => setShowQRScanner(true)}
          className="fixed bottom-6 right-6 h-16 w-16 rounded-full shadow-2xl bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white z-50 border-0"
          title="Quick Scan QR Code"
        >
          <Scan className="h-7 w-7" />
        </Button>
      )}

      {/* Search Input */}
      {showSearchInput && (
        <div className="absolute top-16 left-4 right-4 bg-[#EAEF9D] p-4 shadow-lg">
          <Input
            type="text"
            placeholder="Search orders..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full"
          />
        </div>
      )}
    </div>
  );
}