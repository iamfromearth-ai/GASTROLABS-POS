import { useState } from 'react';
import { Button } from './ui/button';
import { ArrowLeft, Check } from 'lucide-react';
import { Input } from './ui/input';

interface CurrencyOption {
  code: string;
  symbol: string;
  name: string;
  country: string;
}

const CURRENCIES: CurrencyOption[] = [
  { code: 'INR', symbol: '₹', name: 'Indian Rupee', country: 'India' },
  { code: 'USD', symbol: '$', name: 'US Dollar', country: 'United States' },
  { code: 'EUR', symbol: '€', name: 'Euro', country: 'European Union' },
  { code: 'GBP', symbol: '£', name: 'British Pound', country: 'United Kingdom' },
  { code: 'JPY', symbol: '¥', name: 'Japanese Yen', country: 'Japan' },
  { code: 'CNY', symbol: '¥', name: 'Chinese Yuan', country: 'China' },
  { code: 'AUD', symbol: 'A$', name: 'Australian Dollar', country: 'Australia' },
  { code: 'CAD', symbol: 'C$', name: 'Canadian Dollar', country: 'Canada' },
  { code: 'CHF', symbol: 'Fr', name: 'Swiss Franc', country: 'Switzerland' },
  { code: 'SGD', symbol: 'S$', name: 'Singapore Dollar', country: 'Singapore' },
  { code: 'AED', symbol: 'د.إ', name: 'UAE Dirham', country: 'United Arab Emirates' },
  { code: 'SAR', symbol: '﷼', name: 'Saudi Riyal', country: 'Saudi Arabia' },
  { code: 'BDT', symbol: '৳', name: 'Bangladeshi Taka', country: 'Bangladesh' },
  { code: 'PKR', symbol: 'Rs', name: 'Pakistani Rupee', country: 'Pakistan' },
  { code: 'LKR', symbol: 'Rs', name: 'Sri Lankan Rupee', country: 'Sri Lanka' },
  { code: 'NPR', symbol: 'Rs', name: 'Nepalese Rupee', country: 'Nepal' },
  { code: 'MYR', symbol: 'RM', name: 'Malaysian Ringgit', country: 'Malaysia' },
  { code: 'THB', symbol: '฿', name: 'Thai Baht', country: 'Thailand' },
  { code: 'IDR', symbol: 'Rp', name: 'Indonesian Rupiah', country: 'Indonesia' },
  { code: 'PHP', symbol: '₱', name: 'Philippine Peso', country: 'Philippines' },
];

interface CurrencySettingsProps {
  onBack: () => void;
  currentCurrency: string;
  onUpdateCurrency: (symbol: string) => void;
}

export function CurrencySettings({ onBack, currentCurrency, onUpdateCurrency }: CurrencySettingsProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCurrencies = CURRENCIES.filter(
    (curr) =>
      curr.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      curr.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      curr.country.toLowerCase().includes(searchQuery.toLowerCase()) ||
      curr.symbol.includes(searchQuery)
  );

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-3 flex items-center gap-3 shadow-lg">
        <Button
          onClick={onBack}
          variant="ghost"
          size="icon"
          className="text-[#49842B] hover:bg-[#49842B]/10"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-[#336A29] font-semibold">Currency</h1>
      </div>

      {/* Search */}
      <div className="bg-[#C1D95C] px-4 py-3 border-b border-[#336A29]/15">
        <Input
          id="currency-search"
          name="currency-search"
          placeholder="Search currencies..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="bg-[#80B155] border-[#336A29]/20 text-[#336A29] placeholder:text-[#336A29]/60 focus:border-[#49842B] rounded-xl"
        />
      </div>

      {/* Currency List */}
      <div className="flex-1 overflow-auto bg-[#EAEF9D]">
        {filteredCurrencies.map((curr) => (
          <button
            key={curr.code}
            onClick={() => onUpdateCurrency(curr.symbol)}
            className="w-full px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15 hover:bg-[#C1D95C] transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#49842B] to-[#336A29] flex items-center justify-center text-white font-semibold shadow-md">
                {curr.symbol}
              </div>
              <div className="text-left">
                <div className="text-[#336A29] font-medium">{curr.name}</div>
                <div className="text-sm text-[#336A29]/70">
                  {curr.code} • {curr.country}
                </div>
              </div>
            </div>
            {currentCurrency === curr.symbol && (
              <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#49842B] to-[#336A29] flex items-center justify-center shadow-md">
                <Check className="h-4 w-4 text-white" />
              </div>
            )}
          </button>
        ))}
      </div>

      {/* Note */}
      <div className="bg-[#C1D95C] px-4 py-3 border-t border-[#336A29]/15">
        <p className="text-sm text-[#336A29]/70 text-center">
          This only changes the currency symbol displayed. Exchange rates are not applied.
        </p>
      </div>
    </div>
  );
}