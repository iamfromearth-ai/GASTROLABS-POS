import { BillItem } from '../App';

interface ReceiptTapeProps {
  items: BillItem[];
  total: number;
}

export function ReceiptTape({ items, total }: ReceiptTapeProps) {
  return (
    <div className="bg-white px-4 py-3 border border-neutral-200 shadow-sm rounded-2xl">
      <div className="max-w-md mx-auto font-mono">
        {items.length === 0 ? (
          <p className="text-center text-neutral-400 text-xs py-4">~ Empty Receipt ~</p>
        ) : (
          <div className="space-y-0.5">
            {/* Receipt Header */}
            <div className="border-b border-dashed border-neutral-300 pb-1 mb-2">
              <p className="text-xs text-neutral-600 text-center">CURRENT BILL</p>
            </div>
            
            {/* Items - One by one like typewriter */}
            {items.map((item, idx) => (
              <div key={idx} className="flex justify-between items-start text-xs py-0.5 border-b border-dotted border-neutral-200">
                <div className="flex gap-2 flex-1">
                  <span className="text-neutral-700 font-semibold">{item.quantity}x</span>
                  <span className="text-neutral-900">{item.name}</span>
                </div>
                <span className="text-neutral-900 font-semibold ml-2">₹{(item.price * item.quantity).toFixed(2)}</span>
              </div>
            ))}
            
            {/* Total Section */}
            <div className="border-t-2 border-neutral-800 mt-2 pt-1">
              <div className="flex justify-between items-center">
                <span className="text-neutral-900 font-bold">TOTAL</span>
                <span className="text-neutral-900 font-bold">₹ {total}</span>
              </div>
            </div>
            
            {/* Bottom dashed line */}
            <div className="border-t border-dashed border-neutral-300 mt-2 pt-1">
              <p className="text-xs text-neutral-500 text-center">Items: {items.length}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}