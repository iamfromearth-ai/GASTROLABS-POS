import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ArrowLeft, Plus, Tag, Trash2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';
import { Label } from './ui/label';
import { PasswordDialog } from './PasswordDialog';

interface CategoryManagementProps {
  categories: string[];
  onBack: () => void;
  onUpdate: (categories: string[]) => void;
}

export function CategoryManagement({ categories, onBack, onUpdate }: CategoryManagementProps) {
  const [newCategory, setNewCategory] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [pendingDeleteCategory, setPendingDeleteCategory] = useState<string | null>(null);

  // Check if password protection is enabled
  const isPasswordProtected = () => {
    return !!localStorage.getItem('adminPassword');
  };

  const handleAddCategory = () => {
    if (newCategory && !categories.includes(newCategory)) {
      onUpdate([...categories, newCategory]);
      setNewCategory('');
      setDialogOpen(false);
    }
  };

  const handleDeleteClick = (category: string) => {
    if (isPasswordProtected()) {
      setPendingDeleteCategory(category);
      setShowPasswordDialog(true);
    } else {
      onUpdate(categories.filter((cat) => cat !== category));
    }
  };

  const handlePasswordSuccess = () => {
    if (pendingDeleteCategory) {
      onUpdate(categories.filter((cat) => cat !== pendingDeleteCategory));
      setPendingDeleteCategory(null);
    }
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-4 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-3">
          <Button
            onClick={onBack}
            variant="ghost"
            size="icon"
            className="text-[#49842B] hover:bg-[#49842B]/10"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-[#336A29] font-semibold">Categories</h1>
            <p className="text-sm text-[#336A29]/70">{categories.length} categories</p>
          </div>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white rounded-full border-0">
              <Plus className="h-4 w-4 mr-2" />
              Add Category
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-[#C1D95C] border-[#336A29]/15">
            <DialogHeader>
              <DialogTitle className="text-[#336A29]">Add New Category</DialogTitle>
              <DialogDescription className="text-[#336A29]/70">Create a new category for your items.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="category" className="text-[#336A29]">Category Name</Label>
                <Input
                  id="category"
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  placeholder="e.g. Beverages"
                  className="bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70 focus:border-[#49842B]"
                />
              </div>
              <Button onClick={handleAddCategory} className="w-full bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white border-0">
                Add Category
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Categories List */}
      <div className="flex-1 overflow-auto bg-[#EAEF9D]">
        {categories.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-[#336A29]/60">
            <Tag className="h-12 w-12 mb-3" />
            <p className="text-[#336A29]">No categories yet</p>
          </div>
        ) : (
          <div className="p-4 space-y-3">
            {categories.map((category) => (
              <div
                key={category}
                className="bg-[#C1D95C] rounded-2xl border border-[#336A29]/15 p-4 hover:bg-[#80B155] hover:border-[#49842B]/50 transition-all"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center shadow-lg">
                      <Tag className="h-6 w-6 text-white" />
                    </div>
                    <span className="text-[#336A29] font-medium">{category}</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDeleteClick(category)}
                    className="text-[#FF8A65] hover:bg-[#FF8A65]/10 h-9 w-9 rounded-xl"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Password Dialog */}
      <PasswordDialog
        open={showPasswordDialog}
        onOpenChange={setShowPasswordDialog}
        onSuccess={handlePasswordSuccess}
        title="Delete Category - Admin Password Required"
        description="Enter admin password to delete this category"
      />
    </div>
  );
}