import { useState } from 'react';
import { MenuItem } from '../App';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ArrowLeft, Plus, Search, Edit, Trash2, Package, Tag } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { PasswordDialog } from './PasswordDialog';

interface InventoryManagementProps {
  items: MenuItem[];
  categories: string[];
  onBack: () => void;
  onUpdateItems: (items: MenuItem[]) => void;
  onUpdateCategories: (categories: string[]) => void;
}

export function InventoryManagement({ items, categories, onBack, onUpdateItems, onUpdateCategories }: InventoryManagementProps) {
  const [activeTab, setActiveTab] = useState<'items' | 'categories'>('items');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Item states
  const [newItem, setNewItem] = useState<MenuItem>({ id: '', name: '', price: 0, category: '', stock: undefined });
  const [itemDialogOpen, setItemDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  const [showItemPasswordDialog, setShowItemPasswordDialog] = useState(false);
  const [pendingDeleteItemId, setPendingDeleteItemId] = useState<string | null>(null);
  const [stockToAdd, setStockToAdd] = useState<number>(0);
  const [stockMode, setStockMode] = useState<'add' | 'set'>('add');
  
  // Category states
  const [newCategory, setNewCategory] = useState('');
  const [categoryDialogOpen, setCategoryDialogOpen] = useState(false);
  const [showCategoryPasswordDialog, setShowCategoryPasswordDialog] = useState(false);
  const [pendingDeleteCategory, setPendingDeleteCategory] = useState<string | null>(null);

  // Check if password protection is enabled
  const isPasswordProtected = () => {
    return !!localStorage.getItem('adminPassword');
  };

  // Item handlers
  const filteredItems = items.filter(
    (item) =>
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddItem = () => {
    if (newItem.name && newItem.price && newItem.category) {
      const newItemWithId: MenuItem = {
        id: Date.now().toString(),
        name: newItem.name,
        price: newItem.price,
        category: newItem.category,
        stock: newItem.stock,
      };
      onUpdateItems([...items, newItemWithId]);
      setNewItem({ id: '', name: '', price: 0, category: '', stock: undefined });
      setItemDialogOpen(false);
    }
  };

  const handleEditClick = (item: MenuItem) => {
    setEditingItem(item);
    setStockToAdd(0);
    setStockMode('add');
    setEditDialogOpen(true);
  };

  const handleUpdateItem = () => {
    if (editingItem) {
      let finalItem = { ...editingItem };
      
      // If in "add" mode and stockToAdd > 0, add to existing stock
      if (stockMode === 'add' && stockToAdd > 0) {
        const currentStock = editingItem.stock ?? 0;
        finalItem = {
          ...editingItem,
          stock: currentStock + stockToAdd
        };
      }
      
      onUpdateItems(items.map(item => 
        item.id === editingItem.id ? finalItem : item
      ));
      setEditDialogOpen(false);
      setEditingItem(null);
      setStockToAdd(0);
    }
  };

  const handleDeleteItemClick = (id: string) => {
    if (isPasswordProtected()) {
      setPendingDeleteItemId(id);
      setShowItemPasswordDialog(true);
    } else {
      onUpdateItems(items.filter((item) => item.id !== id));
    }
  };

  const handleItemPasswordSuccess = () => {
    if (pendingDeleteItemId) {
      onUpdateItems(items.filter((item) => item.id !== pendingDeleteItemId));
      setPendingDeleteItemId(null);
    }
  };

  // Category handlers
  const handleAddCategory = () => {
    if (newCategory && !categories.includes(newCategory)) {
      onUpdateCategories([...categories, newCategory]);
      setNewCategory('');
      setCategoryDialogOpen(false);
    }
  };

  const handleDeleteCategoryClick = (category: string) => {
    if (isPasswordProtected()) {
      setPendingDeleteCategory(category);
      setShowCategoryPasswordDialog(true);
    } else {
      onUpdateCategories(categories.filter((cat) => cat !== category));
    }
  };

  const handleCategoryPasswordSuccess = () => {
    if (pendingDeleteCategory) {
      onUpdateCategories(categories.filter((cat) => cat !== pendingDeleteCategory));
      setPendingDeleteCategory(null);
    }
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Mobile Container */}
      <div className="flex-1 flex flex-col max-w-[600px] w-full mx-auto overflow-hidden">
        {/* Header */}
        <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-4 flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-3">
            <Button
              onClick={onBack}
              variant="ghost"
              size="icon"
              className="text-white hover:bg-[#49842B]/10"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-white font-semibold">Inventory Management</h1>
              <p className="text-sm text-white/80">
                {activeTab === 'items' ? `${items.length} items` : `${categories.length} categories`}
              </p>
            </div>
          </div>
          {activeTab === 'items' ? (
            <Dialog open={itemDialogOpen} onOpenChange={setItemDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" className="bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white rounded-full border-0">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Item
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-[#C1D95C] border-[#336A29]/15">
                <DialogHeader>
                  <DialogTitle className="text-[#336A29]">Add New Item</DialogTitle>
                  <DialogDescription className="text-[#336A29]/70">Add a new item to your menu.</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div>
                    <Label htmlFor="name" className="text-[#336A29]">Item Name</Label>
                    <Input
                      id="name"
                      value={newItem.name}
                      onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
                      placeholder="e.g. Masala Tea"
                      className="bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70 focus:border-[#49842B]"
                    />
                  </div>
                  <div>
                    <Label htmlFor="price" className="text-[#336A29]">Price</Label>
                    <Input
                      id="price"
                      type="number"
                      value={newItem.price || ''}
                      onChange={(e) => setNewItem({ ...newItem, price: Number(e.target.value) })}
                      placeholder="e.g. 15"
                      className="bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70 focus:border-[#49842B]"
                    />
                  </div>
                  <div>
                    <Label htmlFor="category" className="text-[#336A29]">Category</Label>
                    <Input
                      id="category"
                      value={newItem.category}
                      onChange={(e) => setNewItem({ ...newItem, category: e.target.value })}
                      placeholder="e.g. Tea"
                      list="categories"
                      className="bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70 focus:border-[#49842B]"
                    />
                    <datalist id="categories">
                      {categories.map((cat) => (
                        <option key={cat} value={cat} />
                      ))}
                    </datalist>
                  </div>
                  <div>
                    <Label htmlFor="stock" className="text-[#336A29]">Initial Stock (Optional)</Label>
                    <Input
                      id="stock"
                      type="number"
                      min="0"
                      value={newItem.stock ?? ''}
                      onChange={(e) => setNewItem({ ...newItem, stock: e.target.value ? Number(e.target.value) : undefined })}
                      placeholder="Leave empty for unlimited"
                      className="bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70 focus:border-[#49842B]"
                    />
                    <p className="text-xs text-[#336A29]/70 mt-1">Leave empty for unlimited stock, or enter quantity to track inventory</p>
                  </div>
                  <Button 
                    onClick={handleAddItem} 
                    className="w-full bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white border-0"
                  >
                    Add Item
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          ) : (
            <Dialog open={categoryDialogOpen} onOpenChange={setCategoryDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" className="bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white rounded-full border-0">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Category
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-[#C1D95C] border-[#336A29]/15">
                <DialogHeader>
                  <DialogTitle className="text-[#336A29]">Add New Category</DialogTitle>
                  <DialogDescription className="text-[#336A29]/70">Create a new category for your items.</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div>
                    <Label htmlFor="category-name" className="text-[#336A29]">Category Name</Label>
                    <Input
                      id="category-name"
                      value={newCategory}
                      onChange={(e) => setNewCategory(e.target.value)}
                      placeholder="e.g. Beverages"
                      className="bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70 focus:border-[#49842B]"
                    />
                  </div>
                  <Button 
                    onClick={handleAddCategory} 
                    className="w-full bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white border-0"
                  >
                    Add Category
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as 'items' | 'categories')} className="flex-1 flex flex-col">
          <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-6">
            <TabsList className="bg-transparent gap-2 h-auto p-0">
              <TabsTrigger 
                value="items" 
                className="data-[state=active]:bg-[#80B155] data-[state=active]:text-white text-[#336A29] rounded-t-lg border-b-2 border-transparent data-[state=active]:border-[#49842B] px-6 py-3"
              >
                <Package className="h-4 w-4 mr-2" />
                Items
              </TabsTrigger>
              <TabsTrigger 
                value="categories"
                className="data-[state=active]:bg-[#80B155] data-[state=active]:text-white text-[#336A29] rounded-t-lg border-b-2 border-transparent data-[state=active]:border-[#49842B] px-6 py-3"
              >
                <Tag className="h-4 w-4 mr-2" />
                Categories
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="items" className="flex-1 flex flex-col mt-0 overflow-hidden">
            {/* Search */}
            <div className="px-4 py-4 bg-[#C1D95C] border-b border-[#336A29]/15">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-[#336A29]/60" />
                <Input
                  type="text"
                  placeholder="Search items..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70 rounded-2xl focus:border-[#49842B]"
                />
              </div>
            </div>

            {/* Items List */}
            <div className="flex-1 overflow-auto bg-[#EAEF9D]">
              {filteredItems.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-64 text-[#336A29]/60">
                  <Package className="h-12 w-12 mb-3" />
                  <p className="text-[#336A29]">No items found</p>
                </div>
              ) : (
                <div className="p-4 space-y-3">
                  {filteredItems.map((item) => (
                    <div
                      key={item.id}
                      className="bg-[#C1D95C] rounded-2xl border border-[#336A29]/15 p-4 hover:bg-[#80B155] hover:border-[#49842B]/50 transition-all"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3">
                            <div className="w-12 h-12 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center shadow-lg">
                              <span className="text-white font-semibold text-lg">
                                {item.name.charAt(0).toUpperCase()}
                              </span>
                            </div>
                            <div>
                              <span className="text-[#336A29] font-medium text-lg block">{item.name}</span>
                              <div className="flex items-center gap-2">
                                <span className="text-[#336A29]/70 text-sm">Category: {item.category}</span>
                                {item.stock !== undefined && (
                                  <span 
                                    className={`text-xs px-2 py-0.5 rounded-full ${
                                      item.stock === 0 
                                        ? 'bg-red-500 text-white' 
                                        : item.stock <= 5 
                                        ? 'bg-orange-500 text-white' 
                                        : 'bg-green-600 text-white'
                                    }`}
                                  >
                                    Stock: {item.stock}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          <span className="text-lg font-semibold text-[#49842B]">₹{item.price}</span>
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleEditClick(item)}
                              className="text-[#49842B] hover:bg-[#49842B]/10 h-9 w-9 rounded-xl"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDeleteItemClick(item.id)}
                              className="text-[#FF8A65] hover:bg-[#FF8A65]/10 h-9 w-9 rounded-xl"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="categories" className="flex-1 mt-0 overflow-auto bg-[#EAEF9D]">
            {categories.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-64 text-[#336A29]/60">
                <Tag className="h-12 w-12 mb-3" />
                <p className="text-[#336A29]">No categories yet</p>
              </div>
            ) : (
              <div className="p-4 space-y-3">
                {categories.map((category) => (
                  <div
                    key={category}
                    className="bg-[#C1D95C] rounded-2xl border border-[#336A29]/15 p-4 hover:bg-[#80B155] hover:border-[#49842B]/50 transition-all"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center shadow-lg">
                          <Tag className="h-6 w-6 text-white" />
                        </div>
                        <span className="text-[#336A29] font-medium">{category}</span>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteCategoryClick(category)}
                        className="text-[#FF8A65] hover:bg-[#FF8A65]/10 h-9 w-9 rounded-xl"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Edit Item Dialog */}
        {editDialogOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center">
            {/* Backdrop */}
            <div 
              className="absolute inset-0 bg-black/50 z-40"
              onClick={() => setEditDialogOpen(false)}
            />
            
            {/* Dialog Content */}
            <div className="relative z-50 w-full max-w-lg mx-4 bg-[#C1D95C] rounded-2xl shadow-2xl border border-[#336A29]/15 max-h-[90vh] overflow-y-auto">
              {/* Header */}
              <div className="sticky top-0 bg-[#C1D95C] border-b border-[#336A29]/15 px-6 py-4 rounded-t-2xl">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-xl font-semibold text-[#336A29]">Edit Item</h2>
                    <p className="text-sm text-[#336A29]/70">Update item details and manage stock</p>
                  </div>
                  <button
                    onClick={() => setEditDialogOpen(false)}
                    className="text-[#336A29] hover:bg-[#336A29]/10 rounded-full p-2 transition-colors"
                  >
                    ✕
                  </button>
                </div>
              </div>

              {/* Form Content */}
              <div className="p-6 space-y-4">
                {/* Item Name */}
                <div>
                  <Label htmlFor="edit-name" className="text-[#336A29]">Item Name</Label>
                  <Input
                    id="edit-name"
                    value={editingItem?.name || ''}
                    onChange={(e) => setEditingItem(editingItem ? { ...editingItem, name: e.target.value } : null)}
                    placeholder="e.g. Masala Tea"
                    className="bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70 focus:border-[#49842B]"
                  />
                </div>

                {/* Price */}
                <div>
                  <Label htmlFor="edit-price" className="text-[#336A29]">Price</Label>
                  <Input
                    id="edit-price"
                    type="number"
                    value={editingItem?.price || ''}
                    onChange={(e) => setEditingItem(editingItem ? { ...editingItem, price: Number(e.target.value) } : null)}
                    placeholder="e.g. 15"
                    className="bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70 focus:border-[#49842B]"
                  />
                </div>

                {/* Category */}
                <div>
                  <Label htmlFor="edit-category" className="text-[#336A29]">Category</Label>
                  <Input
                    id="edit-category"
                    value={editingItem?.category || ''}
                    onChange={(e) => setEditingItem(editingItem ? { ...editingItem, category: e.target.value } : null)}
                    placeholder="e.g. Tea"
                    list="categories-edit"
                    className="bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70 focus:border-[#49842B]"
                  />
                  <datalist id="categories-edit">
                    {categories.map((cat) => (
                      <option key={cat} value={cat} />
                    ))}
                  </datalist>
                </div>
                
                {/* Stock Management Section */}
                <div className="border-t border-[#336A29]/20 pt-4 mt-6">
                  <Label className="text-[#336A29] mb-3 block font-semibold">Stock Management</Label>
                  
                  {/* Mode Toggle Buttons */}
                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <button
                      type="button"
                      onClick={() => setStockMode('add')}
                      className={`px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                        stockMode === 'add'
                          ? 'bg-gradient-to-r from-[#49842B] to-[#336A29] text-white shadow-lg scale-105'
                          : 'bg-[#80B155] text-white/70 hover:bg-[#80B155]/90'
                      }`}
                    >
                      ➕ Add Stock
                    </button>
                    <button
                      type="button"
                      onClick={() => setStockMode('set')}
                      className={`px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                        stockMode === 'set'
                          ? 'bg-gradient-to-r from-[#49842B] to-[#336A29] text-white shadow-lg scale-105'
                          : 'bg-[#80B155] text-white/70 hover:bg-[#80B155]/90'
                      }`}
                    >
                      📝 Set Stock
                    </button>
                  </div>
                  
                  {/* Add Stock Mode */}
                  {stockMode === 'add' && (
                    <div className="space-y-3">
                      <div className="bg-[#80B155]/40 rounded-lg p-4 border border-[#336A29]/20">
                        <p className="text-sm text-[#336A29]">
                          Current Stock: <span className="font-bold text-lg ml-2">{editingItem?.stock ?? 'Unlimited'}</span>
                        </p>
                      </div>
                      <div>
                        <Label htmlFor="stock-to-add" className="text-[#336A29] text-sm mb-1 block">Quantity to Add</Label>
                        <Input
                          id="stock-to-add"
                          type="number"
                          min="0"
                          value={stockToAdd || ''}
                          onChange={(e) => setStockToAdd(Number(e.target.value) || 0)}
                          placeholder="Enter quantity (e.g., 50)"
                          className="bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70 focus:border-[#49842B]"
                        />
                      </div>
                      {stockToAdd > 0 && (
                        <div className="bg-green-100 border-2 border-green-600 rounded-lg p-3">
                          <p className="text-sm text-green-800 font-semibold">
                            ✅ New stock will be: {(editingItem?.stock ?? 0) + stockToAdd}
                          </p>
                        </div>
                      )}
                      <p className="text-xs text-[#336A29]/70">Perfect for daily restocking operations</p>
                    </div>
                  )}

                  {/* Set Stock Mode */}
                  {stockMode === 'set' && (
                    <div className="space-y-3">
                      <div>
                        <Label htmlFor="edit-stock-set" className="text-[#336A29] text-sm mb-1 block">Set Exact Stock Level</Label>
                        <Input
                          id="edit-stock-set"
                          type="number"
                          min="0"
                          value={editingItem?.stock ?? ''}
                          onChange={(e) => setEditingItem(editingItem ? { ...editingItem, stock: e.target.value ? Number(e.target.value) : undefined } : null)}
                          placeholder="Leave empty for unlimited"
                          className="bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70 focus:border-[#49842B]"
                        />
                      </div>
                      <p className="text-xs text-[#336A29]/70">Set absolute stock value or leave empty for unlimited</p>
                    </div>
                  )}
                </div>
                
                {/* Action Buttons */}
                <div className="flex gap-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setEditDialogOpen(false)}
                    className="flex-1 px-4 py-3 rounded-lg border-2 border-[#336A29]/30 text-[#336A29] font-medium hover:bg-[#336A29]/10 transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleUpdateItem}
                    className="flex-1 px-4 py-3 rounded-lg bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white font-medium transition-all shadow-lg hover:shadow-xl"
                  >
                    Update Item
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Password Dialogs */}
        <PasswordDialog
          open={showItemPasswordDialog}
          onOpenChange={setShowItemPasswordDialog}
          onSuccess={handleItemPasswordSuccess}
          title="Delete Item - Admin Password Required"
          description="Enter admin password to delete this item"
        />
        <PasswordDialog
          open={showCategoryPasswordDialog}
          onOpenChange={setShowCategoryPasswordDialog}
          onSuccess={handleCategoryPasswordSuccess}
          title="Delete Category - Admin Password Required"
          description="Enter admin password to delete this category"
        />
      </div>
    </div>
  );
}