import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Lock, Eye, EyeOff, CheckCircle2, ChevronLeft } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { setPasswordHash, verifyPassword, getPasswordHash, isPasswordSet } from '../lib/auth';
import { useAuth } from '../lib/auth-context';

interface PasswordSetupProps {
  onBack: () => void;
}

export function PasswordSetup({ onBack }: PasswordSetupProps) {
  const [hasPassword, setHasPassword] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const { checkAuth } = useAuth();

  useEffect(() => {
    setHasPassword(isPasswordSet());
  }, []);

  const handleSetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSaving(true);

    try {
      // Validate if changing existing password
      if (hasPassword) {
        const hash = getPasswordHash();
        if (hash) {
          const isValid = await verifyPassword(currentPassword, hash);
          if (!isValid) {
            setError('Current password is incorrect');
            setIsSaving(false);
            return;
          }
        }
      }

      // Validate new password
      if (newPassword.length < 4) {
        setError('Password must be at least 4 characters');
        setIsSaving(false);
        return;
      }

      if (newPassword !== confirmPassword) {
        setError('Passwords do not match');
        setIsSaving(false);
        return;
      }

      // Save password hash
      await setPasswordHash(newPassword);
      
      setHasPassword(true);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      
      // Update auth context
      checkAuth();
      
      toast.success(hasPassword ? 'Password updated successfully' : 'Password set successfully');
    } catch (err) {
      console.error('Password setup error:', err);
      setError('Failed to save password. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleRemovePassword = async () => {
    setIsSaving(true);
    
    try {
      const hash = getPasswordHash();
      if (hash) {
        const isValid = await verifyPassword(currentPassword, hash);
        if (!isValid) {
          setError('Current password is incorrect');
          setIsSaving(false);
          return;
        }
      }

      // Remove password hash from all storage locations
      localStorage.removeItem('adminPasswordHash');
      sessionStorage.removeItem('adminPasswordHash');
      localStorage.removeItem('adminPassword'); // Legacy
      
      setHasPassword(false);
      setCurrentPassword('');
      
      // Update auth context
      checkAuth();
      
      toast.success('Password protection removed');
    } catch (err) {
      console.error('Password removal error:', err);
      setError('Failed to remove password. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-3 flex items-center shadow-lg">
        <Button onClick={onBack} variant="ghost" size="icon" className="text-white hover:bg-[#49842B]/10 -ml-2">
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="flex-1 text-center text-white font-semibold">Password Protection</h1>
        <div className="w-10"></div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-4">
        <Card className="bg-[#C1D95C] border-[#336A29]/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-[#336A29]">
              <Lock className="h-5 w-5" />
              Admin Password Protection
            </CardTitle>
            <CardDescription className="text-[#336A29]/70">
              {hasPassword
                ? 'Password protection is active. Employees cannot delete or edit bills without the password.'
                : 'Set a password to protect bills from being deleted or edited by employees.'}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {hasPassword && (
              <div className="flex items-center gap-2 p-3 bg-[#49842B]/10 border border-[#49842B]/30 rounded-lg">
                <CheckCircle2 className="h-5 w-5 text-[#49842B]" />
                <span className="text-sm text-[#336A29] font-medium">Password protection is enabled</span>
              </div>
            )}

            <form onSubmit={handleSetPassword} className="space-y-4">
              {hasPassword && (
                <div className="space-y-2">
                  <Label htmlFor="current-password" className="text-[#336A29]">Current Password</Label>
                  <Input
                    id="current-password"
                    type={showPassword ? 'text' : 'password'}
                    value={currentPassword}
                    onChange={(e) => {
                      setCurrentPassword(e.target.value);
                      setError('');
                    }}
                    placeholder="Enter current password"
                    className="bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                  />
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="new-password" className="text-[#336A29]">
                  {hasPassword ? 'New Password' : 'Password'}
                </Label>
                <div className="relative">
                  <Input
                    id="new-password"
                    type={showPassword ? 'text' : 'password'}
                    value={newPassword}
                    onChange={(e) => {
                      setNewPassword(e.target.value);
                      setError('');
                    }}
                    placeholder="Enter password (min. 4 characters)"
                    className="bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4 text-white/70" />
                    ) : (
                      <Eye className="h-4 w-4 text-white/70" />
                    )}
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirm-password" className="text-[#336A29]">Confirm Password</Label>
                <Input
                  id="confirm-password"
                  type={showPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => {
                    setConfirmPassword(e.target.value);
                    setError('');
                  }}
                  placeholder="Confirm password"
                  className="bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                />
              </div>

              {error && <p className="text-sm text-red-600">{error}</p>}

              <div className="flex gap-2">
                <Button
                  type="submit"
                  className="flex-1 bg-[#49842B] hover:bg-[#336A29]"
                  disabled={!newPassword || !confirmPassword || (hasPassword && !currentPassword) || isSaving}
                >
                  {hasPassword ? 'Update Password' : 'Set Password'}
                </Button>
                {hasPassword && (
                  <Button
                    type="button"
                    variant="destructive"
                    onClick={handleRemovePassword}
                    disabled={!currentPassword || isSaving}
                  >
                    Remove Password
                  </Button>
                )}
              </div>
            </form>

            <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-lg">
              <p className="text-sm text-amber-800">
                <strong>Note:</strong> Keep your password safe. If you forget it, you'll need to clear
                browser data to reset it.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}