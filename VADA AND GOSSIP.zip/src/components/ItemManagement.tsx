import { useState } from 'react';
import { MenuItem } from '../App';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ArrowLeft, Plus, Search, Edit, Trash2, Package } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';
import { Label } from './ui/label';
import { PasswordDialog } from './PasswordDialog';

interface ItemManagementProps {
  items: MenuItem[];
  categories: string[];
  onBack: () => void;
  onUpdate: (items: MenuItem[]) => void;
}

export function ItemManagement({ items, categories, onBack, onUpdate }: ItemManagementProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [newItem, setNewItem] = useState<MenuItem>({ id: '', name: '', price: 0, category: '' });
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);

  // Check if password protection is enabled
  const isPasswordProtected = () => {
    return !!localStorage.getItem('adminPassword');
  };

  const filteredItems = items.filter(
    (item) =>
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddItem = () => {
    if (newItem.name && newItem.price && newItem.category) {
      const newItemWithId: MenuItem = {
        id: Date.now().toString(),
        name: newItem.name,
        price: newItem.price,
        category: newItem.category,
      };
      onUpdate([...items, newItemWithId]);
      setNewItem({ id: '', name: '', price: 0, category: '' });
      setDialogOpen(false);
    }
  };

  const handleEditClick = (item: MenuItem) => {
    setEditingItem(item);
    setEditDialogOpen(true);
  };

  const handleUpdateItem = () => {
    if (editingItem) {
      onUpdate(items.map(item => 
        item.id === editingItem.id ? editingItem : item
      ));
      setEditDialogOpen(false);
      setEditingItem(null);
    }
  };

  const handleDeleteClick = (id: string) => {
    if (isPasswordProtected()) {
      setPendingDeleteId(id);
      setShowPasswordDialog(true);
    } else {
      onUpdate(items.filter((item) => item.id !== id));
    }
  };

  const handlePasswordSuccess = () => {
    if (pendingDeleteId) {
      onUpdate(items.filter((item) => item.id !== pendingDeleteId));
      setPendingDeleteId(null);
    }
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-6 py-4 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-3">
          <Button
            onClick={onBack}
            variant="ghost"
            size="icon"
            className="text-[#49842B] hover:bg-[#49842B]/10"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-[#336A29] font-semibold">Menu Items</h1>
            <p className="text-sm text-[#336A29]/70">{items.length} items</p>
          </div>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white rounded-full border-0">
              <Plus className="h-4 w-4 mr-2" />
              Add Item
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-[#C1D95C] border-[#336A29]/15">
            <DialogHeader>
              <DialogTitle className="text-[#336A29]">Add New Item</DialogTitle>
              <DialogDescription className="text-[#336A29]/70">Add a new item to your menu.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="name" className="text-[#336A29]">Item Name</Label>
                <Input
                  id="name"
                  value={newItem.name}
                  onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
                  placeholder="e.g. Masala Tea"
                  className="bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70 focus:border-[#49842B]"
                />
              </div>
              <div>
                <Label htmlFor="price" className="text-[#336A29]">Price</Label>
                <Input
                  id="price"
                  type="number"
                  value={newItem.price || ''}
                  onChange={(e) => setNewItem({ ...newItem, price: Number(e.target.value) })}
                  placeholder="e.g. 15"
                  className="bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70 focus:border-[#49842B]"
                />
              </div>
              <div>
                <Label htmlFor="category" className="text-[#336A29]">Category</Label>
                <Input
                  id="category"
                  value={newItem.category}
                  onChange={(e) => setNewItem({ ...newItem, category: e.target.value })}
                  placeholder="e.g. Tea"
                  list="categories"
                  className="bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70 focus:border-[#49842B]"
                />
                <datalist id="categories">
                  {categories.map((cat) => (
                    <option key={cat} value={cat} />
                  ))}
                </datalist>
              </div>
              <Button onClick={handleAddItem} className="w-full bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white border-0">
                Add Item
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <div className="px-4 py-4 bg-[#C1D95C] border-b border-[#336A29]/15">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-[#336A29]/60" />
          <Input
            type="text"
            placeholder="Search items..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70 rounded-2xl focus:border-[#49842B]"
          />
        </div>
      </div>

      {/* Items List */}
      <div className="flex-1 overflow-auto bg-[#EAEF9D]">
        {filteredItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-[#336A29]/60">
            <Package className="h-12 w-12 mb-3" />
            <p className="text-[#336A29]">No items found</p>
          </div>
        ) : (
          <div className="p-4 space-y-3">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                className="bg-[#C1D95C] rounded-2xl border border-[#336A29]/15 p-4 hover:bg-[#80B155] hover:border-[#49842B]/50 transition-all"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center shadow-lg">
                        <span className="text-white font-semibold text-lg">
                          {item.name.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <div>
                        <span className="text-[#336A29] font-medium text-lg">{item.name}</span>
                        <span className="text-[#336A29]/70 text-sm">Category: {item.category}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <span className="text-lg font-semibold text-[#49842B]">₹{item.price}</span>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEditClick(item)}
                        className="text-[#49842B] hover:bg-[#49842B]/10 h-9 w-9 rounded-xl"
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteClick(item.id)}
                        className="text-[#FF8A65] hover:bg-[#FF8A65]/10 h-9 w-9 rounded-xl"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="bg-[#C1D95C] border-[#336A29]/15">
          <DialogHeader>
            <DialogTitle className="text-[#336A29]">Edit Item</DialogTitle>
            <DialogDescription className="text-[#336A29]/70">Update item details.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="edit-name" className="text-[#336A29]">Item Name</Label>
              <Input
                id="edit-name"
                value={editingItem?.name || ''}
                onChange={(e) => setEditingItem(editingItem ? { ...editingItem, name: e.target.value } : null)}
                placeholder="e.g. Masala Tea"
                className="bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70 focus:border-[#49842B]"
              />
            </div>
            <div>
              <Label htmlFor="edit-price" className="text-[#336A29]">Price</Label>
              <Input
                id="edit-price"
                type="number"
                value={editingItem?.price || ''}
                onChange={(e) => setEditingItem(editingItem ? { ...editingItem, price: Number(e.target.value) } : null)}
                placeholder="e.g. 15"
                className="bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70 focus:border-[#49842B]"
              />
            </div>
            <div>
              <Label htmlFor="edit-category" className="text-[#336A29]">Category</Label>
              <Input
                id="edit-category"
                value={editingItem?.category || ''}
                onChange={(e) => setEditingItem(editingItem ? { ...editingItem, category: e.target.value } : null)}
                placeholder="e.g. Tea"
                list="categories-edit"
                className="bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70 focus:border-[#49842B]"
              />
              <datalist id="categories-edit">
                {categories.map((cat) => (
                  <option key={cat} value={cat} />
                ))}
              </datalist>
            </div>
            <Button onClick={handleUpdateItem} className="w-full bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white border-0">
              Update Item
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Password Dialog */}
      <PasswordDialog
        open={showPasswordDialog}
        onOpenChange={setShowPasswordDialog}
        onSuccess={handlePasswordSuccess}
        title="Delete Item - Admin Password Required"
        description="Enter admin password to delete this item"
      />
    </div>
  );
}