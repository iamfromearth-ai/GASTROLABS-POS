import { Button } from './ui/button';
import { ChevronLeft, Globe, Mail, Phone, ExternalLink, Shield, Zap, Users } from 'lucide-react';
import gastrolabsLogo from 'figma:asset/40e32a5289d65a2b6179706a1a6cf20239f14e08.png';

interface AboutGastrolabsProps {
  onBack: () => void;
}

export function AboutGastrolabs({ onBack }: AboutGastrolabsProps) {
  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-6 py-3 flex items-center gap-3 shadow-lg">
        <Button onClick={onBack} variant="ghost" size="icon" className="text-white hover:bg-[#49842B]/10">
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-white font-semibold">About Gastrolabs</h1>
      </div>

      <div className="flex-1 overflow-auto">
        {/* Gastrolabs Branding */}
        <div className="mt-4 mx-6 bg-gradient-to-br from-[#C1D95C] via-[#80B155] to-[#49842B] rounded-2xl p-8 text-center shadow-xl">
          <img src={gastrolabsLogo} alt="Gastrolabs" className="h-20 w-auto mx-auto mb-4" />
          <h2 className="text-white text-2xl font-bold mb-2">GASTROLABS</h2>
          <p className="text-white/90 text-sm">
            Enterprise Software for Food Service & Hospitality Industry
          </p>
        </div>

        {/* App Info */}
        <div className="mt-4 mx-6 bg-[#C1D95C] rounded-2xl p-4">
          <h3 className="text-[#336A29] font-semibold text-lg mb-3">Gastrolabs POS</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-[#336A29]/70">Version</span>
              <span className="text-[#336A29] font-medium">1.0.0</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#336A29]/70">Build</span>
              <span className="text-[#336A29] font-medium">2025.01</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#336A29]/70">Platform</span>
              <span className="text-[#336A29] font-medium">Web, iOS, Android</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#336A29]/70">License</span>
              <span className="text-[#336A29] font-medium">White-Label SaaS</span>
            </div>
          </div>
        </div>

        {/* Features */}
        <div className="mt-4 mx-6 bg-[#C1D95C] rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-[#336A29]/15">
            <h3 className="text-[#336A29] font-semibold">Platform Features</h3>
          </div>
          
          <div className="divide-y divide-[#336A29]/10">
            <div className="px-4 py-3 flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center">
                <Zap className="h-5 w-5 text-white" />
              </div>
              <div className="flex-1">
                <p className="text-[#336A29] font-medium">Fast POS Operations</p>
                <p className="text-xs text-[#336A29]/60">Quick billing & order management</p>
              </div>
            </div>

            <div className="px-4 py-3 flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center">
                <Shield className="h-5 w-5 text-white" />
              </div>
              <div className="flex-1">
                <p className="text-[#336A29] font-medium">White-Label Ready</p>
                <p className="text-xs text-[#336A29]/60">Fully customizable branding</p>
              </div>
            </div>

            <div className="px-4 py-3 flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center">
                <Users className="h-5 w-5 text-white" />
              </div>
              <div className="flex-1">
                <p className="text-[#336A29] font-medium">Global Food Industry</p>
                <p className="text-xs text-[#336A29]/60">Built for restaurants, cafes, QSR</p>
              </div>
            </div>
          </div>
        </div>

        {/* Company Info */}
        <div className="mt-4 mx-6 bg-[#C1D95C] rounded-2xl p-4">
          <h3 className="text-[#336A29] font-semibold mb-4">Company Information</h3>
          <div className="space-y-3">
            <a
              href="https://gastrolabs.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 p-3 rounded-xl bg-[#80B155]/30 hover:bg-[#80B155]/50 transition-colors"
            >
              <Globe className="h-5 w-5 text-[#49842B]" />
              <div className="flex-1">
                <p className="text-[#336A29] font-medium">Website</p>
                <p className="text-xs text-[#336A29]/60">www.gastrolabs.com</p>
              </div>
              <ExternalLink className="h-4 w-4 text-[#336A29]/40" />
            </a>

            <a
              href="mailto:support@gastrolabs.com"
              className="flex items-center gap-3 p-3 rounded-xl bg-[#80B155]/30 hover:bg-[#80B155]/50 transition-colors"
            >
              <Mail className="h-5 w-5 text-[#49842B]" />
              <div className="flex-1">
                <p className="text-[#336A29] font-medium">Email Support</p>
                <p className="text-xs text-[#336A29]/60">support@gastrolabs.com</p>
              </div>
              <ExternalLink className="h-4 w-4 text-[#336A29]/40" />
            </a>

            <a
              href="tel:+1234567890"
              className="flex items-center gap-3 p-3 rounded-xl bg-[#80B155]/30 hover:bg-[#80B155]/50 transition-colors"
            >
              <Phone className="h-5 w-5 text-[#49842B]" />
              <div className="flex-1">
                <p className="text-[#336A29] font-medium">Phone Support</p>
                <p className="text-xs text-[#336A29]/60">+1 (234) 567-890</p>
              </div>
              <ExternalLink className="h-4 w-4 text-[#336A29]/40" />
            </a>
          </div>
        </div>

        {/* Mission Statement */}
        <div className="mt-4 mx-6 bg-[#C1D95C] rounded-2xl p-4">
          <h3 className="text-[#336A29] font-semibold mb-3">Our Mission</h3>
          <p className="text-[#336A29]/80 text-sm leading-relaxed">
            Gastrolabs empowers food service businesses worldwide with innovative, 
            white-label software solutions. We believe every restaurant, cafe, and 
            food establishment deserves enterprise-grade technology that's affordable, 
            customizable, and easy to use.
          </p>
        </div>

        {/* Target Industries */}
        <div className="mt-4 mx-6 bg-[#C1D95C] rounded-2xl p-4">
          <h3 className="text-[#336A29] font-semibold mb-3">Industries We Serve</h3>
          <div className="grid grid-cols-2 gap-2">
            {[
              'Restaurants',
              'Cafes',
              'Tea Shops',
              'Coffee Shops',
              'Food Trucks',
              'Bakeries',
              'Quick Service',
              'Fine Dining',
              'Cloud Kitchens',
              'Catering',
              'Juice Bars',
              'Fast Food',
            ].map((industry) => (
              <div
                key={industry}
                className="bg-[#80B155]/30 rounded-lg px-3 py-2 text-center"
              >
                <p className="text-[#336A29] text-sm">{industry}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Legal Links */}
        <div className="mt-4 mx-6 bg-[#C1D95C] rounded-2xl overflow-hidden">
          <button className="w-full px-4 py-3 flex items-center justify-between border-b border-[#336A29]/15 hover:bg-[#80B155] transition-colors">
            <span className="text-[#336A29] font-medium">Terms of Service</span>
            <ExternalLink className="h-4 w-4 text-[#336A29]/60" />
          </button>
          <button className="w-full px-4 py-3 flex items-center justify-between border-b border-[#336A29]/15 hover:bg-[#80B155] transition-colors">
            <span className="text-[#336A29] font-medium">Privacy Policy</span>
            <ExternalLink className="h-4 w-4 text-[#336A29]/60" />
          </button>
          <button className="w-full px-4 py-3 flex items-center justify-between hover:bg-[#80B155] transition-colors">
            <span className="text-[#336A29] font-medium">White-Label License Agreement</span>
            <ExternalLink className="h-4 w-4 text-[#336A29]/60" />
          </button>
        </div>

        {/* Copyright */}
        <div className="mt-4 mb-6 mx-6 text-center">
          <p className="text-sm text-[#336A29]/60">
            © 2025 Gastrolabs. All rights reserved.
          </p>
          <p className="text-xs text-[#336A29]/50 mt-1">
            White-Label POS Platform for Food Service Industry
          </p>
        </div>
      </div>
    </div>
  );
}