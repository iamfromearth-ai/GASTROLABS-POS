import { useState } from 'react';
import { Button } from './ui/button';
import { ChevronLeft } from 'lucide-react';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Switch } from './ui/switch';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';

export interface DiscountConfig {
  enabled: boolean;
  type: 'percentage' | 'fixed';
  value: number;
  applyToTotal: boolean;
}

interface DiscountSettingsProps {
  onBack: () => void;
  settings: DiscountConfig;
  onUpdateSettings: (settings: DiscountConfig) => void;
}

export function DiscountSettings({ onBack, settings, onUpdateSettings }: DiscountSettingsProps) {
  const [config, setConfig] = useState<DiscountConfig>(settings);

  const updateConfig = (key: keyof DiscountConfig, value: any) => {
    const updated = { ...config, [key]: value };
    setConfig(updated);
    onUpdateSettings(updated);
  };

  const calculateDiscount = (subtotal: number) => {
    if (config.type === 'percentage') {
      return subtotal * (config.value / 100);
    }
    return config.value;
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-3 flex items-center gap-3 shadow-lg">
        <Button
          onClick={onBack}
          variant="ghost"
          size="icon"
          className="text-[#49842B] hover:bg-[#49842B]/10"
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-[#336A29] font-semibold">Discount Settings</h1>
      </div>

      <div className="flex-1 overflow-auto">
        {/* Enable Discount */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-[#336A29] font-medium">Enable Default Discount</div>
              <div className="text-sm text-[#336A29]/70">Apply discount to all bills</div>
            </div>
            <Switch
              checked={config.enabled}
              onCheckedChange={(checked) => updateConfig('enabled', checked)}
            />
          </div>
        </div>

        {config.enabled && (
          <>
            {/* Discount Type */}
            <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
              <Label className="text-[#336A29] mb-3 block font-semibold">Discount Type</Label>
              <RadioGroup
                value={config.type}
                onValueChange={(value) => updateConfig('type', value)}
                className="space-y-2"
              >
                <div className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg hover:bg-[#80B155] transition-colors">
                  <div>
                    <div className="text-[#336A29] font-medium">Percentage</div>
                    <div className="text-sm text-[#336A29]/70">% off the total</div>
                  </div>
                  <RadioGroupItem value="percentage" />
                </div>
                <div className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg hover:bg-[#80B155] transition-colors">
                  <div>
                    <div className="text-[#336A29] font-medium">Fixed Amount</div>
                    <div className="text-sm text-[#336A29]/70">Fixed rupees off</div>
                  </div>
                  <RadioGroupItem value="fixed" />
                </div>
              </RadioGroup>
            </div>

            {/* Discount Value */}
            <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
              <Label htmlFor="discount-value" className="text-[#336A29]">
                Discount {config.type === 'percentage' ? 'Percentage' : 'Amount'}
              </Label>
              <div className="flex items-center gap-2 mt-2">
                <Input
                  id="discount-value"
                  type="number"
                  step={config.type === 'percentage' ? '0.1' : '1'}
                  min="0"
                  max={config.type === 'percentage' ? '100' : undefined}
                  value={config.value}
                  onChange={(e) => updateConfig('value', parseFloat(e.target.value) || 0)}
                  className="flex-1 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                />
                <span className="text-[#336A29] font-medium">
                  {config.type === 'percentage' ? '%' : 'Rs'}
                </span>
              </div>
              <p className="text-xs text-[#336A29]/70 mt-2">
                {config.type === 'percentage' 
                  ? 'Enter percentage (0-100)'
                  : 'Enter amount in rupees'
                }
              </p>
            </div>

            {/* Apply Settings */}
            <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[#336A29] font-medium">Apply to Total</div>
                  <div className="text-sm text-[#336A29]/70">Apply after taxes</div>
                </div>
                <Switch
                  checked={config.applyToTotal}
                  onCheckedChange={(checked) => updateConfig('applyToTotal', checked)}
                />
              </div>
            </div>

            {/* Preview */}
            <div className="mt-4 mb-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
              <Label className="text-[#336A29] mb-3 block font-semibold">Preview (on Rs 100 subtotal)</Label>
              <div className="border border-[#336A29]/20 rounded-lg p-4 bg-[#80B155]/30 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-[#336A29]/70">Subtotal</span>
                  <span className="text-[#336A29]">Rs 100.00</span>
                </div>
                
                <div className="flex justify-between text-sm text-[#49842B]">
                  <span>
                    Discount {config.type === 'percentage' ? `(${config.value}%)` : ''}
                  </span>
                  <span>- Rs {calculateDiscount(100).toFixed(2)}</span>
                </div>
                
                <div className="border-t border-[#336A29]/30 pt-2 flex justify-between">
                  <span className="text-[#336A29] font-semibold">Total</span>
                  <span className="text-[#336A29] font-semibold">
                    Rs {(100 - calculateDiscount(100)).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          </>
        )}

        {/* Info */}
        <div className="mt-4 mb-4 bg-[#49842B]/10 border border-[#49842B]/30 p-4 mx-4 rounded-lg">
          <p className="text-sm text-[#336A29]">
            💡 This sets a default discount. You can still manually adjust discounts per transaction.
          </p>
        </div>
      </div>
    </div>
  );
}