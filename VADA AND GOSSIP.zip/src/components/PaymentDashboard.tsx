import { Order } from '../App';
import { AlertCircle, CheckCircle, QrCode, Scan } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';

interface PaymentDashboardProps {
  orders: Order[];
  onMarkAsPaid: (orderId: string) => void;
  onViewHistory: () => void;
}

export function PaymentDashboard({ orders, onMarkAsPaid, onViewHistory }: PaymentDashboardProps) {
  const [scanDialogOpen, setScanDialogOpen] = useState(false);
  const [orderIdInput, setOrderIdInput] = useState('');

  const unpaidOrders = orders.filter((o) => o.status === 'active');
  const paidOrders = orders.filter((o) => o.status === 'paid');
  const unpaidTotal = unpaidOrders.reduce((sum, o) => sum + o.total, 0);

  const handleQuickPay = () => {
    if (orderIdInput) {
      const order = unpaidOrders.find((o) => o.id === orderIdInput || o.id.endsWith(orderIdInput));
      if (order) {
        onMarkAsPaid(order.id);
        setOrderIdInput('');
        setScanDialogOpen(false);
      }
    }
  };

  return (
    <>
      <div className="p-4 space-y-3">
        {/* Unpaid Bills Alert */}
        {unpaidOrders.length > 0 && (
          <Card className="border-red-200 bg-red-50">
            <div className="p-4">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <AlertCircle className="h-5 w-5 text-red-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="text-red-900">Unpaid Bills</h3>
                    <Badge variant="destructive" className="bg-red-600">
                      {unpaidOrders.length}
                    </Badge>
                  </div>
                  <p className="text-sm text-red-700 mb-2">
                    Total Outstanding: Rs {unpaidTotal}
                  </p>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      onClick={() => setScanDialogOpen(true)}
                      className="bg-red-600 hover:bg-red-700 h-8"
                    >
                      <Scan className="h-4 w-4 mr-1" />
                      Quick Pay
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={onViewHistory}
                      className="border-red-300 text-red-700 hover:bg-red-100 h-8"
                    >
                      View All
                    </Button>
                  </div>
                </div>
              </div>

              {/* Recent Unpaid Bills */}
              <div className="mt-3 pt-3 border-t border-red-200">
                <div className="text-xs text-red-700 mb-2">Recent Unpaid:</div>
                <div className="space-y-2">
                  {unpaidOrders.slice(0, 3).map((order) => (
                    <div
                      key={order.id}
                      className="flex items-center justify-between bg-white rounded-lg p-2 border border-red-200"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="text-xs text-neutral-600 mb-0.5">
                          #{order.id.slice(-6)}
                        </div>
                        <div className="text-sm text-neutral-900">
                          Rs {order.total}
                        </div>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => onMarkAsPaid(order.id)}
                        className="bg-green-600 hover:bg-green-700 h-7 text-xs"
                      >
                        Mark Paid
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Paid Bills Summary */}
        <Card className="border-green-200 bg-green-50">
          <div className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle className="h-5 w-5 text-green-600" />
              </div>
              <div className="flex-1">
                <h3 className="text-green-900">Paid Bills Today</h3>
                <div className="flex items-center gap-3 mt-1">
                  <Badge variant="secondary" className="bg-green-100 text-green-700">
                    {paidOrders.filter((o) => {
                      const today = new Date();
                      const orderDate = new Date(o.timestamp);
                      return (
                        orderDate.getDate() === today.getDate() &&
                        orderDate.getMonth() === today.getMonth() &&
                        orderDate.getFullYear() === today.getFullYear()
                      );
                    }).length}{' '}
                    bills
                  </Badge>
                  <span className="text-sm text-green-700">
                    Rs{' '}
                    {paidOrders
                      .filter((o) => {
                        const today = new Date();
                        const orderDate = new Date(o.timestamp);
                        return (
                          orderDate.getDate() === today.getDate() &&
                          orderDate.getMonth() === today.getMonth() &&
                          orderDate.getFullYear() === today.getFullYear()
                        );
                      })
                      .reduce((sum, o) => sum + o.total, 0)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* QR Code Info */}
        <Card className="border-blue-200 bg-blue-50">
          <div className="p-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <QrCode className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <h3 className="text-blue-900 mb-1">QR Code Tracking</h3>
                <p className="text-xs text-blue-700">
                  Each bill includes a QR code with order ID. Scan or enter the ID to quickly mark
                  bills as paid and track payments.
                </p>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Quick Pay Dialog */}
      <Dialog open={scanDialogOpen} onOpenChange={setScanDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Quick Payment Entry</DialogTitle>
            <DialogDescription>
              Enter the Order ID from the bill's QR code to mark it as paid
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <label className="text-sm text-neutral-700 mb-2 block">Order ID</label>
              <Input
                placeholder="Enter order ID (e.g., 123456 or full ID)"
                value={orderIdInput}
                onChange={(e) => setOrderIdInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    handleQuickPay();
                  }
                }}
              />
              <p className="text-xs text-neutral-500 mt-1">
                You can enter the last 6 digits or full order ID
              </p>
            </div>

            {orderIdInput && (
              <div className="bg-neutral-50 rounded-lg p-3">
                <div className="text-xs text-neutral-600 mb-1">Matching Order:</div>
                {unpaidOrders.find(
                  (o) => o.id === orderIdInput || o.id.endsWith(orderIdInput)
                ) ? (
                  <div className="text-sm text-neutral-900">
                    Order #
                    {unpaidOrders
                      .find((o) => o.id === orderIdInput || o.id.endsWith(orderIdInput))
                      ?.id.slice(-6)}{' '}
                    - Rs{' '}
                    {
                      unpaidOrders.find((o) => o.id === orderIdInput || o.id.endsWith(orderIdInput))
                        ?.total
                    }
                  </div>
                ) : (
                  <div className="text-sm text-red-600">No matching unpaid order found</div>
                )}
              </div>
            )}

            <Button
              onClick={handleQuickPay}
              className="w-full bg-green-600 hover:bg-green-700"
              disabled={
                !orderIdInput ||
                !unpaidOrders.find((o) => o.id === orderIdInput || o.id.endsWith(orderIdInput))
              }
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              Mark as Paid
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
