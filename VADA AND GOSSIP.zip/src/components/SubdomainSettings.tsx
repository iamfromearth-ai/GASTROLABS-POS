import { Button } from './ui/button';
import { ChevronLeft, Globe, ExternalLink, AlertCircle } from 'lucide-react';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { useState, useEffect } from 'react';
import { toast } from 'sonner@2.0.3';
import { supabase, getCurrentTenant, isSupabaseConfigured } from '../lib/supabase';

interface SubdomainSettingsProps {
  onBack: () => void;
}

export function SubdomainSettings({ onBack }: SubdomainSettingsProps) {
  const [subdomain, setSubdomain] = useState('');
  const [customDomain, setCustomDomain] = useState('');
  const [currentSubdomain, setCurrentSubdomain] = useState('');
  const [tier, setTier] = useState<'free' | 'pro' | 'enterprise'>('free');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isSupabaseConfigured()) {
      loadSettings();
    }
  }, []);

  const loadSettings = async () => {
    const tenant = await getCurrentTenant();
    if (tenant) {
      setCurrentSubdomain(tenant.subdomain);
      setSubdomain(tenant.subdomain);
      setCustomDomain(tenant.custom_domain || '');
      setTier(tenant.subscription_tier);
    }
  };

  const validateSubdomain = (value: string): boolean => {
    // Subdomain must be lowercase alphanumeric with hyphens
    const regex = /^[a-z0-9-]+$/;
    return regex.test(value) && value.length >= 3 && value.length <= 30;
  };

  const validateCustomDomain = (value: string): boolean => {
    // Basic domain validation
    const regex = /^[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,}$/;
    return regex.test(value);
  };

  const handleSaveSubdomain = async () => {
    if (!validateSubdomain(subdomain)) {
      toast.error('Invalid subdomain. Use only lowercase letters, numbers, and hyphens.');
      return;
    }

    setLoading(true);

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error('Not authenticated');
      setLoading(false);
      return;
    }

    // Check if subdomain is available
    const { data: existing } = await supabase
      .from('tenants')
      .select('id')
      .eq('subdomain', subdomain)
      .neq('id', user.id)
      .single();

    if (existing) {
      toast.error('Subdomain already taken. Please choose another.');
      setLoading(false);
      return;
    }

    // Update subdomain
    const { error } = await supabase
      .from('tenants')
      .update({ subdomain })
      .eq('id', user.id);

    if (error) {
      toast.error('Failed to update subdomain');
    } else {
      setCurrentSubdomain(subdomain);
      toast.success('Subdomain updated successfully!');
    }

    setLoading(false);
  };

  const handleSaveCustomDomain = async () => {
    if (tier !== 'enterprise') {
      toast.error('Custom domains are only available on Enterprise plan');
      return;
    }

    if (!validateCustomDomain(customDomain)) {
      toast.error('Invalid domain format');
      return;
    }

    setLoading(true);

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error('Not authenticated');
      setLoading(false);
      return;
    }

    const { error } = await supabase
      .from('tenants')
      .update({ custom_domain: customDomain })
      .eq('id', user.id);

    if (error) {
      toast.error('Failed to update custom domain');
    } else {
      toast.success('Custom domain saved! Please configure DNS settings.');
    }

    setLoading(false);
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-6 py-3 flex items-center gap-3 shadow-lg">
        <Button onClick={onBack} variant="ghost" size="icon" className="text-[#49842B] hover:bg-[#49842B]/10">
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <div className="flex-1">
          <h1 className="text-[#336A29] font-semibold">Domain Settings</h1>
          <p className="text-xs text-[#336A29]/70">Configure your custom URL</p>
        </div>
      </div>

      <div className="flex-1 overflow-auto pb-6">
        {/* Current URL */}
        {currentSubdomain && (
          <div className="mt-4 mx-6 bg-[#C1D95C] rounded-2xl p-4">
            <div className="flex items-center gap-3">
              <Globe className="h-5 w-5 text-[#49842B]" />
              <div className="flex-1">
                <p className="text-sm text-[#336A29]/70">Your POS is accessible at:</p>
                <a
                  href={`https://${currentSubdomain}.gastrolabs.com`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#49842B] font-medium hover:underline flex items-center gap-1"
                >
                  {currentSubdomain}.gastrolabs.com
                  <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>
          </div>
        )}

        {/* Subdomain Settings */}
        <div className="mt-4 mx-6 bg-[#C1D95C] rounded-2xl p-4">
          <h3 className="text-[#336A29] font-semibold mb-4">Gastrolabs Subdomain</h3>

          <div className="space-y-4">
            <div>
              <Label htmlFor="subdomain" className="text-[#336A29]">Subdomain *</Label>
              <div className="flex gap-2 mt-2">
                <Input
                  id="subdomain"
                  value={subdomain}
                  onChange={(e) => setSubdomain(e.target.value.toLowerCase())}
                  placeholder="mycafe"
                  className="bg-[#80B155] border-[#336A29]/20 text-[#336A29] rounded-xl flex-1"
                />
                <div className="flex items-center px-3 bg-[#80B155]/50 border border-[#336A29]/20 rounded-xl text-[#336A29] text-sm whitespace-nowrap">
                  .gastrolabs.com
                </div>
              </div>
              <p className="text-xs text-[#336A29]/60 mt-1">
                Use lowercase letters, numbers, and hyphens (3-30 characters)
              </p>
            </div>

            <Button
              onClick={handleSaveSubdomain}
              className="w-full bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white rounded-full"
              disabled={loading || subdomain === currentSubdomain}
            >
              Save Subdomain
            </Button>
          </div>
        </div>

        {/* Custom Domain (Enterprise Only) */}
        <div className="mt-4 mx-6 bg-[#C1D95C] rounded-2xl p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-[#336A29] font-semibold">Custom Domain</h3>
            {tier !== 'enterprise' && (
              <span className="text-xs bg-amber-500 text-white px-2 py-1 rounded-full">
                Enterprise Only
              </span>
            )}
          </div>

          {tier === 'enterprise' ? (
            <div className="space-y-4">
              <div>
                <Label htmlFor="custom-domain" className="text-[#336A29]">Your Domain</Label>
                <Input
                  id="custom-domain"
                  value={customDomain}
                  onChange={(e) => setCustomDomain(e.target.value.toLowerCase())}
                  placeholder="pos.yourbusiness.com"
                  className="bg-[#80B155] border-[#336A29]/20 text-[#336A29] rounded-xl mt-2"
                  disabled={tier !== 'enterprise'}
                />
                <p className="text-xs text-[#336A29]/60 mt-1">
                  Use your own domain for complete white-label experience
                </p>
              </div>

              <Button
                onClick={handleSaveCustomDomain}
                className="w-full bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white rounded-full"
                disabled={loading}
              >
                Save Custom Domain
              </Button>

              {/* DNS Instructions */}
              <div className="bg-[#80B155]/30 border border-[#336A29]/20 rounded-xl p-3">
                <p className="text-xs font-medium text-[#336A29] mb-2">📝 DNS Configuration Required:</p>
                <div className="space-y-1 text-xs text-[#336A29]/80">
                  <p>1. Add CNAME record: <code className="bg-[#336A29]/10 px-1 rounded">pos.yourbusiness.com</code></p>
                  <p>2. Point to: <code className="bg-[#336A29]/10 px-1 rounded">proxy.gastrolabs.com</code></p>
                  <p>3. Wait 24-48 hours for DNS propagation</p>
                  <p>4. SSL certificate will be auto-generated</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-[#80B155]/30 border border-[#336A29]/20 rounded-xl p-4 text-center">
              <AlertCircle className="h-8 w-8 text-[#336A29]/50 mx-auto mb-2" />
              <p className="text-sm text-[#336A29] mb-2">
                Custom domains are available on Enterprise plan
              </p>
              <Button
                variant="outline"
                size="sm"
                className="border-[#49842B] text-[#49842B]"
              >
                Upgrade to Enterprise
              </Button>
            </div>
          )}
        </div>

        {/* White-Label Info */}
        <div className="mt-4 mx-6 bg-[#C1D95C] rounded-2xl p-4">
          <h3 className="text-[#336A29] font-semibold mb-3">🎨 White-Label Features</h3>
          <div className="space-y-2 text-sm text-[#336A29]/80">
            <p>✅ Custom subdomain (all plans)</p>
            <p>✅ Custom business name and logo</p>
            <p>✅ Custom brand colors (Pro+)</p>
            <p>✅ Remove Gastrolabs watermark (Pro+)</p>
            <p>✅ Custom domain (Enterprise)</p>
            <p>✅ Export branded app build (Enterprise)</p>
          </div>
        </div>
      </div>
    </div>
  );
}