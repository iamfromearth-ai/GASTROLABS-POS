import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Lock, Eye, EyeOff } from 'lucide-react';
import { useAuth } from '../lib/auth-context';

interface PasswordDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
  title?: string;
  description?: string;
  dismissible?: boolean; // Allow dismissing the dialog (false for global protection)
}

export function PasswordDialog({
  open,
  onOpenChange,
  onSuccess,
  title = 'Admin Password Required',
  description = 'Enter the admin password to continue',
  dismissible = true,
}: PasswordDialogProps) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const { authenticate, isPasswordConfigured } = useAuth();

  // Reset error when dialog opens
  useEffect(() => {
    if (open) {
      setPassword('');
      setError('');
      setShowPassword(false);
      setIsVerifying(false);
      
      // Mobile: Prevent body scroll when dialog is open
      document.body.style.overflow = 'hidden';
      document.body.style.position = 'fixed';
      document.body.style.width = '100%';
      
      // Focus input after a short delay for mobile
      setTimeout(() => {
        const input = document.querySelector('#password-input') as HTMLInputElement;
        if (input) {
          input.focus();
          // On mobile, open keyboard
          input.click();
        }
      }, 300);
    } else {
      // Restore body scroll
      document.body.style.overflow = '';
      document.body.style.position = '';
      document.body.style.width = '';
    }
    
    return () => {
      document.body.style.overflow = '';
      document.body.style.position = '';
      document.body.style.width = '';
    };
  }, [open]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!isPasswordConfigured) {
      setError('No admin password set. Please set one in Settings.');
      return;
    }

    if (!password.trim()) {
      setError('Please enter a password');
      return;
    }

    setIsVerifying(true);
    setError('');

    try {
      const isValid = await authenticate(password);
      
      if (isValid) {
        setPassword('');
        setError('');
        onSuccess();
        onOpenChange(false);
      } else {
        setError('Incorrect password');
        setPassword('');
        // Re-focus on input after error
        setTimeout(() => {
          const input = document.querySelector('#password-input') as HTMLInputElement;
          if (input) input.focus();
        }, 100);
      }
    } catch (error) {
      console.error('Password verification error:', error);
      setError('An error occurred. Please try again.');
      setPassword('');
    } finally {
      setIsVerifying(false);
    }
  };

  const handleCancel = (e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    
    // Only allow canceling if dismissible
    if (!dismissible) {
      return;
    }
    
    setPassword('');
    setError('');
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={dismissible ? onOpenChange : undefined} modal={true}>
      <DialogContent 
        className="sm:max-w-md w-[95vw] max-w-[400px] bg-[#C1D95C] border-2 border-[#336A29]/30 shadow-2xl z-[99999] fixed"
        onPointerDownOutside={(e) => e.preventDefault()}
        onInteractOutside={(e) => e.preventDefault()}
        onEscapeKeyDown={(e) => {
          e.preventDefault();
          if (dismissible) {
            handleCancel();
          }
        }}
      >
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-[#336A29] text-xl">
            <Lock className="h-6 w-6 text-[#49842B]" />
            {title}
          </DialogTitle>
          <DialogDescription className="text-[#336A29]/70 text-base">
            {description}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} onTouchEnd={(e) => e.stopPropagation()}>
          <div className="space-y-4 py-4">
            {error && (
              <div className="bg-red-500/10 border-2 border-red-500/30 rounded-lg p-3 animate-pulse">
                <p className="text-sm text-red-600 font-medium">{error}</p>
              </div>
            )}
            <div>
              <Label htmlFor="password-input" className="text-[#336A29] font-medium text-base">Password</Label>
              <div className="relative mt-2">
                <Input
                  id="password-input"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onTouchStart={(e) => e.stopPropagation()}
                  placeholder="Enter password"
                  autoFocus
                  autoComplete="off"
                  className="bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70 focus:border-[#49842B] h-14 text-lg pr-12"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-2 top-1/2 -translate-y-1/2 h-10 w-10 p-0 hover:bg-[#49842B]/20"
                  onClick={() => setShowPassword(!showPassword)}
                  onTouchEnd={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setShowPassword(!showPassword);
                  }}
                >
                  {showPassword ? (
                    <EyeOff className="h-5 w-5 text-white/70" />
                  ) : (
                    <Eye className="h-5 w-5 text-white/70" />
                  )}
                </Button>
              </div>
            </div>
          </div>
          <DialogFooter className="gap-2 sm:gap-2">
            {dismissible && (
              <Button 
                type="button" 
                variant="outline" 
                onClick={handleCancel}
                onTouchEnd={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  handleCancel();
                }}
                className="bg-[#80B155] text-white border-[#336A29]/20 hover:bg-[#49842B] h-12 text-base flex-1 sm:flex-none"
              >
                Cancel
              </Button>
            )}
            <Button 
              type="submit"
              onTouchEnd={(e) => {
                e.preventDefault();
                e.stopPropagation();
                handleSubmit(e as any);
              }}
              className="bg-gradient-to-r from-[#FF8A65] to-[#FF7043] hover:from-[#FF7043] hover:to-[#FF8A65] text-white border-0 h-12 text-base flex-1 sm:flex-none"
            >
              {isVerifying ? 'Verifying...' : 'Verify'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}