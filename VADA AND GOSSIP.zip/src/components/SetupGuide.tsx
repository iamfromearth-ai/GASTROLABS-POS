import { Button } from './ui/button';
import { ChevronLeft, AlertCircle, CheckCircle2, ExternalLink } from 'lucide-react';

interface SetupGuideProps {
  onBack: () => void;
}

// Safely check for environment variables
const getEnvVar = (key: string): string => {
  try {
    if (typeof import.meta !== 'undefined' && import.meta.env) {
      return import.meta.env[key] || '';
    }
    if (typeof process !== 'undefined' && process.env) {
      return process.env[key] || '';
    }
  } catch (error) {
    // Silently fail
  }
  return '';
};

export function SetupGuide({ onBack }: SetupGuideProps) {
  const hasSupabase = !!getEnvVar('VITE_SUPABASE_URL');
  const hasStripe = !!getEnvVar('VITE_STRIPE_PUBLISHABLE_KEY');

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-6 py-3 flex items-center gap-3 shadow-lg">
        <Button onClick={onBack} variant="ghost" size="icon" className="text-[#49842B] hover:bg-[#49842B]/10">
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <div className="flex-1">
          <h1 className="text-[#336A29] font-semibold">Setup Guide</h1>
          <p className="text-xs text-[#336A29]/70">Configure enhanced features</p>
        </div>
      </div>

      <div className="flex-1 overflow-auto pb-6">
        {/* Current Status */}
        <div className="mt-4 mx-6 bg-[#C1D95C] rounded-2xl p-4">
          <h3 className="text-[#336A29] font-semibold mb-3">Configuration Status</h3>
          
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              {hasSupabase ? (
                <CheckCircle2 className="h-5 w-5 text-green-600" />
              ) : (
                <AlertCircle className="h-5 w-5 text-amber-600" />
              )}
              <div className="flex-1">
                <p className="text-sm font-medium text-[#336A29]">Supabase Backend</p>
                <p className="text-xs text-[#336A29]/70">
                  {hasSupabase ? 'Configured ✓' : 'Not configured - Features limited'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {hasStripe ? (
                <CheckCircle2 className="h-5 w-5 text-green-600" />
              ) : (
                <AlertCircle className="h-5 w-5 text-amber-600" />
              )}
              <div className="flex-1">
                <p className="text-sm font-medium text-[#336A29]">Stripe Payments</p>
                <p className="text-xs text-[#336A29]/70">
                  {hasStripe ? 'Configured ✓' : 'Not configured - Subscriptions disabled'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Features Available Without Setup */}
        <div className="mt-4 mx-6 bg-gradient-to-r from-[#C1D95C] to-[#80B155] rounded-2xl p-4 border-2 border-[#49842B]/30">
          <h3 className="text-[#336A29] font-semibold mb-3">✅ Working Now (No Setup Required)</h3>
          <div className="space-y-2 text-sm text-[#336A29]/80">
            <p>✓ Complete POS system with item management</p>
            <p>✓ Order tracking and history</p>
            <p>✓ Receipt printing with thermal printer support</p>
            <p>✓ QR code payment tracking</p>
            <p>✓ Business branding customization</p>
            <p>✓ Tax, discount, and fees configuration</p>
            <p>✓ Statistics and analytics</p>
            <p>✓ Offline-first functionality</p>
          </div>
        </div>

        {/* Enhanced Features Requiring Setup */}
        <div className="mt-4 mx-6 bg-[#C1D95C] rounded-2xl p-4">
          <h3 className="text-[#336A29] font-semibold mb-3">🔐 Enhanced Features (Requires Setup)</h3>
          <div className="space-y-2 text-sm text-[#336A29]/80">
            <p>🔒 Fraud-proof billing with database storage</p>
            <p>🔒 Complete audit logging</p>
            <p>🔒 Multi-device sync</p>
            <p>🔒 Subscription management (Free/Pro/Enterprise)</p>
            <p>🔒 Custom subdomain (yourshop.gastrolabs.com)</p>
            <p>🔒 Custom domain (Enterprise plan)</p>
            <p>🔒 Daily settlement reports</p>
          </div>
        </div>

        {/* Supabase Setup Instructions */}
        <div className="mt-4 mx-6 bg-[#C1D95C] rounded-2xl p-4">
          <h3 className="text-[#336A29] font-semibold mb-3">📝 Step 1: Setup Supabase (Backend)</h3>
          
          <div className="space-y-3 text-sm text-[#336A29]">
            <div>
              <p className="font-medium mb-1">1. Create Supabase Project</p>
              <a 
                href="https://supabase.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-[#49842B] hover:underline flex items-center gap-1"
              >
                Visit Supabase.com
                <ExternalLink className="h-3 w-3" />
              </a>
            </div>

            <div>
              <p className="font-medium mb-1">2. Get Your Credentials</p>
              <p className="text-xs text-[#336A29]/70">
                Project Settings → API → Copy URL and anon key
              </p>
            </div>

            <div>
              <p className="font-medium mb-1">3. Add Environment Variables</p>
              <div className="bg-[#80B155]/30 rounded-lg p-2 mt-1">
                <code className="text-xs text-[#336A29] block">
                  VITE_SUPABASE_URL=your_supabase_url
                </code>
                <code className="text-xs text-[#336A29] block">
                  VITE_SUPABASE_ANON_KEY=your_anon_key
                </code>
              </div>
            </div>

            <div>
              <p className="font-medium mb-1">4. Run Database Migration</p>
              <p className="text-xs text-[#336A29]/70">
                See TECHNICAL_DOCUMENTATION.md for SQL schema
              </p>
            </div>
          </div>
        </div>

        {/* Stripe Setup Instructions */}
        <div className="mt-4 mx-6 bg-[#C1D95C] rounded-2xl p-4">
          <h3 className="text-[#336A29] font-semibold mb-3">💳 Step 2: Setup Stripe (Subscriptions)</h3>
          
          <div className="space-y-3 text-sm text-[#336A29]">
            <div>
              <p className="font-medium mb-1">1. Create Stripe Account</p>
              <a 
                href="https://stripe.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-[#49842B] hover:underline flex items-center gap-1"
              >
                Visit Stripe.com
                <ExternalLink className="h-3 w-3" />
              </a>
            </div>

            <div>
              <p className="font-medium mb-1">2. Create Subscription Products</p>
              <p className="text-xs text-[#336A29]/70">
                Products → Create product for Pro ($29/mo) and Enterprise ($99/mo)
              </p>
            </div>

            <div>
              <p className="font-medium mb-1">3. Add Environment Variables</p>
              <div className="bg-[#80B155]/30 rounded-lg p-2 mt-1">
                <code className="text-xs text-[#336A29] block">
                  VITE_STRIPE_PUBLISHABLE_KEY=pk_xxx
                </code>
                <code className="text-xs text-[#336A29] block">
                  VITE_STRIPE_PRO_MONTHLY_PRICE_ID=price_xxx
                </code>
                <code className="text-xs text-[#336A29] block">
                  VITE_STRIPE_ENTERPRISE_MONTHLY_PRICE_ID=price_xxx
                </code>
              </div>
            </div>
          </div>
        </div>

        {/* Demo Mode Notice */}
        <div className="mt-4 mx-6 bg-amber-50 border-2 border-amber-500 rounded-2xl p-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-amber-900 mb-1">Running in Demo Mode</h3>
              <p className="text-sm text-amber-800">
                The app is fully functional without Supabase/Stripe, but enhanced features 
                (subscriptions, audit logs, multi-device sync) require backend setup.
              </p>
            </div>
          </div>
        </div>

        {/* Documentation Link */}
        <div className="mt-4 mx-6 bg-[#C1D95C] rounded-2xl p-4 text-center">
          <p className="text-[#336A29] font-medium mb-2">📚 Complete Setup Documentation</p>
          <p className="text-sm text-[#336A29]/70 mb-3">
            See TECHNICAL_DOCUMENTATION.md for detailed setup instructions, database schema, and API endpoints.
          </p>
          <Button
            variant="outline"
            className="border-[#49842B] text-[#49842B] hover:bg-[#49842B]/10"
          >
            View Documentation
          </Button>
        </div>
      </div>
    </div>
  );
}