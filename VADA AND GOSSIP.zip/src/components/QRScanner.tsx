import { useEffect, useRef, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Button } from './ui/button';
import { X, Camera, AlertCircle, ScanLine } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import jsQR from 'jsqr';

interface QRScannerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onScan: (data: string) => void;
  startWithCamera?: boolean;
}

export function QRScanner({ open, onOpenChange, onScan }: QRScannerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [cameraError, setCameraError] = useState('');
  const [cameraReady, setCameraReady] = useState(false);

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    setIsScanning(false);
    setCameraReady(false);
  };

  const startCamera = async () => {
    try {
      setCameraError('');
      setCameraReady(false);
      
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        
        // Set up metadata handler BEFORE playing
        const handleLoadedMetadata = () => {
          setCameraReady(true);
          setIsScanning(true);
          setTimeout(() => scan(), 100);
        };
        
        videoRef.current.onloadedmetadata = handleLoadedMetadata;
        
        // Start playing the video
        try {
          await videoRef.current.play();
          
          // If metadata is already loaded by the time play() completes
          if (videoRef.current.readyState >= 2) {
            handleLoadedMetadata();
          }
        } catch (playError) {
          console.error('Video play error:', playError);
          // Try to trigger anyway if video is ready
          if (videoRef.current.readyState >= 2) {
            handleLoadedMetadata();
          }
        }
      }
    } catch (error) {
      // Log as info instead of warning for permission issues (user choice, not an error)
      if (error instanceof DOMException && error.name === 'NotAllowedError') {
        console.info('📷 Camera permission denied by user (expected behavior)');
      } else {
        console.error('Camera error:', error);
      }
      
      setIsScanning(false);
      setCameraReady(false);
      
      if (error instanceof DOMException) {
        if (error.name === 'NotAllowedError') {
          setCameraError('Camera access denied. Please check your browser settings:\n\n1. Click the camera icon in your browser\'s address bar\n2. Allow camera access for this site\n3. Refresh the page and try again');
          toast.error('Camera permission required');
        } else if (error.name === 'NotFoundError') {
          setCameraError('No camera found on this device.');
          toast.error('No camera available');
        } else if (error.name === 'NotReadableError') {
          setCameraError('Camera is already in use by another application. Please close other apps and try again.');
          toast.error('Camera in use');
        } else if (error.name === 'SecurityError') {
          setCameraError('Camera access requires a secure connection (HTTPS). Please use HTTPS or localhost.');
          toast.error('Secure connection required');
        } else {
          setCameraError(`Camera error: ${error.name}. Please try again or use a different browser.`);
          toast.error('Camera initialization failed');
        }
      } else {
        setCameraError('Camera not available. Please check your device settings.');
        toast.error('Camera unavailable');
      }
    }
  };

  const scan = () => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');

    if (!ctx) return;

    if (video.readyState === video.HAVE_ENOUGH_DATA) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const code = jsQR(imageData.data, imageData.width, imageData.height, {
        inversionAttempts: 'dontInvert',
      });

      if (code) {
        handleScan(code.data);
        return;
      }
    }

    animationFrameRef.current = requestAnimationFrame(scan);
  };

  const handleScan = (data: string) => {
    onScan(data);
    stopCamera();
    onOpenChange(false);
  };

  useEffect(() => {
    if (open) {
      setCameraError('');
      stopCamera();
      setTimeout(() => startCamera(), 300);
    } else {
      stopCamera();
    }

    return () => {
      stopCamera();
    };
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto bg-white">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ScanLine className="h-5 w-5 text-[#49842B]" />
            Scan QR Code to Mark as Paid
          </DialogTitle>
          <DialogDescription>
            Point your camera at the receipt QR code
          </DialogDescription>
        </DialogHeader>

        {/* Loading State - Show while camera is initializing */}
        {!cameraReady && !cameraError && (
          <div className="space-y-2">
            <div className="relative bg-neutral-100 rounded-lg overflow-hidden h-[350px] flex items-center justify-center">
              <div className="text-[#336A29] text-center space-y-3">
                <Camera className="h-12 w-12 mx-auto animate-pulse text-[#49842B]" />
                <p className="text-sm">Initializing camera...</p>
                <p className="text-xs text-[#336A29]/60">Please allow camera access if prompted</p>
              </div>
            </div>
            <Button
              onClick={() => onOpenChange(false)}
              variant="outline"
              className="w-full"
            >
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
          </div>
        )}

        {/* Camera Scanner */}
        {cameraReady && isScanning && !cameraError && (
          <div className="space-y-2">
            <div className="relative bg-neutral-900 rounded-lg overflow-hidden">
              <div className="absolute top-2 left-2 bg-green-600 text-white px-2 py-1 rounded text-xs z-10">
                Scanning...
              </div>

              <video
                ref={videoRef}
                className="w-full h-[350px] object-cover"
                autoPlay
                playsInline
                muted
              />
              
              <canvas
                ref={canvasRef}
                className="hidden"
              />

              {/* Scanner Frame Overlay */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="relative w-56 h-56">
                  {/* Corner Brackets */}
                  <div className="absolute top-0 left-0 w-10 h-10 border-t-4 border-l-4 border-green-500"></div>
                  <div className="absolute top-0 right-0 w-10 h-10 border-t-4 border-r-4 border-green-500"></div>
                  <div className="absolute bottom-0 left-0 w-10 h-10 border-b-4 border-l-4 border-green-500"></div>
                  <div className="absolute bottom-0 right-0 w-10 h-10 border-b-4 border-r-4 border-green-500"></div>
                  
                  {/* Scanning Line */}
                  <div className="absolute inset-0 overflow-hidden">
                    <div className="h-1 bg-green-500 opacity-75 animate-scan-line"></div>
                  </div>
                </div>
              </div>
            </div>

            <Button
              onClick={() => onOpenChange(false)}
              variant="outline"
              className="w-full"
            >
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
          </div>
        )}

        {/* Error Display */}
        {cameraError && (
          <div className="space-y-4">
            <div className="rounded-lg bg-red-50 border border-red-200 p-4">
              <div className="flex gap-3">
                <AlertCircle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm text-red-800 whitespace-pre-line">{cameraError}</p>
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={() => {
                  setCameraError('');
                  startCamera();
                }}
                className="flex-1 bg-[#49842B] hover:bg-[#336A29]"
              >
                <Camera className="h-4 w-4 mr-2" />
                Retry Camera
              </Button>
              <Button
                onClick={() => onOpenChange(false)}
                variant="outline"
              >
                <X className="h-4 w-4 mr-2" />
                Cancel
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}