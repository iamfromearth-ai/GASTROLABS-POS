import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { ChevronLeft, Printer, Wifi, Usb, Bluetooth, Search, RefreshCw, Check, AlertCircle, CheckCircle } from 'lucide-react';
import { Switch } from './ui/switch';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Slider } from './ui/slider';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { bluetoothPrinter } from '../lib/bluetooth-printer';
import type { BluetoothDevice as BTDevice } from '../lib/bluetooth-printer-types';

export interface PrinterConfig {
  connectionType: 'wifi' | 'usb' | 'bluetooth';
  printerName: string;
  ipAddress: string;
  port: string;
  autoPrint: boolean;
  paperWidth: '58mm' | '80mm';
  encoding: 'UTF-8' | 'GB2312' | 'EUR(ISO_8859_15)';
  // Advanced thermal printer settings
  printingMethod: 'TXT' | 'ESC/POS' | 'CPCL';
  adjustment: number; // Scaling factor (0.5 - 2.0)
  fontSize: number; // Font size (10-50)
  continuousPrinting: number; // Number of continuous copies
  fontSizePreset: 'Small' | 'Medium' | 'Large' | 'Larger';
  lineSpacing: 'Tight' | 'Default' | 'Loose';
  blankSpacing: number; // Extra blank lines (0-5)
}

interface DiscoveredDevice {
  id: string;
  name: string;
  address: string; // IP for WiFi, device path for USB, MAC for Bluetooth
  type: 'wifi' | 'usb' | 'bluetooth';
  status: 'available' | 'connected';
}

interface PrinterSettingsProps {
  onBack: () => void;
  settings: PrinterConfig;
  onUpdateSettings: (settings: PrinterConfig) => void;
}

export function PrinterSettings({ onBack, settings, onUpdateSettings }: PrinterSettingsProps) {
  const [config, setConfig] = useState<PrinterConfig>(settings);
  const [isScanning, setIsScanning] = useState(false);
  const [discoveredDevices, setDiscoveredDevices] = useState<DiscoveredDevice[]>([]);
  const [showManualEntry, setShowManualEntry] = useState(false);
  const [showPrintPreview, setShowPrintPreview] = useState(false);
  const [printStatus, setPrintStatus] = useState<{ type: 'success' | 'error' | null; message: string }>({ type: null, message: '' });

  const updateConfig = (key: keyof PrinterConfig, value: any) => {
    const updated = { ...config, [key]: value };
    setConfig(updated);
    onUpdateSettings(updated);
  };

  // Real device discovery using Web APIs
  const scanForDevices = async () => {
    setIsScanning(true);
    setDiscoveredDevices([]);
    setShowManualEntry(false);
    setPrintStatus({ type: null, message: '' });

    try {
      if (config.connectionType === 'bluetooth') {
        // Use the new bluetooth-printer module with better error handling
        try {
          const caps = bluetoothPrinter.getPlatformCapabilities();
          
          if (!caps.hasBluetooth) {
            setPrintStatus({
              type: 'success',
              message: '📱 Bluetooth not available on this device.\n\n💡 RECOMMENDED: Use WiFi connection instead!\n\n✅ WiFi works everywhere and is easier to setup.'
            });
            setIsScanning(false);
            setShowManualEntry(true);
            return;
          }

          // Scan using the new bluetooth-printer module
          const devices = await bluetoothPrinter.scan({
            durationMs: 10000,
            nameFilters: ['POS', 'Printer', 'TM-', 'Star', 'Epson'],
          });

          if (devices.length > 0) {
            // Convert BTDevice to DiscoveredDevice
            const discovered: DiscoveredDevice[] = devices.map((d: BTDevice) => ({
              id: d.id,
              name: d.name,
              address: d.id,
              type: 'bluetooth' as const,
              status: 'available' as const,
            }));

            setDiscoveredDevices(discovered);
            setPrintStatus({
              type: 'success',
              message: `✅ Found ${devices.length} Bluetooth printer(s)!`
            });

            // Auto-select first device
            selectDevice(discovered[0]);
          } else {
            setPrintStatus({
              type: 'success',
              message: '🔍 No printers found.\n\nMake sure your printer is:\n• Powered on\n• In pairing mode\n• Within 10 meters'
            });
            setShowManualEntry(true);
          }
        } catch (bluetoothError: any) {
          console.error('Bluetooth error:', bluetoothError);
          
          // Check for nested error details (e.g., CONNECT_FAILED with nested FEATURE_UNAVAILABLE)
          const errorCode = bluetoothError.details?.code || bluetoothError.code;
          const errorHint = bluetoothError.details?.hint || bluetoothError.hint;
          
          // Handle the new error format from bluetooth-printer module
          if (errorCode === 'FEATURE_UNAVAILABLE') {
            setPrintStatus({
              type: 'success',
              message: errorHint || '🔒 BROWSER SECURITY RESTRICTION\n\n📱 Bluetooth is blocked by permissions policy.\n\n✅ SOLUTIONS:\n1. Open app in new tab (not embedded)\n2. Use WiFi connection instead (recommended)\n\n💡 WiFi is easier and works everywhere!'
            });
            setShowManualEntry(true);
          } else if (errorCode === 'PERMISSION_DENIED') {
            setPrintStatus({
              type: 'success',
              message: errorHint || '🔒 Bluetooth access blocked.\n\n💡 TIP: Use WiFi instead - enter your printer IP address manually.'
            });
            setShowManualEntry(true);
          } else if (errorCode === 'SCAN_TIMEOUT') {
            setPrintStatus({
              type: 'success',
              message: '🔍 No printer selected.\n\nTip: Make sure your Bluetooth printer is turned on and in pairing mode, then try again.'
            });
            setShowManualEntry(true);
          } else if (errorCode === 'CONNECT_FAILED') {
            setPrintStatus({
              type: 'success',
              message: errorHint || '📱 Connection failed.\n\n💡 TIP: Use WiFi instead - enter your printer IP address manually.'
            });
            setShowManualEntry(true);
          } else {
            // Generic error fallback
            setPrintStatus({
              type: 'success',
              message: errorHint || bluetoothError.hint || '📱 Bluetooth connection not available.\n\n💡 TIP: Use WiFi instead - enter your printer IP address manually.'
            });
            setShowManualEntry(true);
          }
        }
      } else if (config.connectionType === 'usb') {
        // Check if Web USB is supported
        if (!navigator.usb) {
          setPrintStatus({
            type: 'error',
            message: '📱 Web USB not available in this browser.\n\n💡 TIP: Use WiFi connection instead - it works everywhere!'
          });
          setIsScanning(false);
          setShowManualEntry(true);
          return;
        }

        try {
          // Request USB device (thermal printers)
          const device = await navigator.usb.requestDevice({
            filters: [
              // Common thermal printer vendor IDs
              { vendorId: 0x04b8 }, // Epson
              { vendorId: 0x0416 }, // Star Micronics
              { vendorId: 0x154f }, // Generic thermal printers
              { vendorId: 0x0519 }, // Citizen
              { vendorId: 0x067b }, // Prolific
            ]
          });

          if (device) {
            const discoveredDevice: DiscoveredDevice = {
              id: String(device.serialNumber || device.productId),
              name: device.productName || 'USB Thermal Printer',
              address: `USB-${device.vendorId}-${device.productId}`,
              type: 'usb',
              status: 'available'
            };

            setDiscoveredDevices([discoveredDevice]);
            setPrintStatus({
              type: 'success',
              message: `✅ Connected: ${discoveredDevice.name}`
            });

            // Auto-select the device
            selectDevice(discoveredDevice);
          }
        } catch (usbError: any) {
          console.error('USB error:', usbError);
          
          if (usbError.name === 'NotFoundError') {
            setPrintStatus({
              type: 'success',
              message: '🔍 No printer selected.\n\nTip: Make sure your USB printer is connected, then try again.'
            });
            setShowManualEntry(true);
          } else if (usbError.name === 'SecurityError' || 
                     usbError.message?.includes('permissions policy')) {
            setPrintStatus({
              type: 'success',
              message: '📱 USB scanning not available in this environment.\n\n💡 RECOMMENDED: Switch to WiFi connection instead!'
            });
            setShowManualEntry(true);
          } else {
            setPrintStatus({
              type: 'success',
              message: '📱 USB connection not available.\n\n💡 TIP: Use WiFi instead - enter your printer\'s IP address.'
            });
            setShowManualEntry(true);
          }
        }
      } else if (config.connectionType === 'wifi') {
        // WiFi: Show manual entry for IP configuration
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        setPrintStatus({
          type: 'success',
          message: '📡 WiFi Connection\n\n✅ Enter your printer\'s IP address below.\n💡 Find the IP in your printer\'s network settings.'
        });
        setShowManualEntry(true);
      }
    } catch (error: any) {
      console.error('Device discovery error:', error);
      setPrintStatus({
        type: 'success',
        message: `📱 Automatic scanning not available.\n\n💡 No problem! Enter your printer details manually below.`
      });
      setShowManualEntry(true);
    } finally {
      setIsScanning(false);
    }
  };

  const selectDevice = (device: DiscoveredDevice) => {
    updateConfig('printerName', device.name);
    
    if (device.type === 'wifi') {
      const [ip, port] = device.address.split(':');
      updateConfig('ipAddress', ip);
      updateConfig('port', port);
    }
  };

  const openTestPrintPreview = () => {
    setPrintStatus({ type: null, message: '' });
    setShowPrintPreview(true);
  };

  const handlePrintFromPreview = () => {
    // Create hidden iframe for printing
    const printFrame = document.createElement('iframe');
    printFrame.style.position = 'absolute';
    printFrame.style.width = '0';
    printFrame.style.height = '0';
    printFrame.style.border = 'none';
    
    document.body.appendChild(printFrame);

    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="${config.encoding}">
        <title>Test Print - ${config.printerName || 'Thermal Printer'}</title>
        <style>
          @page {
            size: ${config.paperWidth === '58mm' ? '58mm' : '80mm'} auto;
            margin: 0;
          }
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          body {
            font-family: 'Courier New', 'Courier', monospace;
            width: ${config.paperWidth === '58mm' ? '58mm' : '80mm'};
            margin: 0;
            padding: 10px;
            font-size: ${config.paperWidth === '58mm' ? '10px' : '11px'};
            line-height: 1.4;
            color: #000;
            background: #fff;
          }
          .header {
            text-align: center;
            margin-bottom: 10px;
            border-bottom: 2px solid #000;
            padding-bottom: 8px;
          }
          .header h1 {
            font-size: ${config.paperWidth === '58mm' ? '16px' : '18px'};
            margin-bottom: 4px;
          }
          .info-row {
            display: flex;
            justify-content: space-between;
            margin: 4px 0;
            padding: 2px 0;
          }
          .label {
            font-weight: bold;
          }
          .divider {
            border-top: 1px dashed #000;
            margin: 8px 0;
          }
          .center {
            text-align: center;
          }
          .success-box {
            border: 2px solid #000;
            padding: 10px;
            margin: 10px 0;
            text-align: center;
          }
          .footer {
            text-align: center;
            margin-top: 10px;
            padding-top: 8px;
            border-top: 2px solid #000;
            font-size: ${config.paperWidth === '58mm' ? '8px' : '9px'};
          }
          @media print {
            body {
              background: #fff;
            }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>TEST PRINT</h1>
          <div style="font-size: ${config.paperWidth === '58mm' ? '9px' : '10px'};">Printer Configuration Test</div>
        </div>

        <div class="info-row">
          <span class="label">Printer:</span>
          <span>${config.printerName || 'Not Set'}</span>
        </div>

        <div class="info-row">
          <span class="label">Paper Size:</span>
          <span>${config.paperWidth}</span>
        </div>

        <div class="info-row">
          <span class="label">Connection:</span>
          <span>${config.connectionType.toUpperCase()}</span>
        </div>

        ${config.connectionType === 'wifi' && config.ipAddress ? `
        <div class="info-row">
          <span class="label">IP Address:</span>
          <span>${config.ipAddress}</span>
        </div>
        <div class="info-row">
          <span class="label">Port:</span>
          <span>${config.port || 'N/A'}</span>
        </div>
        ` : ''}

        <div class="info-row">
          <span class="label">Encoding:</span>
          <span>${config.encoding}</span>
        </div>

        <div class="divider"></div>

        <div class="success-box">
          <div style="font-size: ${config.paperWidth === '58mm' ? '12px' : '14px'}; margin-bottom: 6px;">✓ SUCCESS</div>
          <div>If you can read this clearly,</div>
          <div>your printer is configured correctly!</div>
        </div>

        <div class="divider"></div>

        <div class="center" style="margin: 8px 0;">
          <div style="margin-bottom: 4px;">Test Characters:</div>
          <div style="letter-spacing: 1px;">ABCDEFGHIJKLMNOPQRSTUVWXYZ</div>
          <div style="letter-spacing: 1px;">abcdefghijklmnopqrstuvwxyz</div>
          <div style="letter-spacing: 1px;">0123456789 !@#$%^&*()</div>
        </div>

        <div class="divider"></div>

        <div class="footer">
          <div>Generated: ${new Date().toLocaleString()}</div>
          <div style="margin-top: 4px;">Tea Shop POS System</div>
        </div>
      </body>
      </html>
    `;

    const iframeDoc = printFrame.contentWindow?.document;
    if (iframeDoc) {
      iframeDoc.open();
      iframeDoc.write(printContent);
      iframeDoc.close();

      // Wait for content to load, then print
      printFrame.onload = () => {
        setTimeout(() => {
          printFrame.contentWindow?.print();
          
          // Clean up iframe after printing
          setTimeout(() => {
            document.body.removeChild(printFrame);
          }, 100);
          
          setPrintStatus({
            type: 'success',
            message: 'Print dialog opened successfully!'
          });
          
          setTimeout(() => {
            setPrintStatus({ type: null, message: '' });
          }, 5000);
        }, 100);
      };
    }

    setShowPrintPreview(false);
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-3 flex items-center gap-3 shadow-lg">
        <Button
          onClick={onBack}
          variant="ghost"
          size="icon"
          className="text-white hover:bg-[#49842B]/10"
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-white font-semibold">Printer Settings</h1>
      </div>

      <div className="flex-1 overflow-auto">
        {/* Connection Type */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
          <Label className="text-[#336A29] mb-3 block font-semibold">Connection Type</Label>
          <RadioGroup
            value={config.connectionType}
            onValueChange={(value) => updateConfig('connectionType', value as 'wifi' | 'usb' | 'bluetooth')}
            className="space-y-3"
          >
            <label className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg cursor-pointer hover:bg-[#80B155] transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-full flex items-center justify-center shadow-md">
                  <Wifi className="h-5 w-5 text-white" />
                </div>
                <div>
                  <div className="text-[#336A29] font-medium">WiFi Network</div>
                  <div className="text-sm text-[#336A29]/70">Connect via IP address</div>
                </div>
              </div>
              <RadioGroupItem value="wifi" />
            </label>

            <label className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg cursor-pointer hover:bg-[#80B155] transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-full flex items-center justify-center shadow-md">
                  <Usb className="h-5 w-5 text-white" />
                </div>
                <div>
                  <div className="text-[#336A29] font-medium">USB Cable</div>
                  <div className="text-sm text-[#336A29]/70">Direct connection</div>
                </div>
              </div>
              <RadioGroupItem value="usb" />
            </label>

            <label className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg cursor-pointer hover:bg-[#80B155] transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-full flex items-center justify-center shadow-md">
                  <Bluetooth className="h-5 w-5 text-white" />
                </div>
                <div>
                  <div className="text-[#336A29] font-medium">Bluetooth</div>
                  <div className="text-sm text-[#336A29]/70">Wireless connection</div>
                </div>
              </div>
              <RadioGroupItem value="bluetooth" />
            </label>
          </RadioGroup>
        </div>

        {/* Device Discovery */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
          <div className="flex items-center justify-between mb-3">
            <Label className="text-[#336A29] font-semibold">Discover Devices</Label>
            <Button
              onClick={() => setShowManualEntry(!showManualEntry)}
              variant="ghost"
              size="sm"
              className="text-[#49842B] hover:bg-[#49842B]/10"
            >
              {showManualEntry ? 'Hide Manual Entry' : 'Manual Entry'}
            </Button>
          </div>
          
          <Button
            onClick={scanForDevices}
            className="w-full bg-[#49842B] hover:bg-[#336A29]"
            disabled={isScanning}
          >
            {isScanning ? (
              <>
                <RefreshCw className="h-5 w-5 mr-2 animate-spin" />
                Scanning for {config.connectionType.toUpperCase()} devices...
              </>
            ) : (
              <>
                <Search className="h-5 w-5 mr-2" />
                Scan for {config.connectionType.toUpperCase()} Printers
              </>
            )}
          </Button>

          {/* Scanning Animation */}
          {isScanning && (
            <div className="mt-4 p-4 bg-[#49842B]/10 border border-[#49842B]/30 rounded-lg">
              <div className="flex items-center gap-3">
                <RefreshCw className="h-5 w-5 text-[#49842B] animate-spin" />
                <div>
                  <div className="text-[#336A29] font-medium">Searching for devices...</div>
                  <div className="text-sm text-[#336A29]/70">This may take a few seconds</div>
                </div>
              </div>
            </div>
          )}

          {/* Discovered Devices List */}
          {!isScanning && discoveredDevices.length > 0 && (
            <div className="mt-4">
              <Label className="text-[#336A29] mb-2 block font-medium">
                Found {discoveredDevices.length} {discoveredDevices.length === 1 ? 'device' : 'devices'}
              </Label>
              <div className="space-y-2">
                {discoveredDevices.map((device) => (
                  <button
                    key={device.id}
                    onClick={() => selectDevice(device)}
                    className="w-full flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg hover:border-[#49842B] hover:bg-[#80B155] transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-full flex items-center justify-center shadow-md">
                        {device.type === 'wifi' && <Wifi className="h-5 w-5 text-white" />}
                        {device.type === 'usb' && <Usb className="h-5 w-5 text-white" />}
                        {device.type === 'bluetooth' && <Bluetooth className="h-5 w-5 text-white" />}
                      </div>
                      <div className="text-left">
                        <div className="text-[#336A29] font-medium">{device.name}</div>
                        <div className="text-sm text-[#336A29]/70">{device.address}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-white bg-[#49842B] px-2 py-1 rounded font-medium">Available</span>
                      <Check className="h-5 w-5 text-[#49842B]" />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* No Devices Found */}
          {!isScanning && discoveredDevices.length === 0 && showManualEntry && (
            <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div className="flex items-center gap-3">
                <Search className="h-5 w-5 text-yellow-600" />
                <div>
                  <div className="text-yellow-900">No devices found</div>
                  <div className="text-sm text-yellow-600">Try manual entry below or rescan</div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Printer Details */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4 space-y-4">
          <div>
            <Label htmlFor="printer-name" className="text-[#336A29]">Printer Name</Label>
            <Input
              id="printer-name"
              value={config.printerName}
              onChange={(e) => updateConfig('printerName', e.target.value)}
              placeholder="e.g. Thermal Printer 58mm"
              className="mt-1 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
            />
          </div>

          {config.connectionType === 'wifi' && (
            <>
              <div>
                <Label htmlFor="ip-address" className="text-[#336A29]">IP Address</Label>
                <Input
                  id="ip-address"
                  value={config.ipAddress}
                  onChange={(e) => updateConfig('ipAddress', e.target.value)}
                  placeholder="e.g. 192.168.1.100"
                  className="mt-1 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                />
              </div>

              <div>
                <Label htmlFor="port" className="text-[#336A29]">Port</Label>
                <Input
                  id="port"
                  value={config.port}
                  onChange={(e) => updateConfig('port', e.target.value)}
                  placeholder="e.g. 9100"
                  className="mt-1 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                />
              </div>
            </>
          )}
        </div>

        {/* Paper Settings */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
          <Label className="text-[#336A29] mb-3 block font-semibold">Paper Width</Label>
          <RadioGroup
            value={config.paperWidth}
            onValueChange={(value) => updateConfig('paperWidth', value as '58mm' | '80mm')}
            className="space-y-2"
          >
            <label className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg cursor-pointer hover:bg-[#80B155] transition-colors">
              <span className="text-[#336A29] font-medium">58mm (2.25 inches)</span>
              <RadioGroupItem value="58mm" />
            </label>
            <label className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg cursor-pointer hover:bg-[#80B155] transition-colors">
              <span className="text-[#336A29] font-medium">80mm (3.15 inches)</span>
              <RadioGroupItem value="80mm" />
            </label>
          </RadioGroup>
        </div>

        {/* Professional Thermal Printer Settings */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4 space-y-4">
          <h3 className="text-[#336A29] font-semibold">Print Quality Settings</h3>
          
          {/* Printing Method */}
          <div>
            <Label className="text-[#336A29] font-semibold">Printing Method</Label>
            <RadioGroup
              value={config.printingMethod}
              onValueChange={(value) => updateConfig('printingMethod', value as 'TXT' | 'ESC/POS' | 'CPCL')}
              className="mt-2 space-y-2"
            >
              <label className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg cursor-pointer hover:bg-[#80B155] transition-colors">
                <span className="text-[#336A29] font-medium">TXT (Plain Text)</span>
                <RadioGroupItem value="TXT" />
              </label>
              <label className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg cursor-pointer hover:bg-[#80B155] transition-colors">
                <span className="text-[#336A29] font-medium">ESC/POS (Epson Standard)</span>
                <RadioGroupItem value="ESC/POS" />
              </label>
              <label className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg cursor-pointer hover:bg-[#80B155] transition-colors">
                <span className="text-[#336A29] font-medium">CPCL (Zebra/Intermec)</span>
                <RadioGroupItem value="CPCL" />
              </label>
            </RadioGroup>
          </div>

          {/* Adjustment (Scaling) */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label className="text-[#336A29]">Adjustment (Scaling)</Label>
              <span className="text-[#336A29] font-medium px-2 py-1 bg-[#80B155] rounded text-white text-sm">
                {config.adjustment.toFixed(2)}
              </span>
            </div>
            <Slider
              value={[config.adjustment]}
              onValueChange={(values) => updateConfig('adjustment', values[0])}
              min={0.5}
              max={2.0}
              step={0.05}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-[#336A29]/70 mt-1">
              <span>0.5x (Smaller)</span>
              <span>2.0x (Larger)</span>
            </div>
          </div>

          {/* Font Size Adjustment */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label className="text-[#336A29]">Adjust Font Size</Label>
              <span className="text-[#336A29] font-medium px-2 py-1 bg-[#80B155] rounded text-white text-sm">
                {config.fontSize}
              </span>
            </div>
            <Slider
              value={[config.fontSize]}
              onValueChange={(values) => updateConfig('fontSize', values[0])}
              min={10}
              max={50}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-[#336A29]/70 mt-1">
              <span>10 (Tiny)</span>
              <span>50 (Huge)</span>
            </div>
          </div>

          {/* Font Size Preset */}
          <div>
            <Label className="text-[#336A29] font-semibold">Font Size Preset</Label>
            <RadioGroup
              value={config.fontSizePreset}
              onValueChange={(value) => updateConfig('fontSizePreset', value as 'Small' | 'Medium' | 'Large' | 'Larger')}
              className="mt-2 space-y-2"
            >
              <label className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg cursor-pointer hover:bg-[#80B155] transition-colors">
                <span className="text-[#336A29] font-medium">Small</span>
                <RadioGroupItem value="Small" />
              </label>
              <label className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg cursor-pointer hover:bg-[#80B155] transition-colors">
                <span className="text-[#336A29] font-medium">Medium</span>
                <RadioGroupItem value="Medium" />
              </label>
              <label className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg cursor-pointer hover:bg-[#80B155] transition-colors">
                <span className="text-[#336A29] font-medium">Large</span>
                <RadioGroupItem value="Large" />
              </label>
              <label className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg cursor-pointer hover:bg-[#80B155] transition-colors">
                <span className="text-[#336A29] font-medium">Larger</span>
                <RadioGroupItem value="Larger" />
              </label>
            </RadioGroup>
          </div>

          {/* Line Spacing */}
          <div>
            <Label className="text-[#336A29] font-semibold">Line Spacing</Label>
            <RadioGroup
              value={config.lineSpacing}
              onValueChange={(value) => updateConfig('lineSpacing', value as 'Tight' | 'Default' | 'Loose')}
              className="mt-2 space-y-2"
            >
              <label className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg cursor-pointer hover:bg-[#80B155] transition-colors">
                <span className="text-[#336A29] font-medium">Tight</span>
                <RadioGroupItem value="Tight" />
              </label>
              <label className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg cursor-pointer hover:bg-[#80B155] transition-colors">
                <span className="text-[#336A29] font-medium">Default</span>
                <RadioGroupItem value="Default" />
              </label>
              <label className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg cursor-pointer hover:bg-[#80B155] transition-colors">
                <span className="text-[#336A29] font-medium">Loose</span>
                <RadioGroupItem value="Loose" />
              </label>
            </RadioGroup>
          </div>

          {/* Blank Spacing */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label className="text-[#336A29]">Blank Spacing (Extra Lines)</Label>
              <span className="text-[#336A29] font-medium px-2 py-1 bg-[#80B155] rounded text-white text-sm">
                {config.blankSpacing}
              </span>
            </div>
            <Slider
              value={[config.blankSpacing]}
              onValueChange={(values) => updateConfig('blankSpacing', values[0])}
              min={0}
              max={5}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-[#336A29]/70 mt-1">
              <span>0 (None)</span>
              <span>5 (Maximum)</span>
            </div>
          </div>

          {/* Continuous Printing */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label className="text-[#336A29]">Continuous Printing (Copies)</Label>
              <span className="text-[#336A29] font-medium px-2 py-1 bg-[#80B155] rounded text-white text-sm">
                {config.continuousPrinting}
              </span>
            </div>
            <Slider
              value={[config.continuousPrinting]}
              onValueChange={(values) => updateConfig('continuousPrinting', values[0])}
              min={1}
              max={10}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-[#336A29]/70 mt-1">
              <span>1 copy</span>
              <span>10 copies</span>
            </div>
          </div>
        </div>

        {/* Test Print */}
        <div className="mt-4 mb-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
          <Button
            onClick={openTestPrintPreview}
            className="w-full bg-[#49842B] hover:bg-[#336A29]"
          >
            <Printer className="h-5 w-5 mr-2" />
            Test Print
          </Button>
          {printStatus.type === 'success' && (
            <div className="text-sm text-[#49842B] text-left mt-3 bg-[#EAEF9D] p-3 rounded-lg border border-[#49842B]/30">
              <div className="flex items-start gap-2">
                <CheckCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <div className="whitespace-pre-line flex-1">{printStatus.message}</div>
              </div>
              {/* Quick switch to WiFi if Bluetooth/USB fails */}
              {(config.connectionType === 'bluetooth' || config.connectionType === 'usb') && 
               printStatus.message.includes('not available') && (
                <Button
                  onClick={() => updateConfig('connectionType', 'wifi')}
                  className="w-full mt-3 bg-[#49842B] hover:bg-[#336A29]"
                  size="sm"
                >
                  <Wifi className="h-4 w-4 mr-2" />
                  Switch to WiFi Connection
                </Button>
              )}
            </div>
          )}
          {printStatus.type === 'error' && (
            <div className="text-sm text-red-600 text-left mt-3 bg-red-50 p-3 rounded-lg border border-red-200">
              <div className="flex items-start gap-2">
                <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <div className="whitespace-pre-line flex-1">{printStatus.message}</div>
              </div>
              {/* Quick switch to WiFi if Bluetooth/USB not supported */}
              {(config.connectionType === 'bluetooth' || config.connectionType === 'usb') && (
                <Button
                  onClick={() => updateConfig('connectionType', 'wifi')}
                  className="w-full mt-3 bg-[#49842B] hover:bg-[#336A29]"
                  size="sm"
                >
                  <Wifi className="h-4 w-4 mr-2" />
                  Switch to WiFi Connection
                </Button>
              )}
            </div>
          )}
          {!printStatus.type && (
            <p className="text-sm text-[#336A29]/70 text-center mt-2">
              Print a test receipt to verify connection
            </p>
          )}
        </div>
      </div>

      {/* Test Print Preview Dialog */}
      <Dialog open={showPrintPreview} onOpenChange={setShowPrintPreview}>
        <DialogContent className="max-w-md p-0 gap-0">
          <DialogHeader className="sr-only">
            <DialogTitle>Test Print Preview</DialogTitle>
            <DialogDescription>
              Review your test print before sending to printer
            </DialogDescription>
          </DialogHeader>
          
          {/* Receipt Preview */}
          <div className="max-h-[70vh] overflow-auto p-6 bg-neutral-50">
            <div 
              className="bg-white mx-auto p-4 shadow-lg" 
              style={{ 
                width: config.paperWidth === '58mm' ? '220px' : '300px',
                fontFamily: 'monospace',
                fontSize: config.paperWidth === '58mm' ? '10px' : '11px'
              }}
            >
              {/* Header */}
              <div className="text-center mb-3 pb-2 border-b-2 border-black">
                <div className="text-lg mb-1">TEST PRINT</div>
                <div className="text-xs">Printer Configuration Test</div>
              </div>

              {/* Info */}
              <div className="space-y-1 text-xs">
                <div className="flex justify-between">
                  <span className="font-semibold">Printer:</span>
                  <span>{config.printerName || 'Not Set'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-semibold">Paper Size:</span>
                  <span>{config.paperWidth}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-semibold">Connection:</span>
                  <span>{config.connectionType.toUpperCase()}</span>
                </div>
                {config.connectionType === 'wifi' && config.ipAddress && (
                  <>
                    <div className="flex justify-between">
                      <span className="font-semibold">IP Address:</span>
                      <span>{config.ipAddress}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-semibold">Port:</span>
                      <span>{config.port || 'N/A'}</span>
                    </div>
                  </>
                )}
                <div className="flex justify-between">
                  <span className="font-semibold">Encoding:</span>
                  <span>{config.encoding}</span>
                </div>
              </div>

              {/* Divider */}
              <div className="border-t border-dashed border-black my-2"></div>

              {/* Success Box */}
              <div className="border-2 border-black p-3 my-3 text-center">
                <div className="text-sm mb-1">✓ SUCCESS</div>
                <div className="text-xs">If you can read this clearly,</div>
                <div className="text-xs">your printer is configured correctly!</div>
              </div>

              {/* Divider */}
              <div className="border-t border-dashed border-black my-2"></div>

              {/* Test Characters */}
              <div className="text-center text-xs space-y-1">
                <div className="mb-1">Test Characters:</div>
                <div style={{ letterSpacing: '1px' }}>ABCDEFGHIJKLMNOPQRSTUVWXYZ</div>
                <div style={{ letterSpacing: '1px' }}>abcdefghijklmnopqrstuvwxyz</div>
                <div style={{ letterSpacing: '1px' }}>0123456789 !@#$%^&*()</div>
              </div>

              {/* Divider */}
              <div className="border-t border-dashed border-black my-2"></div>

              {/* Footer */}
              <div className="text-center text-xs pt-2 border-t-2 border-black">
                <div>Generated: {new Date().toLocaleString()}</div>
                <div className="mt-1">Tea Shop POS System</div>
              </div>
            </div>
          </div>

          <DialogFooter className="p-4 border-t">
            <Button
              onClick={() => setShowPrintPreview(false)}
              variant="outline"
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              onClick={handlePrintFromPreview}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              <Printer className="h-4 w-4 mr-2" />
              Print
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}