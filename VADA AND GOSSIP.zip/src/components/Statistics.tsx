import { useState, useMemo } from 'react';
import { Order } from '../App';
import { Button } from './ui/button';
import { ArrowLeft, Download } from 'lucide-react';
import { Card } from './ui/card';

interface StatisticsProps {
  orders: Order[];
  onBack: () => void;
}

type Period = 'today' | 'week' | 'month' | 'all';

export function Statistics({ orders, onBack }: StatisticsProps) {
  const [period, setPeriod] = useState<Period>('today');

  const isInPeriod = (date: Date, period: Period): boolean => {
    const now = new Date();
    const orderDate = new Date(date);
    
    switch (period) {
      case 'today':
        return (
          orderDate.getDate() === now.getDate() &&
          orderDate.getMonth() === now.getMonth() &&
          orderDate.getFullYear() === now.getFullYear()
        );
      case 'week':
        const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        return orderDate >= weekAgo;
      case 'month':
        const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        return orderDate >= monthAgo;
      case 'all':
        return true;
      default:
        return false;
    }
  };

  const stats = useMemo(() => {
    const filteredOrders = orders.filter((order) => isInPeriod(order.timestamp, period));
    
    const receiptsQuantity = filteredOrders.length;
    const totalItems = filteredOrders.reduce(
      (sum, order) => sum + order.items.reduce((itemSum, item) => itemSum + item.quantity, 0),
      0
    );
    const grandTotal = filteredOrders.reduce((sum, order) => sum + order.total, 0);
    const unpaidAmount = filteredOrders
      .filter((o) => o.status === 'active')
      .reduce((sum, order) => sum + order.total, 0);
    const paidAmount = filteredOrders
      .filter((o) => o.status === 'paid')
      .reduce((sum, order) => sum + order.total, 0);

    // Sales report - group by item
    const salesByItem = new Map<string, { quantity: number; total: number }>();
    filteredOrders.forEach((order) => {
      order.items.forEach((item) => {
        const existing = salesByItem.get(item.name) || { quantity: 0, total: 0 };
        salesByItem.set(item.name, {
          quantity: existing.quantity + item.quantity,
          total: existing.total + item.price * item.quantity,
        });
      });
    });

    const salesReport = Array.from(salesByItem.entries())
      .map(([name, data]) => ({ name, ...data }))
      .sort((a, b) => b.total - a.total);

    return {
      receiptsQuantity,
      totalItems,
      grandTotal,
      unpaidAmount,
      paidAmount,
      salesReport,
    };
  }, [orders, period]);

  const handleExportCSV = () => {
    const csvContent = [
      ['Statistics Report', '', '', ''],
      ['Period', period, '', ''],
      ['Date', new Date().toLocaleDateString('en-IN'), '', ''],
      ['', '', '', ''],
      ['Receipts Quantity', stats.receiptsQuantity, '', ''],
      ['Quantity of Items', stats.totalItems, '', ''],
      ['Grand Total', stats.grandTotal, '', ''],
      ['Unpaid Bills', stats.unpaidAmount, '', ''],
      ['Paid Bills', stats.paidAmount, '', ''],
      ['', '', '', ''],
      ['Sales Report', '', '', ''],
      ['Item', 'Quantity', 'Total', ''],
      ...stats.salesReport.map((item) => [item.name, item.quantity, item.total, '']),
    ]
      .map((row) => row.join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `statistics-${period}-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const getPeriodLabel = () => {
    switch (period) {
      case 'today': return 'Today';
      case 'week': return 'This Week';
      case 'month': return 'This Month';
      case 'all': return 'All Time';
      default: return 'Today';
    }
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-4 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              onClick={onBack}
              variant="ghost"
              size="icon"
              className="text-white hover:bg-[#49842B]/10"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-white font-semibold">Statistics</h1>
              <p className="text-sm text-white/80">Sales analytics & insights</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleExportCSV}
            className="text-white hover:bg-[#49842B]/10"
            title="Export to CSV"
          >
            <Download className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-3 flex gap-2">
        <Button
          variant={period === 'today' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setPeriod('today')}
          className={
            period === 'today'
              ? 'bg-gradient-to-r from-[#49842B] to-[#336A29] text-white border-0'
              : 'bg-[#80B155] text-white border-[#336A29]/20 hover:bg-[#49842B]'
          }
        >
          Today
        </Button>
        <Button
          variant={period === 'week' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setPeriod('week')}
          className={
            period === 'week'
              ? 'bg-gradient-to-r from-[#49842B] to-[#336A29] text-white border-0'
              : 'bg-[#80B155] text-white border-[#336A29]/20 hover:bg-[#49842B]'
          }
        >
          This Week
        </Button>
        <Button
          variant={period === 'month' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setPeriod('month')}
          className={
            period === 'month'
              ? 'bg-gradient-to-r from-[#49842B] to-[#336A29] text-white border-0'
              : 'bg-[#80B155] text-white border-[#336A29]/20 hover:bg-[#49842B]'
          }
        >
          This Month
        </Button>
        <Button
          variant={period === 'all' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setPeriod('all')}
          className={
            period === 'all'
              ? 'bg-gradient-to-r from-[#49842B] to-[#336A29] text-white border-0'
              : 'bg-[#80B155] text-white border-[#336A29]/20 hover:bg-[#49842B]'
          }
        >
          All Time
        </Button>
      </div>

      {/* Stats Grid */}
      <div className="flex-1 overflow-auto">
        <div className="px-4 grid grid-cols-2 gap-4 mb-4 pt-4">
          <Card className="p-4 bg-[#C1D95C] border-[#336A29]/15">
            <p className="text-sm text-[#336A29]/70 mb-1">Receipts Quantity</p>
            <p className="text-[#336A29] text-2xl font-semibold">{stats.receiptsQuantity}</p>
          </Card>
          <Card className="p-4 bg-[#C1D95C] border-[#336A29]/15">
            <p className="text-sm text-[#336A29]/70 mb-1">Quantity of Items</p>
            <p className="text-[#336A29] text-2xl font-semibold">{stats.totalItems}</p>
          </Card>
          <Card className="p-4 bg-gradient-to-br from-[#49842B] to-[#336A29] border-0 shadow-lg">
            <p className="text-sm text-white/80 mb-1">Grand Total</p>
            <p className="text-white text-2xl font-semibold">Rs {stats.grandTotal}</p>
          </Card>
          <Card className="p-4 bg-[#C1D95C] border-[#336A29]/15">
            <p className="text-sm text-[#336A29]/70 mb-1">Estimated profit</p>
            <p className="text-[#336A29] text-2xl font-semibold">Rs 0</p>
          </Card>
          <Card className="p-4 bg-gradient-to-br from-[#FF8A65] to-[#FF7043] border-0 shadow-lg">
            <p className="text-sm text-white/80 mb-1">Unpaid Bills</p>
            <p className="text-white text-2xl font-semibold">Rs {stats.unpaidAmount}</p>
          </Card>
          <Card className="p-4 bg-gradient-to-br from-[#66BB6A] to-[#4CAF50] border-0 shadow-lg">
            <p className="text-sm text-white/80 mb-1">Paid Bills</p>
            <p className="text-white text-2xl font-semibold">Rs {stats.paidAmount}</p>
          </Card>
        </div>

        {/* Sales Report */}
        {stats.salesReport.length > 0 && (
          <div className="px-4 pb-4">
            <div className="bg-[#C1D95C] border border-[#336A29]/15 rounded-2xl overflow-hidden">
              <div className="px-4 py-3 bg-[#80B155] border-b border-[#336A29]/15">
                <h3 className="text-white font-medium">Top Selling Items</h3>
              </div>
              <div>
                {stats.salesReport.slice(0, 10).map((item, index) => (
                  <div key={index} className="px-4 py-3 flex items-center justify-between hover:bg-[#80B155] transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#49842B] to-[#336A29] flex items-center justify-center text-white text-sm font-semibold">
                        {index + 1}
                      </div>
                      <span className="text-[#336A29] font-medium">{item.name}</span>
                    </div>
                    <div className="text-right">
                      <p className="text-[#336A29] font-semibold">Rs {item.total}</p>
                      <p className="text-xs text-[#336A29]/70">{item.quantity} sold</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}