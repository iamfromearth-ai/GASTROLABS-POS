import { Button } from './ui/button';
import { Trash2, Package, Settings, TrendingUp, Printer, ClipboardList, Layers } from 'lucide-react';
import { Badge } from './ui/badge';
import { Order } from '../App';

interface SidebarProps {
  onClear: () => void;
  onCheckout: () => void;
  onManageItems: () => void;
  onManageCategories: () => void;
  onViewHistory: () => void;
  onSettings: () => void;
  onStatistics: () => void;
  hasItems: boolean;
  orders: Order[];
}

export function Sidebar({ onClear, onCheckout, onManageItems, onManageCategories, onViewHistory, onSettings, onStatistics, hasItems, orders }: SidebarProps) {
  const unpaidCount = orders.filter(o => o.status === 'active').length;
  const paidCount = orders.filter(o => o.status === 'paid').length;
  const hasUnpaidBills = unpaidCount > 0;
  const unpaidTotal = orders.filter(o => o.status === 'active').reduce((sum, o) => sum + o.total, 0);
  const paidTotal = orders.filter(o => o.status === 'paid').reduce((sum, o) => sum + o.total, 0);
  
  // Today's paid bills
  const todayPaidCount = orders.filter((o) => {
    if (o.status !== 'paid') return false;
    const today = new Date();
    const orderDate = new Date(o.timestamp);
    return (
      orderDate.getDate() === today.getDate() &&
      orderDate.getMonth() === today.getMonth() &&
      orderDate.getFullYear() === today.getFullYear()
    );
  }).length;

  return (
    <div className="w-20 bg-[#C1D95C] border border-[#336A29]/15 flex flex-col items-center py-6 gap-4 shadow-xl rounded-2xl">
      {/* CRITICAL ALERT: Unpaid Bills - Top Priority */}
      {unpaidCount > 0 && (
        <div className="relative">
          <Button
            onClick={onViewHistory}
            variant="ghost"
            size="icon"
            className="h-14 w-14 rounded-full bg-gradient-to-br from-[#FF3B30] to-[#FF0000] hover:from-[#FF0000] hover:to-[#FF3B30] text-white shadow-2xl shadow-[#FF0000]/50 border-2 border-white/30 ring-4 ring-[#FF0000]/60 hover:ring-[#FF0000]/80"
            title={`URGENT: ${unpaidCount} unpaid bill${unpaidCount > 1 ? 's' : ''} pending!`}
          >
            <ClipboardList className="h-6 w-6 animate-pulse" />
          </Button>
          <Badge 
            className="absolute -top-1 -right-1 h-6 w-6 flex items-center justify-center p-0 bg-white text-[#FF0000] border-2 border-[#FF0000] font-bold animate-bounce"
          >
            {unpaidCount}
          </Badge>
        </div>
      )}

      {/* History - Only show when no unpaid bills */}
      {unpaidCount === 0 && (
        <Button
          onClick={onViewHistory}
          variant="ghost"
          size="icon"
          className="h-14 w-14 rounded-full bg-gradient-to-br from-[#16DB65] to-[#14C95A] hover:from-[#14C95A] hover:to-[#16DB65] text-white shadow-lg border-0"
          title="Order History"
        >
          <ClipboardList className="h-6 w-6" />
        </Button>
      )}

      {/* Spacer */}
      <div className="flex-1" />

      {/* Statistics */}
      <Button
        onClick={onStatistics}
        variant="ghost"
        size="icon"
        className="h-14 w-14 rounded-full bg-[#80B155] hover:bg-[#49842B] text-white border border-[#336A29]/20"
        title="Statistics"
      >
        <TrendingUp className="h-6 w-6" />
      </Button>

      {/* Settings */}
      <Button
        onClick={onSettings}
        variant="ghost"
        size="icon"
        className="h-14 w-14 rounded-full bg-[#80B155] hover:bg-[#49842B] text-white border border-[#336A29]/20"
        title="Settings"
      >
        <Settings className="h-6 w-6" />
      </Button>

      {/* Manage Inventory - Combined Categories & Items */}
      <Button
        onClick={onManageItems}
        variant="ghost"
        size="icon"
        className="h-14 w-14 rounded-full bg-[#80B155] hover:bg-[#49842B] text-white border border-[#336A29]/20"
        title="Manage Inventory"
      >
        <Layers className="h-6 w-6" />
      </Button>

      {/* Divider */}
      <div className="w-12 h-px bg-[#336A29]/30 my-2" />

      {/* Clear Bill */}
      {hasItems && (
        <Button
          onClick={onClear}
          variant="ghost"
          size="icon"
          className="h-14 w-14 rounded-full bg-gradient-to-br from-[#ff5c39] to-[#ff7043] hover:from-[#ff7043] hover:to-[#ff5c39] text-white shadow-2xl border-2 border-white/30 backdrop-blur-sm ring-4 ring-[#ff5c39]/40 hover:ring-[#ff5c39]/60 hover:scale-110 transition-all duration-300"
          title="Clear Current Bill"
        >
          <Trash2 className="h-6 w-6" />
        </Button>
      )}

      {/* Checkout Button */}
      <Button
        onClick={onCheckout}
        variant="default"
        size="icon"
        disabled={!hasItems}
        className={
          hasItems
            ? "h-14 w-14 rounded-full bg-gradient-to-br from-[#D4FF00] to-[#CCFF00] hover:from-[#E0FF00] hover:to-[#D4FF00] text-[#1a3d15] shadow-2xl shadow-[#D4FF00]/50 border-2 border-white/40 backdrop-blur-sm ring-4 ring-[#D4FF00]/60 hover:ring-[#D4FF00]/80 hover:shadow-[#D4FF00]/70 hover:scale-110 transition-all duration-300 animate-pulse"
            : "h-14 w-14 rounded-full bg-slate-600 text-white/40 shadow-lg border-0 opacity-40 cursor-not-allowed"
        }
        title={hasItems ? 'Checkout & Print' : 'Add items to checkout'}
      >
        <Printer className="h-6 w-6" />
      </Button>
    </div>
  );
}