import { useState } from 'react';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Button } from './ui/button';
import { ChevronLeft, Upload, Image, Trash2 } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export interface LogoConfig {
  enabled: boolean;
  type: 'upload' | 'text';
  imageUrl: string;
  text: string;
  size: 'small' | 'medium' | 'large';
}

interface LogoSettingsProps {
  onBack: () => void;
  settings: LogoConfig;
  onUpdateSettings: (settings: LogoConfig) => void;
}

export function LogoSettings({ onBack, settings, onUpdateSettings }: LogoSettingsProps) {
  const [config, setConfig] = useState<LogoConfig>(settings);

  const updateConfig = (key: keyof LogoConfig, value: any) => {
    const updated = { ...config, [key]: value };
    setConfig(updated);
    onUpdateSettings(updated);
    
    // Save to localStorage for persistence
    saveToLocalStorage(updated);
  };

  const saveToLocalStorage = (logoConfig: LogoConfig) => {
    try {
      // Load existing receipt config from localStorage
      const savedConfig = localStorage.getItem('gastrolabs_receipt_config');
      if (savedConfig) {
        const receiptConfig = JSON.parse(savedConfig);
        receiptConfig.logo = logoConfig;
        localStorage.setItem('gastrolabs_receipt_config', JSON.stringify(receiptConfig));
      } else {
        // If no receipt config exists, just save the logo config
        localStorage.setItem('gastrolabs_logo_config', JSON.stringify(logoConfig));
      }
      console.log('✅ Logo settings saved to localStorage');
    } catch (error) {
      console.error('Failed to save logo settings:', error);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Check file size (2MB limit)
      if (file.size > 2 * 1024 * 1024) {
        toast.error('Image size should be less than 2MB');
        return;
      }

      // Check file type
      if (!file.type.startsWith('image/')) {
        toast.error('Please upload a valid image file');
        return;
      }

      const reader = new FileReader();
      reader.onload = (event) => {
        const imageUrl = event.target?.result as string;
        updateConfig('imageUrl', imageUrl);
        updateConfig('type', 'upload');
        toast.success('✅ Logo uploaded! It will appear on all receipts.');
      };
      reader.onerror = () => {
        toast.error('Failed to read image file');
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-3 flex items-center gap-3 shadow-lg">
        <Button
          onClick={onBack}
          variant="ghost"
          size="icon"
          className="text-[#49842B] hover:bg-[#49842B]/10"
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-[#336A29] font-semibold">Logo Settings</h1>
      </div>

      <div className="flex-1 overflow-auto">
        {/* Logo Type */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
          <Label className="text-[#336A29] mb-3 block font-semibold">Logo Type</Label>
          <RadioGroup
            value={config.type}
            onValueChange={(value) => updateConfig('type', value as 'upload' | 'text')}
            className="space-y-2"
          >
            <label className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg cursor-pointer hover:bg-[#80B155] transition-colors">
              <div className="flex items-center gap-3">
                <Upload className="h-5 w-5 text-[#49842B]" />
                <span className="text-[#336A29] font-medium">Upload Image</span>
              </div>
              <RadioGroupItem value="upload" />
            </label>
            <label className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg cursor-pointer hover:bg-[#80B155] transition-colors">
              <div className="flex items-center gap-3">
                <Image className="h-5 w-5 text-[#49842B]" />
                <span className="text-[#336A29] font-medium">Text Logo</span>
              </div>
              <RadioGroupItem value="text" />
            </label>
          </RadioGroup>
        </div>

        {/* Upload Image */}
        {config.type === 'upload' && (
          <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
            <Label className="text-[#336A29] mb-3 block font-semibold">Upload Logo</Label>
            
            {config.imageUrl ? (
              <div className="space-y-3">
                <div className="border-2 border-dashed border-[#336A29]/30 rounded-lg p-4 flex flex-col items-center bg-[#80B155]/30">
                  <img src={config.imageUrl} alt="Logo" className="max-w-[200px] max-h-[200px] object-contain" />
                </div>
                <Button
                  onClick={() => updateConfig('imageUrl', '')}
                  variant="destructive"
                  className="w-full"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Remove Logo
                </Button>
              </div>
            ) : (
              <>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  id="logo-upload"
                />
                <label 
                  htmlFor="logo-upload"
                  className="border-2 border-dashed border-[#336A29]/30 rounded-lg p-8 flex flex-col items-center cursor-pointer hover:border-[#49842B] hover:bg-[#80B155]/30 transition-colors"
                >
                  <Upload className="h-12 w-12 text-[#336A29]/50 mb-3" />
                  <p className="text-[#336A29] mb-3">Click to upload logo</p>
                  <span className="inline-flex items-center justify-center rounded-md bg-[#49842B] px-4 py-2 text-white hover:bg-[#336A29]">
                    Choose File
                  </span>
                  <p className="text-xs text-[#336A29]/70 mt-2">PNG, JPG up to 2MB</p>
                </label>
              </>
            )}
          </div>
        )}

        {/* Text Logo */}
        {config.type === 'text' && (
          <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
            <Label htmlFor="logo-text" className="text-[#336A29]">Logo Text</Label>
            <Input
              id="logo-text"
              value={config.text}
              onChange={(e) => updateConfig('text', e.target.value)}
              placeholder="Enter your business name"
              className="mt-2 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
            />
          </div>
        )}

        {/* Logo Size */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
          <Label className="text-[#336A29] mb-3 block font-semibold">Logo Size</Label>
          <RadioGroup
            value={config.size}
            onValueChange={(value) => updateConfig('size', value as 'small' | 'medium' | 'large')}
            className="space-y-2"
          >
            <label className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg cursor-pointer hover:bg-[#80B155] transition-colors">
              <span className="text-[#336A29] font-medium">Small</span>
              <RadioGroupItem value="small" />
            </label>
            <label className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg cursor-pointer hover:bg-[#80B155] transition-colors">
              <span className="text-[#336A29] font-medium">Medium</span>
              <RadioGroupItem value="medium" />
            </label>
            <label className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg cursor-pointer hover:bg-[#80B155] transition-colors">
              <span className="text-[#336A29] font-medium">Large</span>
              <RadioGroupItem value="large" />
            </label>
          </RadioGroup>
        </div>

        {/* Preview */}
        <div className="mt-4 mb-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
          <Label className="text-[#336A29] mb-3 block font-semibold">Preview</Label>
          <div className="border border-[#336A29]/20 rounded-lg p-6 flex justify-center bg-[#80B155]/30">
            {config.type === 'upload' && config.imageUrl ? (
              <img 
                src={config.imageUrl} 
                alt="Logo Preview" 
                className={
                  config.size === 'small' ? 'h-12' :
                  config.size === 'medium' ? 'h-16' :
                  'h-24'
                }
              />
            ) : config.type === 'text' && config.text ? (
              <div 
                className={`text-[#336A29] font-semibold text-center ${
                  config.size === 'small' ? 'text-xl' :
                  config.size === 'medium' ? 'text-2xl' :
                  'text-3xl'
                }`}
              >
                {config.text}
              </div>
            ) : (
              <div className="text-[#336A29]/50">No logo configured</div>
            )}
          </div>
          <p className="text-xs text-[#336A29]/60 mt-2 text-center">
            💾 Settings auto-save and will appear on all receipts
          </p>
        </div>
      </div>
    </div>
  );
}