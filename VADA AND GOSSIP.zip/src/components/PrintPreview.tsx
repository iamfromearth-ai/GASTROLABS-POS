import { BillItem } from '../App';
import { ReceiptConfig } from './ReceiptSettings';
import { Button } from './ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogOverlay,
  DialogPortal,
} from './ui/dialog';
import * as DialogPrimitive from '@radix-ui/react-dialog@1.1.6';
import { XIcon } from 'lucide-react';
import defaultLogo from 'figma:asset/f45a949b947b5517a1d0ef8f997f50b041970f5c.png';
import QRCode from 'qrcode';
import { useEffect, useState } from 'react';
import { cn } from './ui/utils';

interface PrintPreviewProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  items: BillItem[];
  total: number;
  config: ReceiptConfig;
  onPrint: () => void;
  orderId?: string;
}

export function PrintPreview({ open, onOpenChange, items, total, config, onPrint, orderId }: PrintPreviewProps) {
  const [qrCodeUrl, setQrCodeUrl] = useState<string>('');
  const [upiQrCodeUrl, setUpiQrCodeUrl] = useState<string>('');
  
  useEffect(() => {
    if (orderId) {
      // Generate smaller QR code with just order ID for employee tracking
      QRCode.toDataURL(orderId, {
        width: 80,
        margin: 0,
      }).then((url) => {
        setQrCodeUrl(url);
      });
    }
  }, [orderId]);

  // Generate UPI QR Code
  useEffect(() => {
    // Get UPI ID from config, fallback to default if not set
    const upiId = config.paymentQR?.upiId || 'jyothish.rajendran@federal';
    const businessName = config.business?.businessName || 'Vada & Gossip';
    
    // Debug logging
    console.log('🔍 PrintPreview - Generating UPI QR with:', { upiId, businessName, total });
    
    const upiString = `upi://pay?pa=${upiId}&pn=${encodeURIComponent(businessName)}&am=${total}&cu=INR`;
    
    QRCode.toDataURL(upiString, {
      width: 360, // High resolution for 180px display (2x for crisp output)
      margin: 1,
      color: {
        dark: '#000000',
        light: '#FFFFFF'
      }
    }).then((url) => {
      setUpiQrCodeUrl(url);
    });
  }, [total, config.paymentQR?.upiId, config.business?.businessName]);

  const handlePrint = () => {
    onPrint();
    onOpenChange(false);
  };

  const totalQty = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogPortal>
        {/* Custom overlay with lower z-index */}
        <DialogPrimitive.Overlay
          className={cn(
            "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-[50] bg-black/50 backdrop-blur-sm"
          )}
        />
        {/* Custom content with matching z-index */}
        <DialogPrimitive.Content
          className={cn(
            "bg-white data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 fixed top-[50%] left-[50%] z-[51] grid w-full max-w-2xl max-h-[90vh] translate-x-[-50%] translate-y-[-50%] p-0 gap-0 rounded-lg border shadow-lg duration-200"
          )}
        >
          <DialogPrimitive.Close className="absolute top-4 right-4 rounded-sm opacity-70 ring-offset-white transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-neutral-950 focus:ring-offset-2 disabled:pointer-events-none z-10">
            <XIcon className="h-4 w-4" />
            <span className="sr-only">Close</span>
          </DialogPrimitive.Close>
          
          <div className="sr-only">
            <DialogPrimitive.Title>Print Receipt Preview</DialogPrimitive.Title>
            <DialogPrimitive.Description>
              Review your receipt before printing
            </DialogPrimitive.Description>
          </div>
          {/* Receipt Preview */}
          <div className="max-h-[75vh] overflow-auto p-6 bg-neutral-100">
            <div className="w-full max-w-[384px] mx-auto bg-white p-4 shadow-2xl" style={{ fontFamily: 'monospace' }}>
              {/* Logo Section */}
              <div className="flex flex-col items-center mb-2">
                {/* Logo - Smaller for compact receipt */}
                <img 
                  src={
                    config.logo?.type === 'upload' && config.logo.imageUrl 
                      ? config.logo.imageUrl 
                      : defaultLogo
                  } 
                  alt="Logo" 
                  className="h-20 w-20 object-contain mb-2"
                />

                {/* Business Info or Header */}
                {config.business?.enabled && config.business.businessName ? (
                  <div className="text-center mb-2">
                    <h2 className="uppercase tracking-wide mb-1 text-black" style={{ fontWeight: 'bold', fontSize: '15px' }}>
                      {config.business.businessName}
                    </h2>
                    {config.business.address && (
                      <div className="text-xs text-neutral-700 whitespace-pre-wrap">
                        {config.business.address}
                      </div>
                    )}
                    {config.business.phone && (
                      <div className="text-xs text-neutral-700">Tel: {config.business.phone}</div>
                    )}
                  </div>
                ) : null}
              </div>

              {/* Date/Time - Compact */}
              <div className="text-center text-xs mb-2 pb-2 text-neutral-800" style={{ borderBottom: '1px dashed #000' }}>
                {new Date().toLocaleDateString('en-GB')} {new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}
              </div>

              {/* Items Table */}
              <div className="mb-2">
                <div className="grid grid-cols-12 gap-1 text-xs mb-1 text-black" style={{ fontWeight: 'bold' }}>
                  <div className="col-span-5">Item</div>
                  <div className="col-span-2 text-center">Qty</div>
                  <div className="col-span-3 text-right">Price</div>
                  <div className="col-span-2 text-right">Total</div>
                </div>
                <div style={{ borderTop: '1px dashed #000', marginBottom: '4px' }}></div>
                {items.map((item, idx) => (
                  <div key={idx} className="grid grid-cols-12 gap-1 text-xs mb-1 text-neutral-900">
                    <div className="col-span-5 truncate">{item.name}</div>
                    <div className="col-span-2 text-center">{item.quantity}</div>
                    <div className="col-span-3 text-right">{item.price}</div>
                    <div className="col-span-2 text-right">{item.price * item.quantity}</div>
                  </div>
                ))}
                <div style={{ borderTop: '1px dashed #000', marginTop: '4px', marginBottom: '4px' }}></div>
              </div>

              {/* Grand Total - Compact */}
              {config.showGrandTotal && (
                <div className="flex justify-between mb-3 mt-2 text-black" style={{ fontWeight: 'bold', fontSize: '16px', borderTop: '2px solid #000', borderBottom: '2px solid #000', paddingTop: '6px', paddingBottom: '6px' }}>
                  <span>TOTAL:</span>
                  <span>Rs {total}</span>
                </div>
              )}

              {/* CUSTOMER PAYMENT SECTION - UPI QR Code (Large & Prominent) */}
              <div className="mt-3 pt-3" style={{ borderTop: '2px solid #000' }}>
                <div className="text-center mb-2">
                  <div className="text-black" style={{ fontSize: '14px', fontWeight: 'bold', marginBottom: '4px' }}>
                    ═══ PAY USING UPI ═══
                  </div>
                  <div className="text-xs text-neutral-700 mb-2">
                    Scan & Pay using any UPI app
                  </div>
                </div>

                {/* Masked Payment QR Code - Security Feature */}
                <div className="flex justify-center mb-3">
                  <div 
                    className="flex flex-col items-center justify-center bg-neutral-200 border-2 border-dashed border-neutral-400"
                    style={{ width: '180px', height: '180px' }}
                  >
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      width="48" 
                      height="48" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round"
                      className="text-neutral-500 mb-2"
                    >
                      <rect width="5" height="5" x="3" y="3" rx="1"/>
                      <rect width="5" height="5" x="16" y="3" rx="1"/>
                      <rect width="5" height="5" x="3" y="16" rx="1"/>
                      <path d="M21 16h-3a2 2 0 0 0-2 2v3"/>
                      <path d="M21 21v.01"/>
                      <path d="M12 7v3a2 2 0 0 1-2 2H7"/>
                      <path d="M3 12h.01"/>
                      <path d="M12 3h.01"/>
                      <path d="M12 16v.01"/>
                      <path d="M16 12h1"/>
                      <path d="M21 12v.01"/>
                      <path d="M12 21v-1"/>
                    </svg>
                    <div className="text-xs text-neutral-600 text-center px-3">
                      <div style={{ fontWeight: 'bold', marginBottom: '2px' }}>QR CODE HIDDEN</div>
                      <div>Visible on printed receipt only</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Thank you message */}
              <div className="text-center text-xs mb-2 mt-3 text-black" style={{ borderTop: '1px dashed #000', paddingTop: '8px' }}>
                THANK YOU AND COME AGAIN!
              </div>

              {/* EMPLOYEE TRACKING SECTION - Small Order QR (Bottom Right) */}
              {orderId && qrCodeUrl && (
                <div className="flex justify-between items-end mt-2 pt-2" style={{ borderTop: '1px dashed #000' }}>
                  <div className="text-left flex-1">
                    <div className="text-xs text-neutral-600">ID: #{orderId.slice(-6)}</div>
                    <div className="text-xs text-neutral-600">
                      {new Date().toLocaleDateString('en-IN', {
                        day: '2-digit',
                        month: 'short'
                      })}
                    </div>
                  </div>
                  <div className="text-center">
                    <img 
                      src={qrCodeUrl} 
                      alt="Order Tracking" 
                      style={{ width: '50px', height: '50px' }}
                    />
                  </div>
                </div>
              )}

              {/* Paid Time */}
              {config.showPaidTime && (
                <div className="text-center text-xs mt-2 text-neutral-600">
                  Paid: {new Date().toLocaleTimeString('en-IN')}
                </div>
              )}

              {/* Powered by Gastrolabs Attribution */}
              <div className="text-center text-xs mt-3 pt-2 text-neutral-500" style={{ borderTop: '1px solid #e5e5e5' }}>
                POWERED BY GASTROLABS
              </div>
            </div>
          </div>

          {/* Footer Buttons */}
          <div className="p-4 bg-neutral-50 border-t flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
            <Button variant="outline" onClick={() => onOpenChange(false)} className="flex-1">
              Cancel
            </Button>
            <Button onClick={handlePrint} className="flex-1 bg-blue-600 hover:bg-blue-700">
              Print
            </Button>
          </div>
        </DialogPrimitive.Content>
      </DialogPortal>
    </Dialog>
  );
}