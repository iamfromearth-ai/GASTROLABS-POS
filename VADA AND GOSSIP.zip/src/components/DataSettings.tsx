import { useState } from 'react';
import { Button } from './ui/button';
import { ChevronLeft, Download, Upload, Trash2, Database } from 'lucide-react';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from './ui/alert-dialog';
import { PasswordDialog } from './PasswordDialog';

interface DataSettingsProps {
  onBack: () => void;
  onExportData: () => void;
  onImportData: () => void;
  onClearData: () => void;
}

export function DataSettings({ onBack, onExportData, onImportData, onClearData }: DataSettingsProps) {
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [showClearDialog, setShowClearDialog] = useState(false);
  const [pendingOperation, setPendingOperation] = useState<'import' | 'clear' | null>(null);

  // Check if password protection is enabled
  const isPasswordProtected = () => {
    return !!localStorage.getItem('adminPassword');
  };

  const handleImportClick = () => {
    if (isPasswordProtected()) {
      setPendingOperation('import');
      setShowPasswordDialog(true);
    } else {
      onImportData();
    }
  };

  const handleClearClick = () => {
    if (isPasswordProtected()) {
      setPendingOperation('clear');
      setShowPasswordDialog(true);
    } else {
      setShowClearDialog(true);
    }
  };

  const handlePasswordSuccess = () => {
    if (pendingOperation === 'import') {
      onImportData();
      setPendingOperation(null);
    } else if (pendingOperation === 'clear') {
      setShowClearDialog(true);
      setPendingOperation(null);
    }
  };

  const handleClearConfirm = () => {
    onClearData();
    setShowClearDialog(false);
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-3 flex items-center gap-3 shadow-lg">
        <Button
          onClick={onBack}
          variant="ghost"
          size="icon"
          className="text-white hover:bg-[#49842B]/10"
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-white font-semibold">Data Settings</h1>
      </div>

      <div className="flex-1 overflow-auto">
        {/* Backup & Restore */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-[#336A29]/15">
            <h2 className="text-[#336A29] font-semibold">Backup & Restore</h2>
          </div>

          <button
            onClick={onExportData}
            className="w-full px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15 hover:bg-[#80B155] transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-full flex items-center justify-center shadow-md">
                <Download className="h-5 w-5 text-white" />
              </div>
              <div className="text-left">
                <div className="text-[#336A29] font-medium">Export All Data</div>
                <div className="text-sm text-[#336A29]/70">Download items, orders & settings</div>
              </div>
            </div>
          </button>

          <button
            onClick={handleImportClick}
            className="w-full px-4 py-4 flex items-center justify-between hover:bg-[#80B155] transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-full flex items-center justify-center shadow-md">
                <Upload className="h-5 w-5 text-white" />
              </div>
              <div className="text-left">
                <div className="text-[#336A29] font-medium">Import Data</div>
                <div className="text-sm text-[#336A29]/70">Restore from backup file</div>
              </div>
            </div>
          </button>
        </div>

        {/* Storage Info */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-full flex items-center justify-center shadow-md">
              <Database className="h-5 w-5 text-white" />
            </div>
            <div>
              <h2 className="text-[#336A29] font-semibold">Storage Information</h2>
              <p className="text-sm text-[#336A29]/70">Data stored in browser</p>
            </div>
          </div>

          <div className="bg-[#80B155] rounded-lg p-3 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-white/80">Storage Type</span>
              <span className="text-white font-medium">Local Storage</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-white/80">Auto Save</span>
              <span className="text-white font-medium">Enabled</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-white/80">Sync Status</span>
              <span className="text-white font-medium">Browser Only</span>
            </div>
          </div>
        </div>

        {/* Danger Zone */}
        <div className="mt-4 mb-4 mx-4 bg-[#C1D95C] rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-[#336A29]/15">
            <h2 className="text-red-600 font-semibold">Danger Zone</h2>
          </div>

          <div className="p-4">
            <Button
              variant="destructive"
              className="w-full bg-red-600 hover:bg-red-700"
              onClick={handleClearClick}
            >
              <Trash2 className="h-5 w-5 mr-2" />
              Clear All Data
            </Button>

            <p className="text-sm text-[#336A29]/70 text-center mt-3">
              ⚠️ This will delete all items, orders, and settings permanently
            </p>
          </div>
        </div>
      </div>

      {/* Password Dialog */}
      <PasswordDialog
        open={showPasswordDialog}
        onOpenChange={setShowPasswordDialog}
        onSuccess={handlePasswordSuccess}
        title={`${pendingOperation === 'import' ? 'Import Data' : 'Clear All Data'} - Admin Password Required`}
        description={`Enter admin password to ${pendingOperation === 'import' ? 'import data' : 'clear all data'}`}
      />

      {/* Clear Confirmation Dialog */}
      <AlertDialog open={showClearDialog} onOpenChange={setShowClearDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete all your items, 
              categories, orders, and settings from this device. Make sure you have exported 
              your data first if you want to keep it.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleClearConfirm}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete Everything
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}