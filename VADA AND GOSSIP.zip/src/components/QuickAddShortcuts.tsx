import { Button } from './ui/button';
import { Zap } from 'lucide-react';
import { MenuItem } from '../App';

interface QuickAddShortcutsProps {
  items: MenuItem[];
  onAddItem: (item: MenuItem) => void;
}

export function QuickAddShortcuts({ items, onAddItem }: QuickAddShortcutsProps) {
  // Get most popular items (you can track this in database)
  // For now, just show first 4 items
  const quickItems = items.slice(0, 4);

  if (quickItems.length === 0) return null;

  return (
    <div className="mb-4">
      <div className="flex items-center gap-2 mb-2">
        <Zap className="h-4 w-4 text-[#49842B]" />
        <span className="text-sm font-medium text-[#336A29]">Quick Add (Popular Items)</span>
      </div>

      <div className="grid grid-cols-2 gap-2">
        {quickItems.map((item) => (
          <Button
            key={item.id}
            onClick={() => onAddItem(item)}
            className="bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white rounded-xl h-16 text-sm shadow-lg"
          >
            <div className="text-center">
              <div className="font-semibold">{item.name}</div>
              <div className="text-xs text-white/80">₹{item.price}</div>
            </div>
          </Button>
        ))}
      </div>
    </div>
  );
}
