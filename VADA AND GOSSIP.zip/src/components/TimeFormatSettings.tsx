import { useState } from 'react';
import { Button } from './ui/button';
import { ChevronLeft, Check } from 'lucide-react';
import { Label } from './ui/label';

const TIME_FORMATS = [
  { label: 'DD/MM/YYYY HH:MM', value: 'dd/MM/yyyy HH:mm', example: '23/10/2025 14:30' },
  { label: 'MM/DD/YYYY HH:MM', value: 'MM/dd/yyyy HH:mm', example: '10/23/2025 14:30' },
  { label: 'YYYY-MM-DD HH:MM', value: 'yyyy-MM-dd HH:mm', example: '2025-10-23 14:30' },
  { label: 'DD MMM YYYY HH:MM', value: 'dd MMM yyyy HH:mm', example: '23 Oct 2025 14:30' },
  { label: 'DD/MM/YYYY hh:mm A', value: 'dd/MM/yyyy hh:mm a', example: '23/10/2025 02:30 PM' },
  { label: 'MM/DD/YYYY hh:mm A', value: 'MM/dd/yyyy hh:mm a', example: '10/23/2025 02:30 PM' },
  { label: 'DD MMM YYYY hh:mm A', value: 'dd MMM yyyy hh:mm a', example: '23 Oct 2025 02:30 PM' },
  { label: 'DD.MM.YYYY HH.MM', value: 'dd.MM.yyyy HH.mm', example: '23.10.2025 14.30' },
  { label: 'DD MM YYYY HH.MM', value: 'dd MM yyyy HH.mm', example: '23 10 2025 14.30' },
];

interface TimeFormatSettingsProps {
  onBack: () => void;
  currentFormat: string;
  onUpdateFormat: (format: string) => void;
}

export function TimeFormatSettings({ onBack, currentFormat, onUpdateFormat }: TimeFormatSettingsProps) {
  const [selectedFormat, setSelectedFormat] = useState(currentFormat);

  const handleSelect = (format: string) => {
    setSelectedFormat(format);
    onUpdateFormat(format);
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-3 flex items-center gap-3 shadow-lg">
        <Button
          onClick={onBack}
          variant="ghost"
          size="icon"
          className="text-[#49842B] hover:bg-[#49842B]/10"
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-[#336A29] font-semibold">Time Format</h1>
      </div>

      <div className="flex-1 overflow-auto">
        {/* Info */}
        <div className="mt-4 bg-[#49842B]/10 border border-[#49842B]/30 p-4 mx-4 rounded-lg">
          <p className="text-sm text-[#336A29]">
            Select how date and time should appear on your receipts
          </p>
        </div>

        {/* Format List */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl overflow-hidden">
          {TIME_FORMATS.map((format) => (
            <button
              key={format.value}
              onClick={() => handleSelect(format.value)}
              className="w-full px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15 last:border-b-0 hover:bg-[#80B155] transition-colors"
            >
              <div className="text-left">
                <div className="text-[#336A29] font-medium">{format.label}</div>
                <div className="text-sm text-[#336A29]/70">{format.example}</div>
              </div>
              {selectedFormat === format.value && (
                <Check className="h-5 w-5 text-[#49842B]" />
              )}
            </button>
          ))}
        </div>

        {/* Current Selection */}
        <div className="mt-4 mb-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
          <Label className="text-[#336A29] mb-2 block font-semibold">Current Selection</Label>
          <div className="border border-[#336A29]/20 rounded-lg p-3 bg-[#80B155]/30">
            <div className="text-[#336A29] font-medium">
              {TIME_FORMATS.find(f => f.value === selectedFormat)?.label || selectedFormat}
            </div>
            <div className="text-sm text-[#336A29]/70 mt-1">
              Example: {TIME_FORMATS.find(f => f.value === selectedFormat)?.example || 'Custom format'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}