import { useState } from 'react';
import { Button } from './ui/button';
import { ChevronLeft } from 'lucide-react';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Switch } from './ui/switch';

export interface FooterConfig {
  enabled: boolean;
  text: string;
  showContactInfo: boolean;
  contactInfo: string;
}

interface FooterSettingsProps {
  onBack: () => void;
  settings: FooterConfig;
  onUpdateSettings: (settings: FooterConfig) => void;
}

export function FooterSettings({ onBack, settings, onUpdateSettings }: FooterSettingsProps) {
  const [config, setConfig] = useState<FooterConfig>(settings);

  const updateConfig = (key: keyof FooterConfig, value: any) => {
    const updated = { ...config, [key]: value };
    setConfig(updated);
    onUpdateSettings(updated);
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-3 flex items-center gap-3 shadow-lg">
        <Button
          onClick={onBack}
          variant="ghost"
          size="icon"
          className="text-[#49842B] hover:bg-[#49842B]/10"
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-[#336A29] font-semibold">Footer Settings</h1>
      </div>

      <div className="flex-1 overflow-auto">
        {/* Enable Footer */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-[#336A29] font-medium">Show Footer</div>
              <div className="text-sm text-[#336A29]/70">Display custom footer on receipts</div>
            </div>
            <Switch
              checked={config.enabled}
              onCheckedChange={(checked) => updateConfig('enabled', checked)}
            />
          </div>
        </div>

        {config.enabled && (
          <>
            {/* Footer Text */}
            <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
              <Label htmlFor="footer-text" className="text-[#336A29]">Footer Message</Label>
              <Textarea
                id="footer-text"
                value={config.text}
                onChange={(e) => updateConfig('text', e.target.value)}
                placeholder="Thank you for your visit!&#10;We appreciate your business."
                className="mt-2 min-h-[100px] bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
              />
              <p className="text-xs text-[#336A29]/70 mt-2">
                This message will appear at the bottom of every receipt
              </p>
            </div>

            {/* Contact Info */}
            <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-[#336A29] font-medium">Show Contact Info</div>
                  <div className="text-sm text-[#336A29]/70">Include phone/email in footer</div>
                </div>
                <Switch
                  checked={config.showContactInfo}
                  onCheckedChange={(checked) => updateConfig('showContactInfo', checked)}
                />
              </div>

              {config.showContactInfo && (
                <div className="mt-3">
                  <Label htmlFor="contact-info" className="text-[#336A29]">Contact Information</Label>
                  <Textarea
                    id="contact-info"
                    value={config.contactInfo}
                    onChange={(e) => updateConfig('contactInfo', e.target.value)}
                    placeholder="Phone: +91 98765 43210&#10;Email: teashop@example.com"
                    className="mt-2 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                  />
                </div>
              )}
            </div>

            {/* Preview */}
            <div className="mt-4 mb-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
              <Label className="text-[#336A29] mb-3 block font-semibold">Preview</Label>
              <div className="border border-[#336A29]/20 rounded-lg p-4 bg-[#80B155]/30">
                <div className="text-center space-y-2">
                  {config.text && (
                    <div className="text-sm text-[#336A29] whitespace-pre-wrap">
                      {config.text}
                    </div>
                  )}
                  {config.showContactInfo && config.contactInfo && (
                    <div className="text-xs text-[#336A29]/70 whitespace-pre-wrap border-t border-[#336A29]/30 pt-2 mt-2">
                      {config.contactInfo}
                    </div>
                  )}
                  {!config.text && !config.contactInfo && (
                    <div className="text-[#336A29]/50 text-sm">No footer content</div>
                  )}
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}