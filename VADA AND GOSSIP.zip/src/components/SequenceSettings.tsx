import { useState } from 'react';
import { Button } from './ui/button';
import { ChevronLeft } from 'lucide-react';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Switch } from './ui/switch';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';

export interface SequenceConfig {
  enabled: boolean;
  prefix: string;
  startNumber: number;
  format: 'number' | 'padded' | 'date-number';
  padding: number;
}

interface SequenceSettingsProps {
  onBack: () => void;
  settings: SequenceConfig;
  onUpdateSettings: (settings: SequenceConfig) => void;
}

export function SequenceSettings({ onBack, settings, onUpdateSettings }: SequenceSettingsProps) {
  const [config, setConfig] = useState<SequenceConfig>(settings);

  const updateConfig = (key: keyof SequenceConfig, value: any) => {
    const updated = { ...config, [key]: value };
    setConfig(updated);
    onUpdateSettings(updated);
  };

  const getExampleNumber = () => {
    const num = config.startNumber || 1;
    switch (config.format) {
      case 'number':
        return `${config.prefix}${num}`;
      case 'padded':
        return `${config.prefix}${String(num).padStart(config.padding, '0')}`;
      case 'date-number':
        const today = new Date().toISOString().split('T')[0].replace(/-/g, '');
        return `${config.prefix}${today}-${String(num).padStart(config.padding, '0')}`;
      default:
        return `${config.prefix}${num}`;
    }
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-3 flex items-center gap-3 shadow-lg">
        <Button
          onClick={onBack}
          variant="ghost"
          size="icon"
          className="text-[#49842B] hover:bg-[#49842B]/10"
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-[#336A29] font-semibold">Sequence Number</h1>
      </div>

      <div className="flex-1 overflow-auto">
        {/* Enable */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-[#336A29] font-medium">Receipt Numbering</div>
              <div className="text-sm text-[#336A29]/70">Auto-increment receipt numbers</div>
            </div>
            <Switch
              checked={config.enabled}
              onCheckedChange={(checked) => updateConfig('enabled', checked)}
            />
          </div>
        </div>

        {config.enabled && (
          <>
            {/* Prefix */}
            <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4 space-y-4">
              <div>
                <Label htmlFor="prefix" className="text-[#336A29]">Prefix</Label>
                <Input
                  id="prefix"
                  value={config.prefix}
                  onChange={(e) => updateConfig('prefix', e.target.value)}
                  placeholder="INV-"
                  className="mt-1 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                />
                <p className="text-xs text-[#336A29]/70 mt-1">
                  Letters or numbers to appear before the sequence number
                </p>
              </div>

              <div>
                <Label htmlFor="start-number" className="text-[#336A29]">Starting Number</Label>
                <Input
                  id="start-number"
                  type="number"
                  value={config.startNumber}
                  onChange={(e) => updateConfig('startNumber', parseInt(e.target.value) || 1)}
                  className="mt-1 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                />
                <p className="text-xs text-[#336A29]/70 mt-1">
                  The first receipt will use this number
                </p>
              </div>
            </div>

            {/* Format */}
            <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
              <Label className="text-[#336A29] mb-3 block font-semibold">Number Format</Label>
              <RadioGroup
                value={config.format}
                onValueChange={(value) => updateConfig('format', value)}
                className="space-y-3"
              >
                <div className="flex items-start justify-between p-3 border border-[#336A29]/20 rounded-lg hover:bg-[#80B155] transition-colors">
                  <div>
                    <div className="text-[#336A29] font-medium">Simple Number</div>
                    <div className="text-sm text-[#336A29]/70">Example: INV-1, INV-2, INV-3</div>
                  </div>
                  <RadioGroupItem value="number" />
                </div>

                <div className="flex items-start justify-between p-3 border border-[#336A29]/20 rounded-lg hover:bg-[#80B155] transition-colors">
                  <div className="flex-1">
                    <div className="text-[#336A29] font-medium">Padded Number</div>
                    <div className="text-sm text-[#336A29]/70">Example: INV-001, INV-002, INV-003</div>
                  </div>
                  <RadioGroupItem value="padded" />
                </div>

                <div className="flex items-start justify-between p-3 border border-[#336A29]/20 rounded-lg hover:bg-[#80B155] transition-colors">
                  <div>
                    <div className="text-[#336A29] font-medium">Date + Number</div>
                    <div className="text-sm text-[#336A29]/70">Example: INV-20251023-001</div>
                  </div>
                  <RadioGroupItem value="date-number" />
                </div>
              </RadioGroup>
            </div>

            {/* Padding */}
            {(config.format === 'padded' || config.format === 'date-number') && (
              <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
                <Label htmlFor="padding" className="text-[#336A29]">Number Padding</Label>
                <Input
                  id="padding"
                  type="number"
                  min="1"
                  max="10"
                  value={config.padding}
                  onChange={(e) => updateConfig('padding', parseInt(e.target.value) || 3)}
                  className="mt-1 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                />
                <p className="text-xs text-[#336A29]/70 mt-1">
                  How many digits (filled with zeros)
                </p>
              </div>
            )}

            {/* Preview */}
            <div className="mt-4 mb-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
              <Label className="text-[#336A29] mb-3 block font-semibold">Preview</Label>
              <div className="border border-[#336A29]/20 rounded-lg p-4 bg-[#80B155]/30">
                <div className="space-y-2">
                  <div className="text-sm text-[#336A29]/70">Next receipt numbers:</div>
                  <div className="font-mono text-[#336A29]">{getExampleNumber()}</div>
                  <div className="font-mono text-[#336A29]/70">
                    {config.format === 'number' && `${config.prefix}${(config.startNumber || 1) + 1}`}
                    {config.format === 'padded' && `${config.prefix}${String((config.startNumber || 1) + 1).padStart(config.padding, '0')}`}
                    {config.format === 'date-number' && `${config.prefix}${new Date().toISOString().split('T')[0].replace(/-/g, '')}-${String((config.startNumber || 1) + 1).padStart(config.padding, '0')}`}
                  </div>
                  <div className="font-mono text-[#336A29]/70">
                    {config.format === 'number' && `${config.prefix}${(config.startNumber || 1) + 2}`}
                    {config.format === 'padded' && `${config.prefix}${String((config.startNumber || 1) + 2).padStart(config.padding, '0')}`}
                    {config.format === 'date-number' && `${config.prefix}${new Date().toISOString().split('T')[0].replace(/-/g, '')}-${String((config.startNumber || 1) + 2).padStart(config.padding, '0')}`}
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}