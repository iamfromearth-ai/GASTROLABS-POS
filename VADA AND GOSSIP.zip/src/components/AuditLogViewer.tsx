import { Button } from './ui/button';
import { ChevronLeft, Shield, Download, AlertTriangle, AlertCircle } from 'lucide-react';
import { useEffect, useState } from 'react';
import { auditLogger, detectSuspiciousActivity } from '../lib/audit-logger';
import { isSupabaseConfigured } from '../lib/supabase';
import { toast } from 'sonner@2.0.3';

interface AuditLogViewerProps {
  onBack: () => void;
}

interface AuditLog {
  id: string;
  action: string;
  entity_type: string;
  entity_id: string;
  user_email: string;
  old_value: any;
  new_value: any;
  ip_address: string | null;
  created_at: string;
}

export function AuditLogViewer({ onBack }: AuditLogViewerProps) {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [suspiciousAlerts, setSuspiciousAlerts] = useState<string[]>([]);

  useEffect(() => {
    if (isSupabaseConfigured()) {
      loadLogs();
      checkSuspiciousActivity();
    } else {
      setLoading(false);
    }
  }, []);

  const loadLogs = async () => {
    setLoading(true);
    const recentLogs = await auditLogger.getRecentLogs(100);
    setLogs(recentLogs);
    setLoading(false);
  };

  const checkSuspiciousActivity = async () => {
    const { data: { user } } = await import('../lib/supabase').then(m => m.supabase.auth.getUser());
    if (user) {
      const { suspicious, alerts } = await detectSuspiciousActivity(user.id);
      if (suspicious) {
        setSuspiciousAlerts(alerts);
      }
    }
  };

  const handleExportLogs = () => {
    const csv = [
      ['Timestamp', 'User', 'Action', 'Entity Type', 'Entity ID', 'IP Address'].join(','),
      ...logs.map(log => [
        new Date(log.created_at).toLocaleString(),
        log.user_email,
        log.action,
        log.entity_type,
        log.entity_id,
        log.ip_address || 'N/A'
      ].join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `audit-logs-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    toast.success('Audit logs exported successfully!');
  };

  const getActionColor = (action: string) => {
    if (action.includes('deleted') || action.includes('voided')) {
      return 'text-red-600';
    }
    if (action.includes('created')) {
      return 'text-green-600';
    }
    if (action.includes('updated')) {
      return 'text-blue-600';
    }
    return 'text-[#336A29]';
  };

  const formatAction = (action: string) => {
    return action.split('.').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-6 py-3 flex items-center gap-3 shadow-lg">
        <Button onClick={onBack} variant="ghost" size="icon" className="text-white hover:bg-[#49842B]/10">
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <div className="flex-1">
          <h1 className="text-white font-semibold">Audit Logs</h1>
          <p className="text-xs text-white/80">Track all system activities</p>
        </div>
        <Button
          onClick={handleExportLogs}
          variant="outline"
          size="sm"
          className="border-[#49842B] text-[#49842B]"
        >
          <Download className="h-4 w-4 mr-2" />
          Export
        </Button>
      </div>

      <div className="flex-1 overflow-auto pb-6">
        {/* Suspicious Activity Alerts */}
        {suspiciousAlerts.length > 0 && (
          <div className="mt-4 mx-6 bg-red-50 border-2 border-red-500 rounded-2xl p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-6 w-6 text-red-600 flex-shrink-0 mt-1" />
              <div className="flex-1">
                <h3 className="font-semibold text-red-900 mb-2">⚠️ Suspicious Activity Detected</h3>
                {suspiciousAlerts.map((alert, idx) => (
                  <p key={idx} className="text-sm text-red-800 mb-1">{alert}</p>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Info Banner */}
        <div className="mt-4 mx-6 bg-[#C1D95C] rounded-2xl p-4">
          <div className="flex items-center gap-3">
            <Shield className="h-6 w-6 text-[#49842B]" />
            <div className="flex-1">
              <p className="text-[#336A29] font-medium">Fraud Prevention Active</p>
              <p className="text-xs text-[#336A29]/70">All activities are logged and monitored for security</p>
            </div>
          </div>
        </div>

        {/* Audit Logs */}
        {loading ? (
          <div className="mt-4 mx-6 text-center py-8">
            <div className="text-[#336A29]/70">Loading audit logs...</div>
          </div>
        ) : logs.length === 0 ? (
          <div className="mt-4 mx-6 text-center py-8">
            <Shield className="h-12 w-12 text-[#336A29]/40 mx-auto mb-3" />
            <p className="text-[#336A29]/70">No audit logs yet</p>
          </div>
        ) : (
          <div className="mt-4 mx-6 space-y-2">
            {logs.map((log) => (
              <div key={log.id} className="bg-[#C1D95C] rounded-xl p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <p className={`font-medium ${getActionColor(log.action)}`}>
                      {formatAction(log.action)}
                    </p>
                    <p className="text-sm text-[#336A29]/70">
                      {log.entity_type} • {log.entity_id.slice(0, 8)}...
                    </p>
                  </div>
                  <span className="text-xs text-[#336A29]/60">
                    {new Date(log.created_at).toLocaleTimeString()}
                  </span>
                </div>

                <div className="flex items-center gap-4 text-xs text-[#336A29]/70">
                  <span>👤 {log.user_email}</span>
                  {log.ip_address && (
                    <span>🌐 {log.ip_address}</span>
                  )}
                  <span>📅 {new Date(log.created_at).toLocaleDateString()}</span>
                </div>

                {/* Show value changes for updates */}
                {log.action.includes('updated') && log.old_value && log.new_value && (
                  <div className="mt-2 pt-2 border-t border-[#336A29]/10">
                    <details className="text-xs">
                      <summary className="cursor-pointer text-[#336A29]/70 hover:text-[#336A29]">
                        View Changes
                      </summary>
                      <div className="mt-2 space-y-1">
                        <div className="text-red-600">
                          - Old: {JSON.stringify(log.old_value).slice(0, 100)}
                        </div>
                        <div className="text-green-600">
                          + New: {JSON.stringify(log.new_value).slice(0, 100)}
                        </div>
                      </div>
                    </details>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Fraud Prevention Info */}
        <div className="mt-4 mx-6 bg-[#C1D95C] rounded-2xl p-4">
          <h3 className="text-[#336A29] font-semibold mb-3">🔒 Fraud Prevention Features</h3>
          <div className="space-y-2 text-sm text-[#336A29]/80">
            <p>✅ All orders saved to database before printing</p>
            <p>✅ Paid orders cannot be deleted (void only)</p>
            <p>✅ Complete audit trail of all actions</p>
            <p>✅ Suspicious activity detection</p>
            <p>✅ Daily settlement reports</p>
            <p>✅ IP address tracking</p>
          </div>
        </div>
      </div>
    </div>
  );
}