import { Button } from './ui/button';
import { ChevronLeft, ChevronRight, Receipt, Printer, Database, Music, Vibrate, Globe, Mail, MessageCircle, Lock, Store, Info, Shield, CreditCard, MapPin, BookOpen } from 'lucide-react';
import { Switch } from './ui/switch';

interface SettingsProps {
  onBack: () => void;
  onReceiptSettings: () => void;
  onPrinterSettings: () => void;
  onDataSettings: () => void;
  onLanguageSettings: () => void;
  onCurrencySettings: () => void;
  onEmailSettings: () => void;
  onMessageSettings: () => void;
  onPasswordSettings: () => void;
  onBrandingSettings: () => void;
  onAboutGastrolabs: () => void;
  onSubscriptionSettings: () => void;
  onAuditLogs: () => void;
  onSubdomainSettings: () => void;
  onSetupGuide: () => void;
  settings: AppSettings;
  onUpdateSettings: (settings: AppSettings) => void;
}

export interface AppSettings {
  sound: boolean;
  vibration: boolean;
  currency: string;
  sortManually: boolean;
  mergeSimilarItems: boolean;
}

export function Settings({
  onBack,
  onReceiptSettings,
  onPrinterSettings,
  onDataSettings,
  onLanguageSettings,
  onCurrencySettings,
  onEmailSettings,
  onMessageSettings,
  onPasswordSettings,
  onBrandingSettings,
  onAboutGastrolabs,
  onSubscriptionSettings,
  onAuditLogs,
  onSubdomainSettings,
  onSetupGuide,
  settings,
  onUpdateSettings,
}: SettingsProps) {
  const toggleSetting = (key: keyof AppSettings) => {
    onUpdateSettings({
      ...settings,
      [key]: !settings[key],
    });
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-6 py-3 flex items-center shadow-lg">
        <Button onClick={onBack} variant="ghost" size="icon" className="text-white hover:bg-[#49842B]/10 -ml-2">
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="flex-1 text-center text-white font-semibold">Settings</h1>
        <div className="w-10"></div>
      </div>

      {/* Settings List */}
      <div className="flex-1 overflow-auto">
        {/* Setup Guide - PROMINENT SETUP HELPER */}
        <div className="mt-4 bg-gradient-to-r from-[#80B155] to-[#49842B] rounded-2xl mx-6 border-2 border-[#336A29]/50 shadow-lg">
          <button
            onClick={onSetupGuide}
            className="w-full px-4 py-4 flex items-center justify-between hover:bg-white/10 transition-colors rounded-2xl"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-md">
                <BookOpen className="h-5 w-5 text-[#49842B]" />
              </div>
              <div className="text-left">
                <span className="text-white font-semibold block">Setup Guide</span>
                <span className="text-white/90 text-xs">Configure Supabase & Stripe</span>
              </div>
            </div>
            <ChevronRight className="h-5 w-5 text-white/80" />
          </button>
        </div>

        {/* Business Setup - NEW WHITE-LABEL SECTION */}
        <div className="mt-4 bg-gradient-to-r from-[#C1D95C] to-[#80B155] rounded-2xl mx-6 border-2 border-[#49842B]/30">
          <button
            onClick={onBrandingSettings}
            className="w-full px-4 py-4 flex items-center justify-between hover:bg-[#49842B]/10 transition-colors rounded-2xl"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center shadow-md">
                <Store className="h-5 w-5 text-white" />
              </div>
              <div className="text-left">
                <span className="text-[#336A29] font-semibold block">Business Branding</span>
                <span className="text-[#336A29]/70 text-xs">Customize your brand identity</span>
              </div>
            </div>
            <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
          </button>
        </div>

        {/* Receipts & Printer Section */}
        <div className="mt-4 bg-[#C1D95C] rounded-2xl mx-6">
          <button
            onClick={onReceiptSettings}
            className="w-full px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15 hover:bg-[#80B155] transition-colors rounded-t-2xl"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center shadow-md">
                <Receipt className="h-5 w-5 text-white" />
              </div>
              <span className="text-[#336A29] font-medium">Receipts Setting</span>
            </div>
            <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
          </button>

          <button
            onClick={onPrinterSettings}
            className="w-full px-4 py-4 flex items-center justify-between hover:bg-[#80B155] transition-colors rounded-b-2xl"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center shadow-md">
                <Printer className="h-5 w-5 text-white" />
              </div>
              <span className="text-[#336A29] font-medium">Printer settings</span>
            </div>
            <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
          </button>
        </div>

        {/* Data Section */}
        <div className="mt-4 bg-[#C1D95C] rounded-2xl mx-6">
          <button
            onClick={onDataSettings}
            className="w-full px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15 hover:bg-[#80B155] transition-colors rounded-t-2xl"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center shadow-md">
                <Database className="h-5 w-5 text-white" />
              </div>
              <span className="text-[#336A29] font-medium">Data Settings</span>
            </div>
            <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
          </button>

          <button
            onClick={onPasswordSettings}
            className="w-full px-4 py-4 flex items-center justify-between hover:bg-[#80B155] transition-colors rounded-b-2xl"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#FF8A65] to-[#FF7043] rounded-xl flex items-center justify-center shadow-md">
                <Lock className="h-5 w-5 text-white" />
              </div>
              <span className="text-[#336A29] font-medium">Password Protection</span>
            </div>
            <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
          </button>
        </div>

        {/* App Settings */}
        <div className="mt-4 bg-[#C1D95C] rounded-2xl mx-6">
          <div className="px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center shadow-md">
                <Music className="h-5 w-5 text-white" />
              </div>
              <span className="text-[#336A29] font-medium">Sound</span>
            </div>
            <Switch
              checked={settings.sound}
              onCheckedChange={() => toggleSetting('sound')}
            />
          </div>

          <div className="px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center shadow-md">
                <Vibrate className="h-5 w-5 text-white" />
              </div>
              <span className="text-[#336A29] font-medium">Vibration</span>
            </div>
            <Switch
              checked={settings.vibration}
              onCheckedChange={() => toggleSetting('vibration')}
            />
          </div>

          <button
            onClick={onLanguageSettings}
            className="w-full px-4 py-4 flex items-center justify-between hover:bg-[#80B155] transition-colors rounded-b-2xl"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center shadow-md">
                <Globe className="h-5 w-5 text-white" />
              </div>
              <span className="text-[#336A29] font-medium">Language</span>
            </div>
            <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
          </button>
        </div>

        {/* Currency & Sorting */}
        <div className="mt-4 bg-[#C1D95C] rounded-2xl mx-6">
          <button
            onClick={onCurrencySettings}
            className="w-full px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15 hover:bg-[#80B155] transition-colors rounded-t-2xl"
          >
            <span className="text-[#336A29] font-medium">Currency symbols</span>
            <div className="flex items-center gap-2">
              <span className="text-[#336A29]/70">{settings.currency}</span>
              <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
            </div>
          </button>

          <div className="px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15">
            <span className="text-[#336A29] font-medium">Sort manually</span>
            <Switch
              checked={settings.sortManually}
              onCheckedChange={() => toggleSetting('sortManually')}
            />
          </div>

          <div className="px-4 py-4 flex items-center justify-between hover:bg-[#80B155] transition-colors rounded-b-2xl">
            <span className="text-[#336A29] font-medium">Merge Similar Items</span>
            <Switch
              checked={settings.mergeSimilarItems}
              onCheckedChange={() => toggleSetting('mergeSimilarItems')}
            />
          </div>
        </div>

        {/* Communication */}
        <div className="mt-4 mb-4 bg-[#C1D95C] rounded-2xl mx-6">
          <button
            onClick={onEmailSettings}
            className="w-full px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15 hover:bg-[#80B155] transition-colors rounded-t-2xl"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center shadow-md">
                <Mail className="h-5 w-5 text-white" />
              </div>
              <span className="text-[#336A29] font-medium">Email</span>
            </div>
            <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
          </button>

          <button
            onClick={onMessageSettings}
            className="w-full px-4 py-4 flex items-center justify-between hover:bg-[#80B155] transition-colors rounded-b-2xl"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center shadow-md">
                <MessageCircle className="h-5 w-5 text-white" />
              </div>
              <span className="text-[#336A29] font-medium">iMessage</span>
            </div>
            <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
          </button>
        </div>

        {/* About Gastrolabs */}
        <div className="mt-4 bg-[#C1D95C] rounded-2xl mx-6">
          <button
            onClick={onAboutGastrolabs}
            className="w-full px-4 py-4 flex items-center justify-between hover:bg-[#80B155] transition-colors rounded-2xl"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center shadow-md">
                <Info className="h-5 w-5 text-white" />
              </div>
              <span className="text-[#336A29] font-medium">About Gastrolabs</span>
            </div>
            <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
          </button>
        </div>

        {/* Subscription Settings */}
        <div className="mt-4 bg-[#C1D95C] rounded-2xl mx-6">
          <button
            onClick={onSubscriptionSettings}
            className="w-full px-4 py-4 flex items-center justify-between hover:bg-[#80B155] transition-colors rounded-2xl"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center shadow-md">
                <CreditCard className="h-5 w-5 text-white" />
              </div>
              <span className="text-[#336A29] font-medium">Subscription Settings</span>
            </div>
            <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
          </button>
        </div>

        {/* Audit Logs */}
        <div className="mt-4 bg-[#C1D95C] rounded-2xl mx-6">
          <button
            onClick={onAuditLogs}
            className="w-full px-4 py-4 flex items-center justify-between hover:bg-[#80B155] transition-colors rounded-2xl"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center shadow-md">
                <Shield className="h-5 w-5 text-white" />
              </div>
              <span className="text-[#336A29] font-medium">Audit Logs</span>
            </div>
            <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
          </button>
        </div>

        {/* Subdomain Settings */}
        <div className="mt-4 bg-[#C1D95C] rounded-2xl mx-6">
          <button
            onClick={onSubdomainSettings}
            className="w-full px-4 py-4 flex items-center justify-between hover:bg-[#80B155] transition-colors rounded-2xl"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center shadow-md">
                <MapPin className="h-5 w-5 text-white" />
              </div>
              <span className="text-[#336A29] font-medium">Subdomain Settings</span>
            </div>
            <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
          </button>
        </div>
      </div>
    </div>
  );
}