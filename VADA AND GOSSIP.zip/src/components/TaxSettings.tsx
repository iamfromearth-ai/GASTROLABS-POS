import { useState } from 'react';
import { Button } from './ui/button';
import { ChevronLeft, Plus, Trash2 } from 'lucide-react';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Switch } from './ui/switch';

export interface TaxItem {
  id: string;
  name: string;
  rate: number;
  enabled: boolean;
}

export interface TaxConfig {
  enabled: boolean;
  taxes: TaxItem[];
  includedInPrice: boolean;
}

interface TaxSettingsProps {
  onBack: () => void;
  settings: TaxConfig;
  onUpdateSettings: (settings: TaxConfig) => void;
}

export function TaxSettings({ onBack, settings, onUpdateSettings }: TaxSettingsProps) {
  const [config, setConfig] = useState<TaxConfig>(settings);

  const updateConfig = (updates: Partial<TaxConfig>) => {
    const updated = { ...config, ...updates };
    setConfig(updated);
    onUpdateSettings(updated);
  };

  const addTax = () => {
    const newTax: TaxItem = {
      id: Date.now().toString(),
      name: 'Tax',
      rate: 0,
      enabled: true,
    };
    updateConfig({ taxes: [...config.taxes, newTax] });
  };

  const updateTax = (id: string, updates: Partial<TaxItem>) => {
    const taxes = config.taxes.map(tax =>
      tax.id === id ? { ...tax, ...updates } : tax
    );
    updateConfig({ taxes });
  };

  const deleteTax = (id: string) => {
    const taxes = config.taxes.filter(tax => tax.id !== id);
    updateConfig({ taxes });
  };

  const calculateTaxAmount = (subtotal: number) => {
    return config.taxes
      .filter(tax => tax.enabled)
      .reduce((sum, tax) => sum + (subtotal * tax.rate / 100), 0);
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-3 flex items-center gap-3 shadow-lg">
        <Button
          onClick={onBack}
          variant="ghost"
          size="icon"
          className="text-[#49842B] hover:bg-[#49842B]/10"
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-[#336A29] font-semibold">Tax Settings</h1>
      </div>

      <div className="flex-1 overflow-auto">
        {/* Enable Taxes */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-[#336A29] font-medium">Enable Taxes</div>
              <div className="text-sm text-[#336A29]/70">Apply tax to receipts</div>
            </div>
            <Switch
              checked={config.enabled}
              onCheckedChange={(checked) => updateConfig({ enabled: checked })}
            />
          </div>
        </div>

        {config.enabled && (
          <>
            {/* Tax Configuration */}
            <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-[#336A29] font-medium">Tax Included in Price</div>
                  <div className="text-sm text-[#336A29]/70">Tax is already in item prices</div>
                </div>
                <Switch
                  checked={config.includedInPrice}
                  onCheckedChange={(checked) => updateConfig({ includedInPrice: checked })}
                />
              </div>
            </div>

            {/* Tax Items */}
            <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl overflow-hidden">
              <div className="px-4 py-3 border-b border-[#336A29]/15 flex items-center justify-between">
                <Label className="text-[#336A29] font-semibold">Tax Items</Label>
                <Button
                  onClick={addTax}
                  size="sm"
                  className="bg-[#49842B] hover:bg-[#336A29]"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Add Tax
                </Button>
              </div>

              {config.taxes.length === 0 ? (
                <div className="p-8 text-center text-[#336A29]/50">
                  No taxes configured. Click "Add Tax" to create one.
                </div>
              ) : (
                config.taxes.map((tax) => (
                  <div key={tax.id} className="px-4 py-3 border-b border-[#336A29]/15">
                    <div className="flex items-center justify-between mb-2">
                      <Switch
                        checked={tax.enabled}
                        onCheckedChange={(checked) => updateTax(tax.id, { enabled: checked })}
                      />
                      <Button
                        onClick={() => deleteTax(tax.id)}
                        variant="ghost"
                        size="sm"
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <div className="space-y-2">
                      <Input
                        id={`tax-name-${tax.id}`}
                        name={`tax-name-${tax.id}`}
                        value={tax.name}
                        onChange={(e) => updateTax(tax.id, { name: e.target.value })}
                        placeholder="Tax name (e.g., GST, VAT)"
                        className="text-sm bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                      />
                      
                      <div className="flex items-center gap-2">
                        <Input
                          id={`tax-rate-${tax.id}`}
                          name={`tax-rate-${tax.id}`}
                          type="number"
                          step="0.01"
                          min="0"
                          max="100"
                          value={tax.rate}
                          onChange={(e) => updateTax(tax.id, { rate: parseFloat(e.target.value) || 0 })}
                          placeholder="Rate"
                          className="text-sm bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                        />
                        <span className="text-[#336A29] font-medium">%</span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Preview */}
            <div className="mt-4 mb-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
              <Label className="text-[#336A29] mb-3 block font-semibold">Preview (on Rs 100 subtotal)</Label>
              <div className="border border-[#336A29]/20 rounded-lg p-4 bg-[#80B155]/30 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-[#336A29]/70">Subtotal</span>
                  <span className="text-[#336A29]">Rs 100.00</span>
                </div>
                
                {config.taxes.filter(t => t.enabled).map(tax => (
                  <div key={tax.id} className="flex justify-between text-sm">
                    <span className="text-[#336A29]/70">{tax.name} ({tax.rate}%)</span>
                    <span className="text-[#336A29]">Rs {(100 * tax.rate / 100).toFixed(2)}</span>
                  </div>
                ))}
                
                <div className="border-t border-[#336A29]/30 pt-2 flex justify-between">
                  <span className="text-[#336A29] font-semibold">Total</span>
                  <span className="text-[#336A29] font-semibold">
                    Rs {(100 + calculateTaxAmount(100)).toFixed(2)}
                  </span>
                </div>

                {config.includedInPrice && (
                  <div className="text-xs text-[#336A29]/70 text-center mt-2">
                    Note: Tax is included in the total, not added separately
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}