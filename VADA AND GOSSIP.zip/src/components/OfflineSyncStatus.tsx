import { WifiOff, Wifi, Cloud, CloudOff, RefreshCw } from 'lucide-react';
import { useState, useEffect } from 'react';
import { offlineSyncManager } from '../lib/offline-sync';
import { Button } from './ui/button';

export function OfflineSyncStatus() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [pendingCount, setPendingCount] = useState(0);
  const [syncing, setSyncing] = useState(false);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Update pending count periodically
    const interval = setInterval(() => {
      setPendingCount(offlineSyncManager.getPendingCount());
    }, 1000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
    };
  }, []);

  const handleSync = async () => {
    setSyncing(true);
    await offlineSyncManager.syncAll();
    setPendingCount(offlineSyncManager.getPendingCount());
    setSyncing(false);
  };

  if (isOnline && pendingCount === 0) {
    // All synced - minimal indicator
    return (
      <div className="flex items-center gap-2 text-xs text-[#49842B]">
        <Cloud className="h-3 w-3" />
        <span>Synced</span>
      </div>
    );
  }

  if (!isOnline) {
    // Offline mode
    return (
      <div className="bg-amber-500/20 border border-amber-500 rounded-lg px-3 py-2 flex items-center gap-2">
        <WifiOff className="h-4 w-4 text-amber-700" />
        <div className="flex-1">
          <p className="text-xs font-medium text-amber-900">Offline Mode</p>
          {pendingCount > 0 && (
            <p className="text-xs text-amber-700">{pendingCount} pending sync</p>
          )}
        </div>
      </div>
    );
  }

  // Online with pending sync
  return (
    <div className="bg-blue-50 border border-blue-300 rounded-lg px-3 py-2 flex items-center gap-2">
      <CloudOff className="h-4 w-4 text-blue-700" />
      <div className="flex-1">
        <p className="text-xs font-medium text-blue-900">Syncing...</p>
        <p className="text-xs text-blue-700">{pendingCount} items pending</p>
      </div>
      <Button
        onClick={handleSync}
        size="sm"
        variant="ghost"
        className="h-6 w-6 p-0"
        disabled={syncing}
      >
        <RefreshCw className={`h-3 w-3 text-blue-700 ${syncing ? 'animate-spin' : ''}`} />
      </Button>
    </div>
  );
}
