import { useState } from 'react';
import { Switch } from './ui/switch';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { QRCodeConfig } from './QRCodeSettings';
import { PaymentQRConfig } from './PaymentQRSettings';
import { toast } from 'sonner@2.0.3';
import { Label } from './ui/label';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { PrintPreview } from './PrintPreview';

// Import correct types from their source files to avoid mismatches
import type { LogoConfig } from './LogoSettings';
import type { FooterConfig } from './FooterSettings';
import type { BusinessInfo } from './BusinessIdentity';
import type { SequenceConfig } from './SequenceSettings';
import type { TaxConfig } from './TaxSettings';
import type { DiscountConfig } from './DiscountSettings';
import type { FeesConfig } from './FeesSettings';

// Re-export for other components
export type { LogoConfig, FooterConfig, BusinessInfo, SequenceConfig, TaxConfig, DiscountConfig, FeesConfig, QRCodeConfig };

// BillItem type for test printing
interface BillItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  category: string;
}

interface ReceiptSettingsProps {
  onBack: () => void;
  onLogoSettings: () => void;
  onFooterSettings: () => void;
  onTimeFormatSettings: () => void;
  onBusinessIdentity: () => void;
  onSequenceSettings: () => void;
  onTaxSettings: () => void;
  onDiscountSettings: () => void;
  onFeesSettings: () => void;
  onQRCodeSettings: () => void;
  onPaymentQRSettings: () => void;
  settings: ReceiptConfig;
  onUpdateSettings: (settings: ReceiptConfig) => void;
}

export interface ReceiptConfig {
  header: string;
  showCustomer: boolean;
  showTotalQty: boolean;
  showSubtotal: boolean;
  showPaymentMethods: boolean;
  showCash: boolean;
  showChange: boolean;
  showGrandTotal: boolean;
  showPaidTime: boolean;
  showWatermark: boolean;
  timeFormat: string;
  logo: LogoConfig;
  footer: FooterConfig;
  business: BusinessInfo;
  sequence: SequenceConfig;
  tax: TaxConfig;
  discount: DiscountConfig;
  fees: FeesConfig;
  qrCode: QRCodeConfig;
  paymentQR: PaymentQRConfig;
}

export function ReceiptSettings({ 
  onBack, 
  onLogoSettings,
  onFooterSettings,
  onTimeFormatSettings,
  onBusinessIdentity,
  onSequenceSettings,
  onTaxSettings,
  onDiscountSettings,
  onFeesSettings,
  onQRCodeSettings,
  onPaymentQRSettings,
  settings, 
  onUpdateSettings 
}: ReceiptSettingsProps) {
  const [showTestPreview, setShowTestPreview] = useState(false);
  
  const toggleSetting = (key: keyof ReceiptConfig) => {
    onUpdateSettings({
      ...settings,
      [key]: !settings[key],
    });
    toast.success('✅ Setting updated!');
  };

  const updateHeader = (header: string) => {
    onUpdateSettings({
      ...settings,
      header,
    });
    toast.success('✅ Header updated!');
  };

  // Test data for print preview
  const testItems: BillItem[] = [
    { id: '1', name: 'Regular Tea', price: 10, quantity: 2, category: 'Tea' },
    { id: '2', name: 'Samosa', price: 20, quantity: 1, category: 'Snacks' },
    { id: '3', name: 'Coffee', price: 15, quantity: 1, category: 'Beverages' },
  ];
  const testTotal = 55;
  const testOrderId = `TEST-${Date.now().toString().slice(-6)}`;

  const handlePrintTest = () => {
    setShowTestPreview(true);
    toast.success('Opening test receipt preview...');
  };

  const handleActualPrint = () => {
    // Close the preview dialog
    setShowTestPreview(false);
    
    // Create a print-friendly version of the receipt in a new window
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      toast.error('Please allow popups to print test receipts');
      return;
    }

    const printContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Test Receipt</title>
          <style>
            body {
              font-family: monospace;
              width: 80mm;
              margin: 0 auto;
              padding: 10px;
            }
            .center { text-align: center; }
            .bold { font-weight: bold; }
            .divider {
              border-top: 1px dashed #000;
              margin: 8px 0;
            }
            table {
              width: 100%;
              font-size: 12px;
            }
            @media print {
              body { padding: 0; }
            }
          </style>
        </head>
        <body>
          <div class="center bold">TEST RECEIPT</div>
          <div class="center">This is a test print</div>
          <div class="divider"></div>
          <table>
            <tr>
              <td>Regular Tea x2</td>
              <td style="text-align: right;">₹20</td>
            </tr>
            <tr>
              <td>Samosa x1</td>
              <td style="text-align: right;">₹20</td>
            </tr>
            <tr>
              <td>Coffee x1</td>
              <td style="text-align: right;">₹15</td>
            </tr>
          </table>
          <div class="divider"></div>
          <div style="text-align: right; font-weight: bold;">TOTAL: ₹55</div>
          <div class="divider"></div>
          <div class="center">Thank you!</div>
          <div class="center" style="font-size: 10px; margin-top: 10px;">POWERED BY GASTROLABS</div>
        </body>
      </html>
    `;

    printWindow.document.write(printContent);
    printWindow.document.close();
    
    // Wait for content to load, then print
    printWindow.onload = () => {
      setTimeout(() => {
        printWindow.print();
        toast.success('📄 Test receipt sent to printer!');
      }, 250);
    };
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-3 flex items-center justify-between shadow-lg">
        <div className="flex items-center">
          <Button onClick={onBack} variant="ghost" size="icon" className="text-[#49842B] hover:bg-[#49842B]/10 -ml-2">
            <ChevronLeft className="h-6 w-6" />
          </Button>
          <h1 className="text-[#336A29] font-semibold">Receipts Setting</h1>
        </div>
        <Button
          onClick={handlePrintTest}
          variant="ghost"
          className="text-[#49842B] hover:bg-[#49842B]/10"
        >
          Print Test
        </Button>
      </div>

      {/* Settings List */}
      <div className="flex-1 overflow-auto">
        {/* Header */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl overflow-hidden">
          <div className="px-4 py-4 border-b border-[#336A29]/15">
            <Label htmlFor="receipt-header" className="text-[#336A29] font-medium mb-2">Header</Label>
            <Input
              id="receipt-header"
              name="receipt-header"
              value={settings.header}
              onChange={(e) => updateHeader(e.target.value)}
              placeholder="Tea Shop"
              className="bg-[#80B155] border-[#336A29]/20 text-[#336A29] placeholder:text-[#336A29]/60 focus:border-[#49842B] rounded-xl mt-2"
            />
          </div>

          <div className="px-4 py-4 flex items-center justify-between">
            <span className="text-[#336A29] font-medium">Customer</span>
            <Switch
              checked={settings.showCustomer}
              onCheckedChange={() => toggleSetting('showCustomer')}
            />
          </div>
        </div>

        {/* Locked Features */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl overflow-hidden">
          <button 
            onClick={onBusinessIdentity}
            className="w-full px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15 hover:bg-[#80B155] transition-colors"
          >
            <span className="text-[#336A29] font-medium">Identity</span>
            <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
          </button>

          <button 
            onClick={onSequenceSettings}
            className="w-full px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15 hover:bg-[#80B155] transition-colors"
          >
            <span className="text-[#336A29] font-medium">Sequence NO.</span>
            <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
          </button>

          <button className="w-full px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15 hover:bg-[#80B155] transition-colors" onClick={onLogoSettings}>
            <span className="text-[#336A29] font-medium">LOGO</span>
            <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
          </button>

          <button 
            onClick={onTaxSettings}
            className="w-full px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15 hover:bg-[#80B155] transition-colors"
          >
            <span className="text-[#336A29] font-medium">Taxes</span>
            <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
          </button>

          <button 
            onClick={onDiscountSettings}
            className="w-full px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15 hover:bg-[#80B155] transition-colors"
          >
            <span className="text-[#336A29] font-medium">Discount</span>
            <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
          </button>

          <button 
            onClick={onFeesSettings}
            className="w-full px-4 py-4 flex items-center justify-between hover:bg-[#80B155] transition-colors"
          >
            <span className="text-[#336A29] font-medium">Other Fees</span>
            <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
          </button>
        </div>

        {/* Receipt Display Options */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl overflow-hidden">
          <div className="px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15">
            <span className="text-[#336A29] font-medium">TOTAL QTY</span>
            <Switch
              checked={settings.showTotalQty}
              onCheckedChange={() => toggleSetting('showTotalQty')}
            />
          </div>

          <div className="px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15">
            <span className="text-[#336A29] font-medium">Subtotal</span>
            <Switch
              checked={settings.showSubtotal}
              onCheckedChange={() => toggleSetting('showSubtotal')}
            />
          </div>

          <div className="px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15">
            <span className="text-[#336A29] font-medium">Payment methods</span>
            <Switch
              checked={settings.showPaymentMethods}
              onCheckedChange={() => toggleSetting('showPaymentMethods')}
            />
          </div>

          <div className="px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15">
            <span className="text-[#336A29] font-medium">Cash</span>
            <Switch
              checked={settings.showCash}
              onCheckedChange={() => toggleSetting('showCash')}
            />
          </div>

          <div className="px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15">
            <span className="text-[#336A29] font-medium">Change</span>
            <Switch
              checked={settings.showChange}
              onCheckedChange={() => toggleSetting('showChange')}
            />
          </div>

          <div className="px-4 py-4 flex items-center justify-between">
            <span className="text-[#336A29] font-medium">Grand Total</span>
            <Switch
              checked={settings.showGrandTotal}
              onCheckedChange={() => toggleSetting('showGrandTotal')}
            />
          </div>
        </div>

        {/* Footer Options */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl overflow-hidden">
          <button className="w-full px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15 hover:bg-[#80B155] transition-colors" onClick={onFooterSettings}>
            <span className="text-[#336A29] font-medium">Footer</span>
            <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
          </button>

          <button 
            onClick={onQRCodeSettings}
            className="w-full px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15 hover:bg-[#80B155] transition-colors"
          >
            <span className="text-[#336A29] font-medium">QR code</span>
            <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
          </button>

          <button 
            onClick={onPaymentQRSettings}
            className="w-full px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15 hover:bg-[#80B155] transition-colors"
          >
            <span className="text-[#336A29] font-medium">Payment QR code</span>
            <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
          </button>

          <div className="px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15">
            <span className="text-[#336A29] font-medium">Paid Time</span>
            <Switch
              checked={settings.showPaidTime}
              onCheckedChange={() => toggleSetting('showPaidTime')}
            />
          </div>

          <div className="px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15">
            <span className="text-[#336A29] font-medium">Watermark</span>
            <Switch
              checked={settings.showWatermark}
              onCheckedChange={() => toggleSetting('showWatermark')}
            />
          </div>

          <button className="w-full px-4 py-4 flex items-center justify-between hover:bg-[#80B155] transition-colors" onClick={onTimeFormatSettings}>
            <span className="text-[#336A29] font-medium">Time Format</span>
            <div className="flex items-center gap-2">
              <span className="text-neutral-500">{settings.timeFormat}</span>
              <ChevronRight className="h-5 w-5 text-[#336A29]/60" />
            </div>
          </button>
        </div>

        <div className="h-8"></div>
      </div>

      {/* Print Preview Dialog */}
      {showTestPreview && (
        <PrintPreview
          open={showTestPreview}
          onOpenChange={setShowTestPreview}
          items={testItems}
          total={testTotal}
          config={settings}
          onPrint={handleActualPrint}
          orderId={testOrderId}
        />
      )}
    </div>
  );
}