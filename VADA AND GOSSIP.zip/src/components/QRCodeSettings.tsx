import { useState } from 'react';
import { Button } from './ui/button';
import { ChevronLeft, QrCode } from 'lucide-react';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Switch } from './ui/switch';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';

export interface QRCodeConfig {
  enabled: boolean;
  type: 'upi' | 'url' | 'text';
  upiId: string;
  url: string;
  text: string;
  size: 'small' | 'medium' | 'large';
  label: string;
}

interface QRCodeSettingsProps {
  onBack: () => void;
  settings: QRCodeConfig;
  onUpdateSettings: (settings: QRCodeConfig) => void;
}

export function QRCodeSettings({ onBack, settings, onUpdateSettings }: QRCodeSettingsProps) {
  const [config, setConfig] = useState<QRCodeConfig>(settings);

  const updateConfig = (key: keyof QRCodeConfig, value: any) => {
    const updated = { ...config, [key]: value };
    setConfig(updated);
    onUpdateSettings(updated);
  };

  const getQRContent = () => {
    switch (config.type) {
      case 'upi':
        return config.upiId ? `upi://pay?pa=${config.upiId}` : '';
      case 'url':
        return config.url;
      case 'text':
        return config.text;
      default:
        return '';
    }
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-3 flex items-center gap-3 shadow-lg">
        <Button
          onClick={onBack}
          variant="ghost"
          size="icon"
          className="text-[#49842B] hover:bg-[#49842B]/10"
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-[#336A29] font-semibold">QR Code Settings</h1>
      </div>

      <div className="flex-1 overflow-auto">
        {/* Enable QR Code */}
        <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-[#336A29] font-medium">Show QR Code</div>
              <div className="text-sm text-[#336A29]/70">Display QR code on receipts</div>
            </div>
            <Switch
              checked={config.enabled}
              onCheckedChange={(checked) => updateConfig('enabled', checked)}
            />
          </div>
        </div>

        {config.enabled && (
          <>
            {/* QR Code Type */}
            <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
              <Label className="text-[#336A29] mb-3 block font-semibold">QR Code Type</Label>
              <RadioGroup
                value={config.type}
                onValueChange={(value) => updateConfig('type', value)}
                className="space-y-2"
              >
                <div className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg hover:bg-[#80B155] transition-colors">
                  <div>
                    <div className="text-[#336A29] font-medium">UPI Payment</div>
                    <div className="text-sm text-[#336A29]/70">For digital payments</div>
                  </div>
                  <RadioGroupItem value="upi" />
                </div>
                <div className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg hover:bg-[#80B155] transition-colors">
                  <div>
                    <div className="text-[#336A29] font-medium">Website URL</div>
                    <div className="text-sm text-[#336A29]/70">Link to your website</div>
                  </div>
                  <RadioGroupItem value="url" />
                </div>
                <div className="flex items-center justify-between p-3 border border-[#336A29]/20 rounded-lg hover:bg-[#80B155] transition-colors">
                  <div>
                    <div className="text-[#336A29] font-medium">Custom Text</div>
                    <div className="text-sm text-[#336A29]/70">Any text or data</div>
                  </div>
                  <RadioGroupItem value="text" />
                </div>
              </RadioGroup>
            </div>

            {/* Content Input */}
            <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4 space-y-4">
              {config.type === 'upi' && (
                <div>
                  <Label htmlFor="upi-id" className="text-[#336A29]">UPI ID</Label>
                  <Input
                    id="upi-id"
                    value={config.upiId}
                    onChange={(e) => updateConfig('upiId', e.target.value)}
                    placeholder="yourname@paytm"
                    className="mt-1 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                  />
                  <p className="text-xs text-[#336A29]/70 mt-1">
                    Enter your UPI ID (e.g., 9876543210@paytm, name@okaxis)
                  </p>
                </div>
              )}

              {config.type === 'url' && (
                <div>
                  <Label htmlFor="url" className="text-[#336A29]">Website URL</Label>
                  <Input
                    id="url"
                    type="url"
                    value={config.url}
                    onChange={(e) => updateConfig('url', e.target.value)}
                    placeholder="https://www.teashop.com"
                    className="mt-1 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                  />
                  <p className="text-xs text-[#336A29]/70 mt-1">
                    Enter full URL including https://
                  </p>
                </div>
              )}

              {config.type === 'text' && (
                <div>
                  <Label htmlFor="text" className="text-[#336A29]">Custom Text</Label>
                  <Textarea
                    id="text"
                    value={config.text}
                    onChange={(e) => updateConfig('text', e.target.value)}
                    placeholder="Enter any text, contact info, or data"
                    className="mt-1 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                  />
                </div>
              )}

              <div>
                <Label htmlFor="label" className="text-[#336A29]">QR Code Label</Label>
                <Input
                  id="label"
                  value={config.label}
                  onChange={(e) => updateConfig('label', e.target.value)}
                  placeholder="Scan to Pay / Visit Us"
                  className="mt-1 bg-[#80B155] border-[#336A29]/20 text-white placeholder:text-white/70"
                />
              </div>
            </div>

            {/* Size */}
            <div className="mt-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
              <Label className="text-[#336A29] mb-3 block font-semibold">QR Code Size</Label>
              <RadioGroup
                value={config.size}
                onValueChange={(value) => updateConfig('size', value)}
                className="space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[#336A29] font-medium">Small</span>
                  <RadioGroupItem value="small" />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#336A29] font-medium">Medium</span>
                  <RadioGroupItem value="medium" />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#336A29] font-medium">Large</span>
                  <RadioGroupItem value="large" />
                </div>
              </RadioGroup>
            </div>

            {/* Preview */}
            <div className="mt-4 mb-4 mx-4 bg-[#C1D95C] rounded-2xl p-4">
              <Label className="text-[#336A29] mb-3 block font-semibold">Preview</Label>
              <div className="border border-[#336A29]/20 rounded-lg p-6 flex flex-col items-center bg-[#80B155]/30">
                {getQRContent() ? (
                  <>
                    <div className={`bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-lg flex items-center justify-center shadow-md ${
                      config.size === 'small' ? 'w-24 h-24' :
                      config.size === 'medium' ? 'w-32 h-32' :
                      'w-40 h-40'
                    }`}>
                      <QrCode className="text-white w-1/2 h-1/2" />
                    </div>
                    {config.label && (
                      <div className="text-sm text-[#336A29] text-center mt-3 font-medium">
                        {config.label}
                      </div>
                    )}
                    <div className="text-xs text-[#336A29]/70 text-center mt-2 max-w-full break-all">
                      {getQRContent().substring(0, 50)}
                      {getQRContent().length > 50 ? '...' : ''}
                    </div>
                  </>
                ) : (
                  <div className="text-[#336A29]/50">Configure QR code content</div>
                )}
              </div>
            </div>
          </>
        )}

        {/* Info */}
        <div className="mt-4 mb-4 bg-[#49842B]/10 border border-[#49842B]/30 p-4 mx-4 rounded-lg">
          <p className="text-sm text-[#336A29]">
            📱 Note: This is a placeholder. In production, a real QR code will be generated from your data.
          </p>
        </div>
      </div>
    </div>
  );
}