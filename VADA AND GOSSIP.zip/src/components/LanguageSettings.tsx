import { useState } from 'react';
import { Button } from './ui/button';
import { ChevronLeft, Check } from 'lucide-react';
import { Input } from './ui/input';

export type Language = 'en' | 'hi' | 'mr' | 'ta' | 'te' | 'bn' | 'gu' | 'kn' | 'ml' | 'pa';

interface LanguageOption {
  code: Language;
  name: string;
  nativeName: string;
}

const LANGUAGES: LanguageOption[] = [
  { code: 'en', name: 'English', nativeName: 'English' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी' },
  { code: 'mr', name: 'Marathi', nativeName: 'मराठी' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்' },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు' },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা' },
  { code: 'gu', name: 'Gujarati', nativeName: 'ગુજરાતી' },
  { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ' },
  { code: 'ml', name: 'Malayalam', nativeName: 'മലയാളം' },
  { code: 'pa', name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ' },
];

interface LanguageSettingsProps {
  onBack: () => void;
  currentLanguage: Language;
  onUpdateLanguage: (language: Language) => void;
}

export function LanguageSettings({ onBack, currentLanguage, onUpdateLanguage }: LanguageSettingsProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredLanguages = LANGUAGES.filter(
    (lang) =>
      lang.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lang.nativeName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-4 py-3 flex items-center gap-3 shadow-lg">
        <Button
          onClick={onBack}
          variant="ghost"
          size="icon"
          className="text-[#49842B] hover:bg-[#49842B]/10"
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-[#336A29] font-semibold">Language</h1>
      </div>

      {/* Search */}
      <div className="bg-[#C1D95C] px-4 py-3 border-b border-[#336A29]/15">
        <Input
          id="language-search"
          name="language-search"
          type="text"
          placeholder="Search languages..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="bg-[#80B155] border-[#336A29]/20 text-[#336A29] placeholder:text-[#336A29]/60 focus:border-[#49842B] rounded-xl"
        />
      </div>

      {/* Language List */}
      <div className="flex-1 overflow-auto bg-[#EAEF9D]">
        {filteredLanguages.map((lang) => (
          <button
            key={lang.code}
            onClick={() => onUpdateLanguage(lang.code)}
            className="w-full px-4 py-4 flex items-center justify-between border-b border-[#336A29]/15 hover:bg-[#C1D95C] transition-colors"
          >
            <div className="text-left">
              <div className="text-[#336A29] font-medium">{lang.name}</div>
              <div className="text-sm text-[#336A29]/70">{lang.nativeName}</div>
            </div>
            {currentLanguage === lang.code && (
              <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#49842B] to-[#336A29] flex items-center justify-center shadow-md">
                <Check className="h-4 w-4 text-white" />
              </div>
            )}
          </button>
        ))}
      </div>

      {/* Note */}
      <div className="bg-[#C1D95C] px-4 py-3 border-t border-[#336A29]/15">
        <p className="text-sm text-[#336A29]/70 text-center">
          📝 Language support is currently limited to English. Other languages will be available in future updates.
        </p>
      </div>
    </div>
  );
}