import { Button } from './ui/button';
import { ChevronLeft, Crown, Zap, Building2, Check, AlertCircle } from 'lucide-react';
import { subscriptionPlans, formatPrice, createCheckoutSession, createPortalSession } from '../lib/stripe-integration';
import { useState, useEffect } from 'react';
import { supabase, getCurrentTenant, isSupabaseConfigured } from '../lib/supabase';
import { toast } from 'sonner@2.0.3';

interface SubscriptionManagerProps {
  onBack: () => void;
}

export function SubscriptionManager({ onBack }: SubscriptionManagerProps) {
  const [currentTier, setCurrentTier] = useState<'free' | 'pro' | 'enterprise'>('free');
  const [loading, setLoading] = useState(false);
  const [tenantId, setTenantId] = useState<string>('');

  useEffect(() => {
    loadCurrentSubscription();
  }, []);

  const loadCurrentSubscription = async () => {
    if (!isSupabaseConfigured()) {
      // Demo mode - stay on free tier
      return;
    }
    
    const tenant = await getCurrentTenant();
    if (tenant) {
      setCurrentTier(tenant.subscription_tier);
      setTenantId(tenant.id);
    }
  };

  const handleUpgrade = async (planId: string) => {
    const plan = subscriptionPlans.find(p => p.id === planId);
    if (!plan || !tenantId) return;

    if (plan.price === 0) {
      toast.info('You are already on the Free plan');
      return;
    }

    setLoading(true);

    try {
      await createCheckoutSession(
        plan.stripePriceId,
        tenantId,
        window.location.origin + '?subscription_success=true',
        window.location.origin + '?subscription_cancelled=true'
      );
    } catch (error) {
      toast.error('Failed to start checkout. Please try again.');
      setLoading(false);
    }
  };

  const handleManageSubscription = async () => {
    if (!tenantId) return;

    setLoading(true);

    try {
      await createPortalSession(tenantId, window.location.origin);
    } catch (error) {
      toast.error('Failed to open billing portal. Please try again.');
      setLoading(false);
    }
  };

  const getTierIcon = (tier: string) => {
    switch (tier) {
      case 'free':
        return <Zap className="h-8 w-8 text-[#49842B]" />;
      case 'pro':
        return <Crown className="h-8 w-8 text-[#49842B]" />;
      case 'enterprise':
        return <Building2 className="h-8 w-8 text-[#49842B]" />;
      default:
        return <Zap className="h-8 w-8 text-[#49842B]" />;
    }
  };

  const isCurrentPlan = (tier: string) => {
    return tier === currentTier;
  };

  return (
    <div className="h-screen bg-[#EAEF9D] flex flex-col">
      {/* Header */}
      <div className="bg-[#C1D95C] border-b border-[#336A29]/15 px-6 py-3 flex items-center gap-3 shadow-lg">
        <Button onClick={onBack} variant="ghost" size="icon" className="text-[#49842B] hover:bg-[#49842B]/10">
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <div className="flex-1">
          <h1 className="text-[#336A29] font-semibold">Subscription Plans</h1>
          <p className="text-xs text-[#336A29]/70">Choose the plan that fits your business</p>
        </div>
      </div>

      <div className="flex-1 overflow-auto pb-6">
        {/* Current Plan Banner */}
        {currentTier !== 'free' && (
          <div className="mt-4 mx-6 bg-gradient-to-r from-[#49842B] to-[#336A29] rounded-2xl p-4 text-white">
            <div className="flex items-center gap-3">
              {getTierIcon(currentTier)}
              <div className="flex-1">
                <p className="font-semibold">Current Plan: {currentTier.toUpperCase()}</p>
                <p className="text-sm text-white/80">Your subscription is active</p>
              </div>
              <Button
                onClick={handleManageSubscription}
                variant="outline"
                className="bg-white text-[#49842B] hover:bg-white/90"
                disabled={loading}
              >
                Manage
              </Button>
            </div>
          </div>
        )}

        {/* Free Plan */}
        <div className="mt-4 mx-6">
          <div className={`bg-[#C1D95C] rounded-2xl p-6 border-2 ${isCurrentPlan('free') ? 'border-[#49842B]' : 'border-transparent'}`}>
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center">
                  <Zap className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-[#336A29] font-bold text-lg">Free Plan</h3>
                  <p className="text-[#336A29]/70 text-sm">Perfect for getting started</p>
                </div>
              </div>
              {isCurrentPlan('free') && (
                <span className="bg-[#49842B] text-white text-xs px-3 py-1 rounded-full">
                  Current
                </span>
              )}
            </div>

            <div className="mb-4">
              <span className="text-3xl font-bold text-[#336A29]">$0</span>
              <span className="text-[#336A29]/70"> / month</span>
            </div>

            <div className="space-y-2 mb-6">
              {subscriptionPlans[0].features.map((feature, idx) => (
                <div key={idx} className="flex items-start gap-2">
                  <Check className="h-4 w-4 text-[#49842B] mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-[#336A29]">{feature}</span>
                </div>
              ))}
            </div>

            {isCurrentPlan('free') && (
              <div className="text-center text-sm text-[#336A29]/70">
                You're on the Free plan
              </div>
            )}
          </div>
        </div>

        {/* Pro Plan */}
        <div className="mt-4 mx-6">
          <div className={`bg-[#C1D95C] rounded-2xl p-6 border-2 ${isCurrentPlan('pro') ? 'border-[#49842B]' : 'border-transparent'} relative overflow-hidden`}>
            <div className="absolute top-0 right-0 bg-[#49842B] text-white text-xs px-4 py-1 rounded-bl-lg">
              POPULAR
            </div>

            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center">
                  <Crown className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-[#336A29] font-bold text-lg">Pro Plan</h3>
                  <p className="text-[#336A29]/70 text-sm">For growing businesses</p>
                </div>
              </div>
              {isCurrentPlan('pro') && (
                <span className="bg-[#49842B] text-white text-xs px-3 py-1 rounded-full">
                  Current
                </span>
              )}
            </div>

            <div className="mb-4">
              <span className="text-3xl font-bold text-[#336A29]">$29</span>
              <span className="text-[#336A29]/70"> / month</span>
              <div className="text-sm text-[#336A29]/60 mt-1">or $290/year (save $58)</div>
            </div>

            <div className="space-y-2 mb-6">
              {subscriptionPlans[1].features.map((feature, idx) => (
                <div key={idx} className="flex items-start gap-2">
                  <Check className="h-4 w-4 text-[#49842B] mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-[#336A29]">{feature}</span>
                </div>
              ))}
            </div>

            {!isCurrentPlan('pro') ? (
              <Button
                onClick={() => handleUpgrade('pro_monthly')}
                className="w-full bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white rounded-full"
                disabled={loading}
              >
                {currentTier === 'enterprise' ? 'Downgrade to Pro' : 'Upgrade to Pro'}
              </Button>
            ) : (
              <Button
                onClick={handleManageSubscription}
                className="w-full bg-[#80B155] text-[#336A29] rounded-full"
                disabled={loading}
              >
                Manage Subscription
              </Button>
            )}
          </div>
        </div>

        {/* Enterprise Plan */}
        <div className="mt-4 mx-6">
          <div className={`bg-[#C1D95C] rounded-2xl p-6 border-2 ${isCurrentPlan('enterprise') ? 'border-[#49842B]' : 'border-transparent'}`}>
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-[#49842B] to-[#336A29] rounded-xl flex items-center justify-center">
                  <Building2 className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-[#336A29] font-bold text-lg">Enterprise Plan</h3>
                  <p className="text-[#336A29]/70 text-sm">Full white-label solution</p>
                </div>
              </div>
              {isCurrentPlan('enterprise') && (
                <span className="bg-[#49842B] text-white text-xs px-3 py-1 rounded-full">
                  Current
                </span>
              )}
            </div>

            <div className="mb-4">
              <span className="text-3xl font-bold text-[#336A29]">$99</span>
              <span className="text-[#336A29]/70"> / month</span>
              <div className="text-sm text-[#336A29]/60 mt-1">or $990/year (save $198)</div>
            </div>

            <div className="space-y-2 mb-6">
              {subscriptionPlans[3].features.map((feature, idx) => (
                <div key={idx} className="flex items-start gap-2">
                  <Check className="h-4 w-4 text-[#49842B] mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-[#336A29]">{feature}</span>
                </div>
              ))}
            </div>

            {!isCurrentPlan('enterprise') ? (
              <Button
                onClick={() => handleUpgrade('enterprise_monthly')}
                className="w-full bg-gradient-to-r from-[#49842B] to-[#336A29] hover:from-[#336A29] hover:to-[#49842B] text-white rounded-full"
                disabled={loading}
              >
                Upgrade to Enterprise
              </Button>
            ) : (
              <Button
                onClick={handleManageSubscription}
                className="w-full bg-[#80B155] text-[#336A29] rounded-full"
                disabled={loading}
              >
                Manage Subscription
              </Button>
            )}
          </div>
        </div>

        {/* Contact Sales */}
        <div className="mt-4 mx-6 bg-[#C1D95C] rounded-2xl p-4 text-center">
          <p className="text-[#336A29] font-medium mb-2">Need a custom solution?</p>
          <p className="text-sm text-[#336A29]/70 mb-3">
            Contact our sales team for enterprise pricing and custom white-label packages
          </p>
          <Button
            variant="outline"
            className="border-[#49842B] text-[#49842B] hover:bg-[#49842B]/10"
          >
            Contact Sales
          </Button>
        </div>
      </div>
    </div>
  );
}