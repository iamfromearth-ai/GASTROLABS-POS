# 🖥️ Quick Console Commands for Your POS System

Useful commands to run in browser console (F12 → Console tab)

---

## 🔍 View Current UPI ID

```javascript
// See what UPI ID is currently stored
const config = JSON.parse(localStorage.getItem('gastrolabs_receipt_config'));
console.log('Current UPI ID:', config.paymentQR?.upiId || 'Not set');
console.log('Full payment QR config:', config.paymentQR);
```

---

## 💳 Update UPI ID (Quick Fix)

```javascript
// Replace YOUR_NEW_UPI_ID with your actual UPI ID
const config = JSON.parse(localStorage.getItem('gastrolabs_receipt_config'));
config.paymentQR.upiId = 'YOUR_NEW_UPI_ID@paytm';  // ← Change this
localStorage.setItem('gastrolabs_receipt_config', JSON.stringify(config));
console.log('✅ UPI ID updated to:', config.paymentQR.upiId);
location.reload();
```

### Example:
```javascript
// If your new UPI is: merchant@ybl
const config = JSON.parse(localStorage.getItem('gastrolabs_receipt_config'));
config.paymentQR.upiId = 'merchant@ybl';
localStorage.setItem('gastrolabs_receipt_config', JSON.stringify(config));
console.log('✅ UPI ID updated to:', config.paymentQR.upiId);
location.reload();
```

---

## 📋 View All Settings

```javascript
// See everything that's stored
const config = JSON.parse(localStorage.getItem('gastrolabs_receipt_config'));
console.table({
  'Business Name': config.business?.businessName,
  'UPI ID': config.paymentQR?.upiId,
  'Logo Enabled': config.logo?.enabled,
  'Footer Enabled': config.footer?.enabled
});
```

---

## 🗑️ Clear UPI ID Only

```javascript
// Remove just the UPI ID
const config = JSON.parse(localStorage.getItem('gastrolabs_receipt_config'));
config.paymentQR.upiId = '';
localStorage.setItem('gastrolabs_receipt_config', JSON.stringify(config));
console.log('✅ UPI ID cleared');
location.reload();
```

---

## 🔄 Clear All Settings (Reset to Defaults)

```javascript
// WARNING: This clears ALL your settings!
localStorage.removeItem('gastrolabs_receipt_config');
console.log('✅ All settings cleared. Reloading...');
location.reload();
```

---

## 🧪 Test UPI Validation

```javascript
// Test if a UPI ID is valid format
function testUPI(upiId) {
  const regex = /^[\w\.\-]+@[\w\.]+$/;
  const isValid = regex.test(upiId);
  console.log(`UPI ID: ${upiId}`);
  console.log(`Valid: ${isValid ? '✅ YES' : '❌ NO'}`);
  return isValid;
}

// Test your UPI IDs
testUPI('jyothish.rajendran@federal');  // Should be ✅ YES
testUPI('merchant@paytm');               // Should be ✅ YES
testUPI('invalid');                      // Should be ❌ NO
```

---

## 📊 View Receipt Config Structure

```javascript
// See the complete config structure
const config = JSON.parse(localStorage.getItem('gastrolabs_receipt_config'));
console.log(JSON.stringify(config, null, 2));
```

---

## 🎯 Quick Diagnostic

```javascript
// All-in-one diagnostic
const config = JSON.parse(localStorage.getItem('gastrolabs_receipt_config'));

console.log('═══════════════════════════════════');
console.log('📊 POS SYSTEM DIAGNOSTIC');
console.log('═══════════════════════════════════');
console.log('Business Name:', config.business?.businessName || 'Not set');
console.log('Business Address:', config.business?.address || 'Not set');
console.log('UPI ID:', config.paymentQR?.upiId || 'Not set');
console.log('Logo Enabled:', config.logo?.enabled ? 'Yes' : 'No');
console.log('Logo Type:', config.logo?.type || 'Not set');
console.log('Footer Enabled:', config.footer?.enabled ? 'Yes' : 'No');
console.log('Show Total QTY:', config.showTotalQty ? 'Yes' : 'No');
console.log('Show Grand Total:', config.showGrandTotal ? 'Yes' : 'No');
console.log('═══════════════════════════════════');

// Test UPI validation
if (config.paymentQR?.upiId) {
  const isValid = /^[\w\.\-]+@[\w\.]+$/.test(config.paymentQR.upiId);
  console.log('UPI ID Valid:', isValid ? '✅ YES' : '❌ NO (Invalid format)');
} else {
  console.log('UPI ID Valid: ⚠️  Not configured');
}
```

---

## 💡 Copy & Paste Ready Commands

### **Just tell me your new UPI ID and I'll give you the exact command!**

For example, if your new UPI is: `newshop@paytm`

```javascript
const c=JSON.parse(localStorage.getItem('gastrolabs_receipt_config'));c.paymentQR.upiId='newshop@paytm';localStorage.setItem('gastrolabs_receipt_config',JSON.stringify(c));console.log('✅ Updated to:',c.paymentQR.upiId);location.reload();
```

---

## 🚀 After Running Commands

1. The page will auto-reload
2. Go to POS and add items
3. Click Checkout
4. Check console - you should see your new UPI ID:
   ```
   🔍 PrintPreview - Generating UPI QR with: {
     upiId: 'YOUR_NEW_UPI_ID',
     businessName: 'VADA AND GOSSIP',
     total: XX
   }
   ```

---

## 🆘 If Nothing Works

Run this complete reset and reconfigure:

```javascript
// 1. Backup current settings
const backup = localStorage.getItem('gastrolabs_receipt_config');
console.log('Backup saved to clipboard');

// 2. Clear and reload
localStorage.removeItem('gastrolabs_receipt_config');
console.log('Settings cleared. Page will reload...');
setTimeout(() => location.reload(), 1000);
```

Then manually:
1. Go to Settings → Receipt Settings → Payment QR code
2. Enter your new UPI ID
3. Refresh page

---

**What's your new UPI ID? I'll give you the exact command to paste!**
