# 💳 Dynamic UPI Payment QR Code System

## Overview

Your POS system now generates **dynamic UPI payment QR codes** that automatically include the exact order amount and order ID. This creates a seamless payment experience where:

1. **Customer orders** → Receipt prints with QR code
2. **Customer scans QR** → UPI app opens with exact amount pre-filled
3. **Customer pays** → Employee marks order as paid in Order History
4. **Bill closed** → Order moved to "Paid" status

---

## ✨ How It Works

### Setup (One-Time Configuration)

1. **Go to Settings → Receipt Settings → Payment QR Code**
2. **Enter your UPI ID** (e.g., `yourname@paytm` or `yourname@ybl`)
3. **Save** - That's it! Dynamic QR codes are now enabled.

### When Printing Receipts

**With UPI ID Configured:**
- ✅ QR code contains: `upi://pay?pa=yourname@paytm&pn=ShopName&am=150.00&cu=INR&tn=Payment for Order #123456`
- ✅ Label shows: "Scan to Pay ₹150"
- ✅ Customer scans → UPI app opens with ₹150 pre-filled
- ✅ Customer completes payment
- ✅ Employee verifies payment → Marks as paid in Order History

**Without UPI ID:**
- ❌ QR code contains only order tracking info
- ❌ Label shows: "Scan to track payment"
- ❌ No automatic payment link

---

## 🎯 Key Features

### 1. **Dynamic Amount**
Each QR code is unique and contains the exact order total:
- Order for ₹50 → QR code has ₹50
- Order for ₹250 → QR code has ₹250

### 2. **Order Tracking**
QR code includes order ID in the payment note:
- `Payment for Order #123456`
- Easy to match payments with orders

### 3. **Standard UPI Protocol**
Uses official UPI deep-link format:
```
upi://pay?pa=UPI_ID&pn=NAME&am=AMOUNT&cu=INR&tn=NOTE
```

Works with ALL UPI apps:
- ✅ Google Pay
- ✅ PhonePe
- ✅ Paytm
- ✅ BHIM
- ✅ Amazon Pay
- ✅ Any UPI app

---

## 📱 Customer Experience

### Step-by-Step Flow

1. **Customer receives printed receipt** with QR code
2. **Opens any UPI app** (Google Pay, PhonePe, etc.)
3. **Scans QR code** from receipt
4. **UPI app opens** with:
   - Merchant: Your Business Name
   - Amount: ₹[Order Total] (pre-filled, can't be changed)
   - Note: "Payment for Order #[ID]"
5. **Customer enters UPI PIN** and confirms
6. **Payment complete!** ✅

### What Customer Sees
```
┌─────────────────────────┐
│   Pay to Merchant       │
│                         │
│   Vada and Gossip      │
│                         │
│   Amount: ₹ 150.00     │
│   [Cannot be edited]    │
│                         │
│   Note: Payment for     │
│   Order #783946         │
│                         │
│   [Enter UPI PIN]       │
└─────────────────────────┘
```

---

## 👨‍💼 Employee Workflow

### Creating Order with Payment QR

1. **Add items to bill** in POS
2. **Click "Checkout"**
3. **Print receipt** → Dynamic QR code included
4. **Give receipt to customer**
5. **Customer scans and pays**

### Confirming Payment

1. **Go to Order History** (accessible without password)
2. **Find the unpaid order** (shows in "Active Orders" tab)
3. **Verify payment received** (check UPI app/bank)
4. **Click "Mark as Paid"**
5. **Order moves to "Paid Orders"** tab

---

## 🔧 Technical Details

### UPI Payment URL Format

```typescript
upi://pay?
  pa=yourname@paytm         // Payee Address (your UPI ID)
  &pn=Vada%20and%20Gossip   // Payee Name (your business)
  &am=150.00                // Amount (order total)
  &cu=INR                   // Currency
  &tn=Payment%20for%20Order%20%23783946  // Transaction Note
```

### QR Code Generation Logic

**File:** `/lib/upi-payment-generator.ts`

```typescript
export function generateUPIPaymentURL(params: UPIPaymentParams): string {
  const { upiId, name, amount, orderId, note } = params;
  
  return `upi://pay?pa=${upiId}&pn=${encodeURIComponent(name)}&am=${amount.toFixed(2)}&cu=INR&tn=${encodeURIComponent(note)}`;
}
```

**Called in:** `/App.tsx` → `handleThermalPrint()`

---

## 🎨 Receipt Display

### QR Code Section on Receipt

```
━━━━━━━━━━━━━━━━━━━━━━━━
   Scan to Pay ₹150
   
   [QR CODE IMAGE]
   
   Order ID: #783946
━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## 💡 Best Practices

### For Shop Owners

1. **✅ Test your UPI ID first**
   - Print a test receipt
   - Scan QR code with your phone
   - Verify UPI app opens correctly
   - DON'T complete payment (it's a test!)

2. **✅ Display QR code prominently**
   - Receipt already optimized for 58mm thermal printers
   - QR code is 120x120px - perfect for scanning

3. **✅ Train employees**
   - How to check UPI notifications
   - How to mark orders as paid
   - How to handle scanning issues

### For Employees

1. **✅ Always verify payment before marking as paid**
   - Check UPI notification on phone
   - Match order amount
   - Match order ID in payment note

2. **✅ If customer can't scan:**
   - Check phone camera/permissions
   - Try different UPI app
   - Clean QR code (if smudged)
   - Manually share UPI ID as fallback

---

## 🐛 Troubleshooting

### QR Code Not Working

**Issue:** QR code doesn't open UPI app

**Solutions:**
1. Verify UPI ID format: `username@bankname`
2. Check Settings → Payment QR Code → UPI ID is saved
3. Print new receipt (old receipts have old QR codes)

### Wrong Amount in QR

**Issue:** UPI app shows different amount

**Solution:**
- Each QR is generated at print time with current order total
- If order was modified after printing, print new receipt

### Payment Received but Can't Find Order

**Solution:**
1. Go to Order History
2. Check order ID in UPI payment note
3. Search for that order ID
4. Mark as paid

---

## 🔒 Security & Privacy

### What's Stored

- ✅ UPI ID: Stored locally in browser (localStorage)
- ✅ Order data: Stored locally in browser
- ❌ Payment details: NOT stored
- ❌ Customer data: NOT collected

### UPI Safety

- ✅ Standard UPI protocol (same as Google Pay)
- ✅ Amount cannot be edited by customer
- ✅ No sensitive data in QR code
- ✅ Customer must enter UPI PIN to pay

---

## 📊 Benefits

### For Business

1. **Faster payments** - No cash handling
2. **Accurate amounts** - No wrong change
3. **Digital tracking** - UPI notifications
4. **Professional** - Modern payment method

### For Customers

1. **Convenient** - Scan and pay
2. **Safe** - No cash to carry
3. **Receipt proof** - Order ID in transaction
4. **All UPI apps work** - Not limited to one app

---

## 🎉 Summary

Your POS now has **professional-grade dynamic UPI payment QR codes**!

**Setup:** Enter UPI ID once  
**Usage:** Automatic on every receipt  
**Result:** Faster, easier payments  

**Next Steps:**
1. Configure your UPI ID in Settings
2. Print a test receipt
3. Scan with your phone to test
4. Start accepting payments! 🚀

---

**Need Help?**
- Check console logs (F12) for QR generation messages
- Logs show: "✅ Generated UPI payment QR code for ₹[amount]"
- Or: "ℹ️ Generated order tracking QR code (UPI not configured)"
