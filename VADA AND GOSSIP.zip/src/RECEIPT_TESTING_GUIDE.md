# 🧪 Receipt System Testing Guide

Quick guide to verify all receipt functionality works correctly in your deployed app.

---

## 🚀 Quick Test (5 minutes)

### 1. **Test Print Preview**
1. Navigate to: **Settings → Receipt Settings**
2. Click **"Print Test"** button (top right)
3. ✅ Should see: Beautiful receipt preview dialog
4. Click **"Print"** button
5. ✅ Should see: Browser print dialog opens
6. ✅ Should see: Simple test receipt in new window

### 2. **Test Toggle Switches**
1. In Receipt Settings, toggle **"TOTAL QTY"** OFF
2. ✅ Should see: Green success toast
3. Toggle it back ON
4. ✅ Should see: Another success toast
5. Test 2-3 more toggles to confirm they work

### 3. **Test Sub-Settings Navigation**
1. Click **"Identity"**
2. ✅ Should navigate to Business Identity screen
3. Click back arrow
4. ✅ Should return to Receipt Settings
5. Try **"LOGO"** button
6. ✅ Should navigate to Logo Settings
7. Click back
8. Try **"Payment QR code"**
9. ✅ Should navigate to Payment QR Settings

### 4. **Test Business Name Change**
1. Navigate: Settings → Receipt Settings → Identity
2. Change **"Business Name"** to your shop name
3. ✅ Should see: Success toast
4. Go back to main POS screen
5. ✅ Should see: Your shop name in the header

### 5. **Test Full Receipt Flow**
1. Add 2-3 items to cart in POS
2. Click **Checkout** (green button in sidebar)
3. ✅ Should see: Print Preview dialog
4. ✅ Should see: Your shop name in receipt
5. ✅ Should see: Items listed correctly
6. ✅ Should see: Total calculated correctly
7. ✅ Should see: **"QR CODE HIDDEN"** placeholder (security feature)
8. ✅ Should see: Small order tracking QR at bottom
9. Click **"Print"**
10. ✅ Should see: Actual printing starts

---

## 🔧 Detailed Tests (15 minutes)

### **Test Each Sub-Setting**

#### Logo Settings
1. Settings → Receipt Settings → LOGO
2. Select **"Upload"** type
3. Click **"Upload Logo"**
4. Select an image file
5. ✅ Logo preview appears
6. Go back and Print Test
7. ✅ Your logo appears in receipt

#### Business Identity
1. Settings → Receipt Settings → Identity
2. Fill in:
   - Business Name: `Your Shop`
   - Address: `123 Main St`
   - Phone: `555-1234`
3. ✅ All fields save (toast notifications)
4. Print Test
5. ✅ All info appears in receipt header

#### Payment QR Settings
1. Settings → Receipt Settings → Payment QR code
2. Toggle **"Enable Payment QR"** ON
3. Enter UPI ID: `yourname@paytm` (or your UPI)
4. ✅ Success toast
5. Go to POS, add items
6. Click Checkout
7. ✅ Preview still shows **"QR CODE HIDDEN"** (security!)
8. Note the total amount (e.g., ₹55)
9. Click Print
10. In new window: ✅ Real QR code appears with amount

#### Footer Settings
1. Settings → Receipt Settings → Footer
2. Toggle **"Enable Footer"** ON
3. Change text to: `Thank you! Visit again!`
4. ✅ Success toast
5. Print Test
6. ✅ Footer text appears at bottom

#### Time Format
1. Settings → Receipt Settings → Time Format
2. Select different format (e.g., "DD/MM/YYYY HH:MM")
3. ✅ Checkmark appears on selected format
4. Go back
5. ✅ Receipt Settings shows selected format

#### Taxes
1. Settings → Receipt Settings → Taxes
2. Toggle **"Enable Taxes"** ON
3. Click **"+ Add Tax"**
4. Enter:
   - Name: `GST`
   - Rate: `18`
5. ✅ Tax item appears
6. (Note: Tax calculation would need implementation in receipt)

#### Discount
1. Settings → Receipt Settings → Discount
2. Toggle **"Enable Discount"** ON
3. Select type: **"Percentage"**
4. Enter value: `10`
5. ✅ Settings saved
6. (Note: Discount calculation would need implementation in receipt)

---

## 📱 Mobile Testing

### **Mobile Browser**
1. Open app on mobile device
2. Navigate: Settings → Receipt Settings
3. ✅ All buttons touch-friendly
4. ✅ Scrolling smooth
5. Click **"Print Test"**
6. ✅ Preview dialog responsive
7. ✅ Buttons don't overlap
8. Click **"Print"**
9. ✅ Mobile print dialog appears

### **Mobile Printing**
1. Add items in POS on mobile
2. Click Checkout
3. ✅ Preview looks good on small screen
4. Click Print
5. ✅ Mobile browser offers print/save options
6. Try "Save as PDF"
7. ✅ PDF generated successfully

---

## 🔒 Security Testing

### **Payment QR Masking**
1. Configure UPI ID in Payment QR Settings
2. Add items and checkout
3. In Print Preview:
   - ✅ Should see placeholder icon
   - ✅ Should see "QR CODE HIDDEN" text
   - ✅ Should NOT see actual QR code
4. Click Print
5. In new print window:
   - ✅ Should see actual payment QR code
   - ✅ QR code should include exact amount

### **Order Tracking**
1. Create an order
2. Check Print Preview
3. ✅ Small QR code visible at bottom right
4. ✅ Order ID shown (last 6 digits)
5. ✅ Date shown
6. (Note: Scanning this QR would show order ID)

---

## 💾 Data Persistence Testing

### **Settings Survive Reload**
1. Change multiple settings:
   - Business name
   - Enable logo
   - Change footer
   - Toggle some options
2. Note all changes
3. **Refresh browser** (F5 or Cmd+R)
4. Navigate to Settings → Receipt Settings
5. ✅ All changes still there
6. ✅ Business name in POS header unchanged
7. ✅ Print Test shows all your settings

### **Settings Survive App Close**
1. Configure settings
2. Close browser tab completely
3. Open new tab, go to app
4. Check settings
5. ✅ Everything preserved

### **Clear Data Test**
1. Settings → Data Settings → Clear All Data
2. Confirm clear
3. Navigate to Receipt Settings
4. ✅ Back to defaults:
   - Business Name: "Vada and Gossip"
   - Address: "Breakfast, Chat & Bun"
   - All toggles at default state

---

## 🐛 Error Testing

### **Camera Permission**
1. Click QR scanner (in Payment Dashboard)
2. When browser asks for camera:
   - Click **"Block"** or **"Deny"**
3. ✅ Should see friendly error message
4. ✅ Should see "Retry Camera" button
5. ✅ Should be able to cancel
6. **No console errors** (just info log)

### **Invalid UPI ID**
1. Payment QR Settings
2. Enter invalid UPI: `notvalid`
3. (Current behavior: saves anyway)
4. Try checkout
5. ✅ Should handle gracefully

### **Missing Logo Image**
1. Logo Settings
2. Enter broken URL: `https://example.com/broken.jpg`
3. Print Test
4. ✅ Should fallback to default logo
5. ✅ No broken image icon

---

## ✅ Success Criteria

All tests should pass with these results:
- ✅ No console errors (warnings okay)
- ✅ All navigation works smoothly
- ✅ All toggles update immediately
- ✅ All settings persist after reload
- ✅ Print Preview shows all configurations
- ✅ Print Test generates printable receipt
- ✅ Mobile UI fully responsive
- ✅ Payment QR properly masked in preview
- ✅ Success toasts appear for all changes

---

## 🚨 If Something Fails

### **Print Test doesn't work**
- Check: Pop-up blocker enabled?
- Try: Allow pop-ups for this site
- Verify: No console errors

### **Settings don't save**
- Check: Browser localStorage enabled?
- Try: Incognito mode (rules out extensions)
- Check: Console for localStorage errors

### **Print Preview blank**
- Check: Are there items in cart?
- Verify: receiptConfig loaded
- Check: Console errors

### **Navigation broken**
- Try: Refresh page
- Check: Console for errors
- Verify: All components loaded

---

## 📊 Test Results Template

```
✅ Print Test: PASS / FAIL
✅ Toggles: PASS / FAIL
✅ Navigation: PASS / FAIL
✅ Business Name: PASS / FAIL
✅ Receipt Flow: PASS / FAIL
✅ Logo Upload: PASS / FAIL
✅ Payment QR: PASS / FAIL
✅ Mobile UI: PASS / FAIL
✅ Data Persistence: PASS / FAIL
✅ QR Masking: PASS / FAIL
```

---

## 🎯 Production Deployment Checklist

Before going live in your shop:

- [ ] Tested on your actual devices (phone, tablet, computer)
- [ ] Configured your business name and address
- [ ] Uploaded your shop logo
- [ ] Set up your UPI ID for payments
- [ ] Customized footer message
- [ ] Tested printing on your actual printer
- [ ] Verified QR codes scan correctly
- [ ] Trained staff on how to use system
- [ ] Set admin password for Settings access
- [ ] Backed up your configuration (Export Data)

---

**Ready for Production?** ✅

Once all tests pass, your receipt system is ready for real-world use!

**Support**: Check `/RECEIPT_SYSTEM_VERIFICATION.md` for detailed technical docs.
