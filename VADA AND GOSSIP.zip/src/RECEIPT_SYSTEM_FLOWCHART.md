# 🔄 Receipt System Flow Diagrams

Visual guide to understanding how the receipt system works.

---

## 📱 Main User Flow

```
┌─────────────────────────────────────────────────────────────┐
│                        POS SCREEN                           │
│  ┌────────────────────────────────────────────────────┐    │
│  │  [Regular Tea] [Special Tea] [Samosa] [Bun]        │    │
│  │                                                     │    │
│  │  User clicks item buttons to add to cart           │    │
│  └────────────────────────────────────────────────────┘    │
│                           ▼                                 │
│  ┌────────────────────────────────────────────────────┐    │
│  │  CART: 2x Regular Tea, 1x Samosa                   │    │
│  │  Total: ₹55                                        │    │
│  └────────────────────────────────────────────────────┘    │
│                           ▼                                 │
│              User clicks [CHECKOUT] button                  │
└─────────────────────────────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                   PRINT PREVIEW DIALOG                      │
│  ┌────────────────────────────────────────────────────┐    │
│  │  ┌─────────────┐                                   │    │
│  │  │  [LOGO]     │  Vada and Gossip                  │    │
│  │  └─────────────┘  Breakfast, Chat & Bun            │    │
│  │  ───────────────────────────────────────────────   │    │
│  │  Regular Tea x2                             ₹20    │    │
│  │  Samosa x1                                  ₹20    │    │
│  │  Coffee x1                                  ₹15    │    │
│  │  ───────────────────────────────────────────────   │    │
│  │  TOTAL:                                     ₹55    │    │
│  │  ───────────────────────────────────────────────   │    │
│  │         ┌──────────────────┐                       │    │
│  │         │  QR CODE HIDDEN  │ ← Security Feature!   │    │
│  │         │ (Visible on      │                       │    │
│  │         │  print only)     │                       │    │
│  │         └──────────────────┘                       │    │
│  │  ───────────────────────────────────────────────   │    │
│  │  THANK YOU AND COME AGAIN!                         │    │
│  │                        ┌───┐                       │    │
│  │  Order: #123456        │QR │ ← Tracking QR        │    │
│  │  Date: 25 Oct          └───┘                       │    │
│  └────────────────────────────────────────────────────┘    │
│                                                             │
│        [Cancel]                         [Print] ◄───────────┼── User clicks
└─────────────────────────────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                NEW WINDOW - PRINTABLE RECEIPT               │
│  ┌────────────────────────────────────────────────────┐    │
│  │  Same content as preview BUT:                      │    │
│  │                                                     │    │
│  │         ┌──────────────────┐                       │    │
│  │         │ ██████████████  │ ← Real Payment QR!     │    │
│  │         │ ██ SCAN ME ███  │   (with exact amount)  │    │
│  │         │ ██████████████  │                        │    │
│  │         │   Pay ₹55       │                        │    │
│  │         └──────────────────┘                       │    │
│  └────────────────────────────────────────────────────┘    │
│                           ▼                                 │
│              Browser Print Dialog Opens                     │
│        User can print or save as PDF                        │
└─────────────────────────────────────────────────────────────┘
```

---

## ⚙️ Settings Configuration Flow

```
┌──────────────────────────────────────────────────────────────┐
│                   SETTINGS SCREEN                            │
│  ┌────────────────────────────────────────────────────┐     │
│  │  [Receipt Settings]  [Printer]  [Data]  [...]     │     │
│  └────────────────────────────────────────────────────┘     │
│                           ▼                                  │
│              User clicks [Receipt Settings]                  │
└──────────────────────────────────────────────────────────────┘
                            ▼
┌──────────────────────────────────────────────────────────────┐
│               RECEIPT SETTINGS SCREEN                        │
│  ┌────────────────────────────────────────────────────┐     │
│  │  Header: [Tea Shop________________]     [Print Test] ◄────┼── Click to test
│  │                                                      │     │
│  │  Customer                           [OFF] [ON]      │     │
│  │  ─────────────────────────────────────────────────  │     │
│  │  [Identity]                                     >   │ ◄───┼── Click to configure
│  │  [Sequence NO.]                                 >   │     │
│  │  [LOGO]                                         >   │     │
│  │  [Taxes]                                        >   │     │
│  │  [Discount]                                     >   │     │
│  │  [Other Fees]                                   >   │     │
│  │  ─────────────────────────────────────────────────  │     │
│  │  TOTAL QTY                          [OFF] [ON]      │ ◄───┼── Toggle options
│  │  Subtotal                           [OFF] [ON]      │     │
│  │  Grand Total                        [OFF] [ON]      │     │
│  │  ─────────────────────────────────────────────────  │     │
│  │  [Footer]                                       >   │     │
│  │  [QR code]                                      >   │     │
│  │  [Payment QR code]                              >   │     │
│  │  [Time Format]                                  >   │     │
│  └────────────────────────────────────────────────────┘     │
└──────────────────────────────────────────────────────────────┘
                            ▼
           User clicks [Identity] or any sub-setting
                            ▼
┌──────────────────────────────────────────────────────────────┐
│              BUSINESS IDENTITY SCREEN                        │
│  ┌────────────────────────────────────────────────────┐     │
│  │  [←] Business Identity                              │     │
│  │                                                      │     │
│  │  Show Business Info              [OFF] [ON]         │     │
│  │                                                      │     │
│  │  Business Name:                                     │     │
│  │  [Vada and Gossip______________]                    │ ◄───┼── User types
│  │                                                      │     │
│  │  Address:                                           │     │
│  │  [Breakfast, Chat & Bun_________]                   │     │
│  │                                                      │     │
│  │  Phone: [________________]                          │     │
│  │  Email: [________________]                          │     │
│  │  Website: [______________]                          │     │
│  │  Tax ID: [_______________]                          │     │
│  └────────────────────────────────────────────────────┘     │
│                           ▼                                  │
│     Changes save automatically + Toast notification          │
└──────────────────────────────────────────────────────────────┘
                            ▼
                   User clicks [←] Back
                            ▼
              Returns to Receipt Settings Screen
```

---

## 💾 Data Persistence Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    USER MAKES CHANGE                        │
│  Example: Toggles "Show TOTAL QTY" from OFF to ON           │
└─────────────────────────────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────┐
│               ReceiptSettings.tsx                            │
│  toggleSetting('showTotalQty')                              │
│      ▼                                                       │
│  onUpdateSettings({                                         │
│    ...settings,                                             │
│    showTotalQty: true  ← NEW VALUE                          │
│  })                                                          │
└─────────────────────────────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                      App.tsx                                 │
│  setReceiptConfig({                                         │
│    ...receiptConfig,                                        │
│    showTotalQty: true                                       │
│  })                                                          │
└─────────────────────────────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              useEffect (in App.tsx)                          │
│  Triggers on receiptConfig change                           │
│      ▼                                                       │
│  localStorage.setItem(                                      │
│    'gastrolabs_receipt_config',                            │
│    JSON.stringify(receiptConfig)                           │
│  )                                                          │
└─────────────────────────────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                 Browser localStorage                         │
│  Key: 'gastrolabs_receipt_config'                          │
│  Value: {                                                   │
│    "showTotalQty": true,  ← SAVED!                         │
│    "showSubtotal": false,                                  │
│    "business": {                                           │
│      "businessName": "Vada and Gossip",                    │
│      ...                                                    │
│    },                                                       │
│    ...                                                      │
│  }                                                          │
└─────────────────────────────────────────────────────────────┘
                            ▼
              PERSISTS EVEN AFTER:
              - Browser refresh
              - Tab close/reopen
              - Computer restart
              - Days/weeks/months later
```

---

## 🔄 Data Loading Flow (App Startup)

```
┌─────────────────────────────────────────────────────────────┐
│                   APP STARTS / PAGE LOADS                    │
└─────────────────────────────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              useEffect (runs once on mount)                  │
│                                                              │
│  const savedConfig = localStorage.getItem(                  │
│    'gastrolabs_receipt_config'                             │
│  );                                                          │
└─────────────────────────────────────────────────────────────┘
                            ▼
                ┌───────────┴───────────┐
                ▼                       ▼
    ┌──────────────────┐    ┌──────────────────┐
    │  savedConfig     │    │  No savedConfig  │
    │  EXISTS          │    │  found           │
    └──────────────────┘    └──────────────────┘
                ▼                       ▼
    ┌──────────────────┐    ┌──────────────────┐
    │ Parse JSON       │    │ Use defaults     │
    │ Deep merge with  │    │ from             │
    │ defaults         │    │ DEFAULT_RECEIPT_ │
    │                  │    │ CONFIG           │
    └──────────────────┘    └──────────────────┘
                ▼                       ▼
                └───────────┬───────────┘
                            ▼
┌─────────────────────────────────────────────────────────────┐
│         setReceiptConfig(mergedConfig)                       │
│                                                              │
│  App now has your saved settings!                           │
│  - Business name: "Vada and Gossip"                         │
│  - Logo: Your uploaded image                                │
│  - All toggles: Your preferences                            │
│  - UPI ID: Your payment details                             │
└─────────────────────────────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              APP RENDERS WITH YOUR SETTINGS                  │
│  - POS header shows your business name                      │
│  - Receipts use your configuration                          │
│  - Settings screens show saved values                       │
└─────────────────────────────────────────────────────────────┘
```

---

## 🖨️ Print Test Flow

```
┌─────────────────────────────────────────────────────────────┐
│           RECEIPT SETTINGS SCREEN                            │
│  User clicks [Print Test] button (top right)                │
└─────────────────────────────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────┐
│         handlePrintTest() in ReceiptSettings.tsx             │
│  setShowTestPreview(true)                                   │
│  toast.success('Opening test receipt preview...')           │
└─────────────────────────────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              PRINT PREVIEW DIALOG OPENS                      │
│  <PrintPreview                                              │
│    open={true}                                              │
│    items={testItems}  ← [Regular Tea x2, Samosa, Coffee]   │
│    total={55}                                               │
│    config={settings}  ← Current receipt configuration       │
│    onPrint={handleActualPrint}                             │
│    orderId="TEST-123456"                                    │
│  />                                                          │
└─────────────────────────────────────────────────────────────┘
                            ▼
            User reviews receipt, clicks [Print]
                            ▼
┌─────────────────────────────────────────────────────────────┐
│        handleActualPrint() in ReceiptSettings.tsx            │
│                                                              │
│  1. Close preview dialog                                    │
│  2. Create new window with printable HTML                   │
│  3. Wait for content to load                                │
│  4. Trigger window.print()                                  │
│  5. Show success toast                                      │
└─────────────────────────────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              BROWSER PRINT DIALOG                            │
│  User can:                                                  │
│  - Select printer                                           │
│  - Adjust print settings                                    │
│  - Save as PDF                                              │
│  - Preview before printing                                  │
│  - Click [Print] to send to printer                         │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔐 Security: Payment QR Masking

```
┌─────────────────────────────────────────────────────────────┐
│                    CHECKOUT FLOW                             │
│  Customer orders: Tea + Samosa = ₹55                        │
│  Cashier clicks [Checkout]                                  │
└─────────────────────────────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              PRINT PREVIEW (On Screen)                       │
│  ┌────────────────────────────────────────────────────┐    │
│  │         PAY USING UPI                              │    │
│  │  ┌──────────────────┐                              │    │
│  │  │    🔒 LOCKED     │ ← Prevents employee from     │    │
│  │  │  QR CODE HIDDEN  │   capturing QR before        │    │
│  │  │ Visible on print │   customer pays              │    │
│  │  │      only        │                              │    │
│  │  └──────────────────┘                              │    │
│  └────────────────────────────────────────────────────┘    │
│                                                             │
│  WHY? Prevents fraud where employee:                       │
│  1. Scans payment QR themselves                            │
│  2. Customer thinks they paid                              │
│  3. Employee keeps the money                               │
└─────────────────────────────────────────────────────────────┘
                            ▼
              Cashier clicks [Print]
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              PRINTED RECEIPT (Physical)                      │
│  ┌────────────────────────────────────────────────────┐    │
│  │         PAY USING UPI                              │    │
│  │  ┌──────────────────┐                              │    │
│  │  │ ███████████████  │ ← Real QR code appears!     │    │
│  │  │ ██ SCAN ME ████  │   Customer can now scan      │    │
│  │  │ ███████████████  │   and make payment           │    │
│  │  │   Pay ₹55        │   (exact amount)             │    │
│  │  └──────────────────┘                              │    │
│  │                                                     │    │
│  │  upi://pay?pa=yourname@paytm                       │    │
│  │           &pn=Vada+and+Gossip                      │    │
│  │           &am=55                 ← Exact amount!   │    │
│  │           &cu=INR                                  │    │
│  └────────────────────────────────────────────────────┘    │
│                                                             │
│  NOW SAFE:                                                 │
│  ✅ Customer receives receipt                              │
│  ✅ Customer scans QR to pay                               │
│  ✅ Payment goes to business account                       │
│  ✅ Employee cannot intercept                              │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎯 Component Architecture

```
                    App.tsx
                       │
         ┌─────────────┼─────────────┐
         ▼             ▼             ▼
    [POS View]  [Settings View]  [Other Views]
                       │
         ┌─────────────┼─────────────────────┐
         ▼                                    ▼
   Settings.tsx                     Receipt Settings
   (Main menu)                      (Main hub)
                                           │
         ┌─────────────┬─────────────┬────┴────┬─────────────┐
         ▼             ▼             ▼          ▼             ▼
    Identity      Logo        Footer      QR Code      Payment QR
    Settings     Settings    Settings     Settings      Settings
         │             │             │          │             │
         └─────────────┴─────────────┴──────────┴─────────────┘
                                    ▼
                          Updates flow back up
                                    ▼
                            App.tsx state
                                    ▼
                            localStorage
```

---

## 📊 State Management

```
┌──────────────────────────────────────────────────────────────┐
│                        App.tsx                               │
│                                                              │
│  receiptConfig = {                                          │
│    ┌──────────────────────────────────────────────┐        │
│    │  header: string                              │        │
│    │  showCustomer: boolean                       │        │
│    │  showTotalQty: boolean    ◄── Direct toggles │        │
│    │  showSubtotal: boolean       in Receipt      │        │
│    │  ...                         Settings         │        │
│    ├──────────────────────────────────────────────┤        │
│    │  logo: {                                     │        │
│    │    enabled: boolean         ◄── From Logo    │        │
│    │    type: 'upload'|'text'       Settings      │        │
│    │    imageUrl: string                          │        │
│    │    ...                                        │        │
│    │  }                                            │        │
│    ├──────────────────────────────────────────────┤        │
│    │  business: {                                 │        │
│    │    enabled: boolean         ◄── From         │        │
│    │    businessName: string        Business      │        │
│    │    address: string             Identity      │        │
│    │    ...                                        │        │
│    │  }                                            │        │
│    ├──────────────────────────────────────────────┤        │
│    │  tax: { ... }               ◄── From Tax     │        │
│    │  discount: { ... }          ◄── From Discount│        │
│    │  fees: { ... }              ◄── From Fees    │        │
│    │  qrCode: { ... }            ◄── From QR Code │        │
│    │  paymentQR: { ... }         ◄── From Payment │        │
│    │  sequence: { ... }          ◄── From Sequence│        │
│    │  footer: { ... }            ◄── From Footer  │        │
│    └──────────────────────────────────────────────┘        │
│  }                                                          │
│                                                              │
│  All nested configs merge into single receiptConfig object  │
│  Saved to localStorage on any change                        │
└──────────────────────────────────────────────────────────────┘
```

---

## 🔄 Type Safety Flow

```
BEFORE (❌ Type Mismatch):
┌──────────────────────────────────────────────────────────────┐
│  ReceiptSettings.tsx defines:                                │
│    interface BusinessInfo {                                  │
│      name: string;     ◄── WRONG!                           │
│      address: string;                                        │
│    }                                                          │
└──────────────────────────────────────────────────────────────┘
                            ▼
┌──────────────────────────────────────────────────────────────┐
│  BusinessIdentity.tsx defines:                               │
│    interface BusinessInfo {                                  │
│      enabled: boolean;                                       │
│      businessName: string;  ◄── CORRECT                     │
│      address: string;                                        │
│      ...                                                      │
│    }                                                          │
└──────────────────────────────────────────────────────────────┘
                            ▼
                   ❌ DATA MISMATCH!
          App expects 'businessName' but gets 'name'
                   Runtime errors possible


AFTER (✅ Type Safe):
┌──────────────────────────────────────────────────────────────┐
│  ReceiptSettings.tsx:                                        │
│    import type { BusinessInfo } from './BusinessIdentity'    │
│                             ▲                                │
│                             │                                │
│                   Single source of truth!                    │
└──────────────────────────────────────────────────────────────┘
                            ▼
┌──────────────────────────────────────────────────────────────┐
│  BusinessIdentity.tsx:                                       │
│    export interface BusinessInfo {                           │
│      enabled: boolean;                                       │
│      businessName: string;  ◄── Everyone uses this          │
│      address: string;                                        │
│      ...                                                      │
│    }                                                          │
└──────────────────────────────────────────────────────────────┘
                            ▼
                   ✅ TYPES MATCH!
            All components use same definition
                  No runtime errors
```

---

## 🎨 Summary Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                  GASTROLABS POS SYSTEM                       │
│                     Receipt Module                           │
└─────────────────────────────────────────────────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        ▼                   ▼                   ▼
    ┌────────┐      ┌──────────────┐     ┌──────────┐
    │  POS   │      │   SETTINGS   │     │  PRINT   │
    │ Screen │      │   (11 sub-   │     │ Preview  │
    │        │      │   screens)   │     │          │
    └────────┘      └──────────────┘     └──────────┘
        │                   │                   │
        └───────────────────┼───────────────────┘
                            ▼
                    ┌──────────────┐
                    │  App State   │
                    │ (receiptConf)│
                    └──────────────┘
                            ▼
                    ┌──────────────┐
                    │ localStorage │
                    │  Persistence │
                    └──────────────┘
                            ▼
                    ✅ Data persists
                    ✅ Survives reload
                    ✅ Type safe
                    ✅ Mobile ready
```

---

**📖 For complete technical details, see:**
- `/RECEIPT_SYSTEM_VERIFICATION.md` - Full documentation
- `/RECEIPT_TESTING_GUIDE.md` - Testing instructions
- `/COMPREHENSIVE_AUDIT_SUMMARY.md` - Audit results
