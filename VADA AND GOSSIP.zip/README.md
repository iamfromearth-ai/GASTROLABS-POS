
  # VADA AND GOSSIP

  This is a code bundle for VADA AND GOSSIP. The original project is available at https://www.figma.com/design/U9KhkUK9hZ8ONQwrUbWVya/VADA-AND-GOSSIP.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  